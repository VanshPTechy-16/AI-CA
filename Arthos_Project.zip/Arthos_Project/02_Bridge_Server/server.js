// Arthos Bridge: optional companion server. No dependencies needed (Node 18+).
//   1. API key proxy   : the Anthropic key stays on this machine, never in the browser
//   2. Shared storage  : several PCs on your office network share one workspace
//   3. Email           : real SMTP sending (needs `npm i nodemailer` plus the SMTP_* variables)
// Run:  ANTHROPIC_API_KEY=sk-ant-... BRIDGE_TOKEN=choose-a-secret node server.js
const http = require('http'), fs = require('fs'), path = require('path');
const PORT = +process.env.PORT || 8787, TOKEN = process.env.BRIDGE_TOKEN || '', KEY = process.env.ANTHROPIC_API_KEY || '';
const DATA = path.join(__dirname, 'data'); fs.mkdirSync(DATA, { recursive: true });
let mailer = null;
try { const nm = require('nodemailer'); if (process.env.SMTP_HOST) mailer = nm.createTransport({ host: process.env.SMTP_HOST, port: +process.env.SMTP_PORT || 587, secure: process.env.SMTP_SECURE === 'true', auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } }); } catch (e) { /* nodemailer not installed */ }
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type, X-Bridge-Token', 'Access-Control-Allow-Methods': 'GET,POST,PUT,OPTIONS' }); res.end(JSON.stringify(obj)); };
const body = req => new Promise((ok, no) => { let b = ''; req.on('data', c => { b += c; if (b.length > 25e6) { no(new Error('Too large')); req.destroy(); } }); req.on('end', () => { try { ok(b ? JSON.parse(b) : {}); } catch (e) { no(e); } }); });
http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, {});
  const url = new URL(req.url, 'http://x'); const p = url.pathname;
  if (TOKEN && req.headers['x-bridge-token'] !== TOKEN) return send(res, 401, { error: 'Wrong or missing bridge token.' });
  if (p === '/health') return send(res, 200, { ok: true, ai: !!KEY, mail: !!mailer, shared: true, auth: !!TOKEN });
  try {
    if (p === '/ai' && req.method === 'POST') {
      if (!KEY) return send(res, 503, { error: { message: 'The Bridge has no ANTHROPIC_API_KEY set.' } });
      const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': KEY, 'anthropic-version': '2023-06-01' }, body: JSON.stringify(await body(req)) });
      return send(res, r.status, await r.json());
    }
    if (p.startsWith('/store/')) {
      const name = p.slice(7).replace(/[^A-Za-z0-9_-]/g, ''), f = path.join(DATA, name + '.json'); if (!name) return send(res, 400, { error: 'Bad key' });
      if (req.method === 'GET') return fs.existsSync(f) ? send(res, 200, { value: fs.readFileSync(f, 'utf8'), version: fs.statSync(f).mtimeMs }) : send(res, 404, { error: 'Not found' });
      if (req.method === 'PUT') { const b = await body(req); if (b.expect && fs.existsSync(f) && fs.statSync(f).mtimeMs !== b.expect) return send(res, 409, { error: 'Someone else saved first. Reload and retry.', version: fs.statSync(f).mtimeMs }); fs.writeFileSync(f, b.value); return send(res, 200, { ok: true, version: fs.statSync(f).mtimeMs }); }
    }
    if (p === '/mail' && req.method === 'POST') {
      if (!mailer) return send(res, 501, { error: 'SMTP is not configured on the Bridge (install nodemailer and set SMTP_HOST, SMTP_USER, SMTP_PASS).' });
      const m = await body(req); await mailer.sendMail({ from: process.env.SMTP_FROM || process.env.SMTP_USER, to: m.to, cc: m.cc, subject: m.subject, text: m.body, attachments: (m.attachments || []).map(a => ({ filename: a.name, content: Buffer.from(a.base64, 'base64'), contentType: a.mime })) });
      return send(res, 200, { ok: true });
    }
    send(res, 404, { error: 'Unknown route' });
  } catch (e) { send(res, 500, { error: e.message }); }
}).listen(PORT, () => console.log('Arthos Bridge on http://localhost:' + PORT + (TOKEN ? ' (token required)' : ' (no token set: use only on a trusted network)') + ' | AI ' + (KEY ? 'on' : 'off') + ' | mail ' + (mailer ? 'on' : 'off')));
