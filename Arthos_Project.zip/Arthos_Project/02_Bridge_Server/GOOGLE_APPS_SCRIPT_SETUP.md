# Google Apps Script bridge for Arthos.AI

This bridge keeps your Gemini API key off the computer and sends email with attachments from your own Gmail. You don't need a server.

## 1. Get a Gemini auth key
1. Open https://aistudio.google.com/apikey and click **Create API key**.
2. Copy the key. Current keys are **auth keys** and start with `AQ.`.
3. Old keys that start with `AIza` (standard keys) stopped working with the Gemini API in September 2026. If your key starts with `AIza`, create a new one and delete the old one.

## 2. Create the script
1. Go to https://script.google.com and click **New project**. Name it `Arthos bridge`.
2. Delete what is in `Code.gs` and paste in the whole of `Code.gs` from this folder. Save.
3. Open **Project Settings** (gear icon), then **Script properties**, and add:
   - `BRIDGE_TOKEN`: any secret word, for example `narmada-2026`
   - `GEMINI_API_KEY`: your `AQ.` key (leave this out if you only want email)
   - `GEMINI_MODEL` (optional): for example `gemini-3.8-flash`
4. In the editor, choose `testGemini` and click **Run**. Allow the permissions it asks for. **Execution log** should show a reply containing `Connected`.

## 3. Deploy
1. Click **Deploy**, then **New deployment**, then **Web app**.
2. Set **Execute as** to *Me* and **Who has access** to *Anyone*.
3. Copy the web app URL. It ends in `/exec`.

## 4. Connect Arthos
1. In Arthos, open **Settings**, then **AI and email connections**.
2. Set **Bridge type** to **Google Apps Script**.
3. Paste the URL, type the same token, and click **Save and test bridge**.
4. To keep the key only in the script, leave the **Gemini API key** box in Arthos empty and choose **Google Gemini** as the AI provider.

After you edit the script, deploy a new version: **Deploy**, **Manage deployments**, edit, then **New version**.

## Models
| Model ID | Use |
|---|---|
| `gemini-3.8-flash` | Default. Best quality |
| `gemini-3.5-flash-lite` | Fastest and cheapest |
| `gemini-3.7-flash`, `gemini-3.6-flash`, `gemini-3.5-flash`, `gemini-3.1-flash-lite` | Alternatives |

Gemini 3.x models no longer use `temperature`, `topP` or `topK`, and `thinkingLevel` (`minimal`, `low`, `medium` or `high`) replaces `thinkingBudget`. The app and the script already follow these rules. If Google retires a model, both switch to a current one automatically.

## Errors
| Message | What to do |
|---|---|
| 401, `ACCESS_TOKEN_TYPE_UNSUPPORTED`, or "key rejected" | Create a new `AQ.` key in AI Studio. If a new key still fails, create it in a new project, as Google's forum advises. |
| 403 "unrestricted" or "standard key" | The key is an old standard key. Replace it with an auth key. |
| 404, model not found | Pick another model in Settings. The app also falls back automatically. |
| 429 | Rate limit or quota reached. Wait, or check billing in AI Studio. |
