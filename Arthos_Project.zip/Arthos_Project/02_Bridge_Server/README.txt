ARTHOS BRIDGE: setup in 2 minutes
1. Install Node.js 18 or newer on one office PC.
2. Open a terminal in this folder and run:
     Windows : set ANTHROPIC_API_KEY=sk-ant-... & set BRIDGE_TOKEN=pick-a-secret & node server.js
     Mac/Linux: ANTHROPIC_API_KEY=sk-ant-... BRIDGE_TOKEN=pick-a-secret node server.js
3. In Arthos.AI > Settings > Bridge, enter  http://<that-pc-ip>:8787  and the token.
What you get: the AI key stays on the server; AI works without a key in each browser;
real email if you also run  npm i nodemailer  and set SMTP_HOST, SMTP_USER, SMTP_PASS (SMTP_FROM, SMTP_PORT optional).
Limits (honest): permissions are still enforced in the browser, not on the server, and
the shared-storage endpoint exists but Arthos.AI does not sync workspaces through it yet.

Google Apps Script option (no server): see GOOGLE_APPS_SCRIPT_SETUP.md and Code.gs in this folder.
Gemini keys: use an auth key from aistudio.google.com/apikey (starts with "AQ."). Old "AIza" keys no longer work with Gemini.
