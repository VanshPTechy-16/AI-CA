/**
 * Arthos.AI bridge for Google Apps Script (no server needed).
 * - Keeps your Gemini API key on Google's side instead of in the browser.
 * - Sends email with attachments from your own Gmail.
 *
 * Gemini authentication (2026): use an AUTH KEY from https://aistudio.google.com/apikey (starts with "AQ.").
 * Old "AIza" standard keys are rejected by the Gemini API since September 2026.
 * The key is sent in the x-goog-api-key header, never in the URL.
 *
 * Setup: see GOOGLE_APPS_SCRIPT_SETUP.md in this folder.
 * Script properties (Project Settings > Script properties):
 *   GEMINI_API_KEY  your AQ. auth key (optional; leave out if you only want email)
 *   BRIDGE_TOKEN    any secret word; type the same word in Arthos Settings
 *   GEMINI_MODEL    optional default model, e.g. gemini-3.8-flash
 */
var DEFAULT_MODEL = 'gemini-3.8-flash';
var FALLBACK_MODEL = 'gemini-3.5-flash-lite';

function doGet() { return json_({ ok: true, app: 'Arthos bridge', hint: 'POST from Arthos.AI Settings.' }); }

function doPost(e) {
  try {
    var req = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    var props = PropertiesService.getScriptProperties();
    var token = props.getProperty('BRIDGE_TOKEN') || '';
    if (!token || req.token !== token) return json_({ ok: false, error: 'Bridge token does not match. Use the same word in the script properties and in Arthos Settings.' });
    if (req.action === 'ping') return json_({ ok: true, ai: !!props.getProperty('GEMINI_API_KEY'), mail: true, quota: MailApp.getRemainingDailyQuota(), user: Session.getEffectiveUser().getEmail() });
    if (req.action === 'ai') return json_({ ok: true, data: gemini_(req.model, req.body, props) });
    if (req.action === 'mail') return json_(mail_(req));
    return json_({ ok: false, error: 'Unknown action: ' + req.action });
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err) });
  }
}

function gemini_(model, body, props) {
  var key = (props.getProperty('GEMINI_API_KEY') || '').trim();
  if (!key) throw new Error('No GEMINI_API_KEY in the script properties.');
  if (/^AIza/.test(key)) throw new Error('GEMINI_API_KEY is an old AIza key. Create a new auth key (starts with AQ.) at aistudio.google.com/apikey.');
  model = String(model || props.getProperty('GEMINI_MODEL') || DEFAULT_MODEL);
  if (/^gemini-(1\.|2\.)/.test(model)) model = DEFAULT_MODEL;
  body = clean_(body || {});
  var d = post_(model, body, key);
  if (d.error && d.error.code === 404 && model !== FALLBACK_MODEL) d = post_(FALLBACK_MODEL, body, key);
  return d;   // Arthos reads candidates / error from this
}

/* Gemini 3.x rules: no temperature/topP/topK/candidateCount, thinkingLevel instead of thinkingBudget, no trailing model turn. */
function clean_(body) {
  var g = body.generationConfig || {};
  ['temperature', 'topP', 'topK', 'candidateCount', 'presencePenalty', 'frequencyPenalty'].forEach(function (k) { delete g[k]; });
  if (g.thinkingConfig && g.thinkingConfig.thinkingBudget !== undefined) { delete g.thinkingConfig.thinkingBudget; if (!g.thinkingConfig.thinkingLevel) g.thinkingConfig.thinkingLevel = 'low'; }
  body.generationConfig = g;
  var c = body.contents || [];
  while (c.length && c[c.length - 1].role === 'model') c.pop();
  body.contents = c;
  return body;
}

function post_(model, body, key) {
  var res = UrlFetchApp.fetch('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(model) + ':generateContent', {
    method: 'post', contentType: 'application/json', muteHttpExceptions: true,
    headers: { 'x-goog-api-key': key },
    payload: JSON.stringify(body)
  });
  var d; try { d = JSON.parse(res.getContentText()); } catch (x) { d = {}; }
  if (res.getResponseCode() >= 300 && !d.error) d.error = { code: res.getResponseCode(), message: 'Gemini returned status ' + res.getResponseCode() };
  if (d.error && !d.error.code) d.error.code = res.getResponseCode();
  return d;
}

function mail_(req) {
  if (!req.to) return { ok: false, error: 'No recipient.' };
  var atts = (req.attachments || []).map(function (a) { return Utilities.newBlob(Utilities.base64Decode(a.base64), a.mime || 'application/octet-stream', a.name || 'attachment'); });
  GmailApp.sendEmail(req.to, req.subject || '(no subject)', req.body || '', { cc: req.cc || '', attachments: atts, name: req.fromName || 'Arthos.AI' });
  return { ok: true, sent: true, quota: MailApp.getRemainingDailyQuota() };
}

function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

/* Run this once from the editor to check your key: View > Logs shows the answer. */
function testGemini() {
  var d = gemini_(null, { contents: [{ role: 'user', parts: [{ text: 'Reply with exactly one word: Connected' }] }], generationConfig: { thinkingConfig: { thinkingLevel: 'minimal' } } }, PropertiesService.getScriptProperties());
  Logger.log(JSON.stringify(d).slice(0, 800));
}
