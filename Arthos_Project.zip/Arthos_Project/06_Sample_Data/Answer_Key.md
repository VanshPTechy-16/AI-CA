# Answer key: planted issues

Company: Narmada Polymers Pvt Ltd
Generated: 30 Oct 2026 by Arthos.AI

Keep this away from anyone being tested.

## Vendor master

- **V007**: GSTIN check character is wrong (typo). Validator must reject it.
- **V012**: Declared Micro enterprise but no Udyam registration number.
- **V015**: Constitution says Private Limited but the PAN 4th character is P (individual).
- **V019**: Duplicate of V004: same PAN and GSTIN, name written differently.
- **V023**: Marked as GST Regular but GSTIN is missing.
- **V026**: Shares a bank account with V009, a classic fictitious-vendor red flag.

## Customer master

- **C008**: State says Gujarat but GSTIN state code says otherwise. Wrong place of supply means wrong IGST/CGST split.
- **C017**: GSTIN has only 14 characters.
- **C021**: Credit limit is zero, so any sale breaches it. Needs an approval rule.

## Bank statement

- **09/04/26 ACCOUNT MAINTENANCE CHARGES INCL GST**: Bank charges not recorded in books.
- **16/05/26 CHQ RETURN-INSUFFICIENT FUNDS-CHQ 004512**: Cheque 004512 from C004 returned unpaid. The receipt in books must be reversed.
- **16/05/26 CHQ RTN CHGS INCL GST**: Cheque return charges not recorded in books.
- **30/06/26 INT.PD 2026-06 TO 2026-06**: Interest credited by the bank, not recorded in books.
- **18/07/26 NEFT CR-UNKNOWN REMITTER-REF 247290435**: Receipt from an unidentified remitter. Must not be credited to income without investigation.
- **30/09/26 INT.PD 2026-09 TO 2026-09**: Interest credited by the bank, not recorded in books.

## Users and roles

- **Vikram Joshi**: Vikram holds create and approve on purchases and journals: segregation-of-duties conflict.
- **Pooja Desai**: Pooja left in August but her login is still enabled and was used after she left.
- **Accounts Team**: Generic shared login: actions cannot be traced to a person.

## Books of account

- Duplicate bill and payment: V011 invoice INV-2231 entered twice (as "INV 2231") and paid twice.
- Split purchases: four bills of about ₹49,000 from V015 within 4 days, just under the ₹50,000 approval limit.
- Suspense: ₹38,500 paid to an unidentified beneficiary and parked in Suspense A/c.
- Large round-sum cash withdrawal of ₹6,00,000 on a Sunday, maker and checker the same person.
- Twelve cash payments between ₹9,200 and ₹9,950, just under the ₹10,000 cash limit (Benford test will flag digit 9).
- Round-sum manual journal of ₹24,00,000 crediting Sales on the last day of the month, posted at 23:41 and self-approved.
- Prepaid insurance of ₹1,44,000 never amortised to expense.
- Timing items: a ₹1,25,000 cheque issued and a ₹2,10,000 cheque deposited in the last days, not yet in the bank statement (appear in the reconciliation statement).
- Payment to blocked vendor V028.
- Fixed asset FA006 put to use after 28 September: under 180 days, so Income Tax depreciation is at half rate.
- Customer C008 state differs from GSTIN state code; C021 has a zero credit limit; C012 has old unpaid invoices; V002 and V003 bills carry no TDS.
- Depreciation not posted for the latest closed month, and no accrual or tax provision journals exist.
- Four payments above ₹60,000 approved by the same person who prepared them.
- Three purchase bills entered more than 25 days after their bill date; three sales invoices entered after 11 pm.
- Sales invoice numbering has a gap at 22 (one number skipped).
- 3-way match: PO 003 rate is 8% lower than the bill; PO 005 goods received are 10% fewer than billed.
- Stock count: PP copolymer physical quantity is 6% below book; masterbatch batch has expired.

## GSTR-2B sample

Every 11th bill is missing from 2B, every 13th differs by 10%, every 7th has its invoice number written without hyphens (should still match), and two invoices appear in 2B that are not in books.

## Where each is caught

- Bank reconciliation: bank-only rows, cheque return, unidentified receipt, charges, interest
- Duplicate watch and Risk: V011 duplicate, V015 split bills, self-approved payments, weekend cash withdrawal, round-sum journal
- Tax alerts: V002/V003 TDS, rent TDS, MSME 43B(h), cash below limit
- Month-end close: depreciation, prepaid, suspense, tax provision
- Controls & RCM: exceptions listed per control
