/* ===================== HARDENING & AUDIT FIXES ===================== */
CONFIG.idleMinutes = 15;
(() => { const st = document.createElement('style'); st.textContent = `.bell{position:relative}.bell .badge{position:absolute;top:1px;right:1px;min-width:16px;height:16px;border-radius:99px;background:var(--red);color:var(--on-red);font-size:10px;font-weight:700;display:grid;place-items:center;padding:0 4px}.tbl-tools{display:flex;gap:8px;align-items:center;margin:0 0 8px}.tbl-tools input{max-width:260px;height:32px}table.t th[data-sortable]{cursor:pointer;user-select:none}table.t th[data-sortable]:hover{color:var(--ink)}.tool-bar{margin-bottom:14px;display:flex;gap:8px;align-items:center;flex-wrap:wrap}`; document.head.appendChild(st); })();

/* ---------- Idle auto-lock and unsaved-change guard ---------- */
(() => {
  let t = null, last = 0;
  const arm = force => { const n = Date.now(); if (force !== true && n - last < 1500 && t) return; last = n; clearTimeout(t); if (!App.session.userId) return; t = setTimeout(() => { if (App.session.userId) { Actions.lock(); UI.toast('Locked after ' + ((App.core.settings.idleMin || CONFIG.idleMinutes)) + ' minutes of inactivity.'); } }, (App.core.settings.idleMin || CONFIG.idleMinutes) * 60000); };
  ['click', 'keydown', 'mousemove', 'touchstart', 'scroll'].forEach(e => document.addEventListener(e, arm, { passive: true, capture: true }));
  window.addEventListener('beforeunload', e => { if (Object.keys(Store.timers || {}).length) { e.preventDefault(); e.returnValue = ''; } });
  window.__idleArm = arm;
})();
Changes['idle-min'] = el => { const v = Math.max(1, Math.min(240, +el.value || 15)); App.core.settings.idleMin = v; App.saveCore(); Log.add('Auto-lock changed', v + ' minutes'); UI.toast('Auto-lock after ' + v + ' minutes.', 'good'); window.__idleArm(true); };

/* ---------- Notification centre ---------- */
const Notif = {
  items() {
    const out = [], b = Books.cur(), add = (sev, t, go) => out.push({ sev, t, go }), tryit = f => { try { f(); } catch (e) { /* skip */ } };
    tryit(() => { const p = b.vouchers.filter(v => v.status === 'pending'); if (p.length) add('warn', p.length + ' voucher(s) waiting for approval', 'approvals'); });
    tryit(() => { const h = Compliance.health(App.company); if (h.overdue.length) add('bad', h.overdue.length + ' compliance item(s) overdue', 'calendar'); if (h.soon.length) add('warn', h.soon.length + ' compliance item(s) due in the next 15 days', 'calendar'); });
    tryit(() => { if (b.bankStmt && b.bankStmt.rows.length < 3000) { const r = BankRec.run(); const n = r.ub.length + r.sugg.length; if (n) add('warn', n + ' bank item(s) need reconciliation', 'bankrec'); } });
    tryit(() => { const low = b.items.filter(i => { const q = i.opQty + sum((b.moves || []).filter(m => m.item === i.id), m => m.type === 'IN' ? m.qty : -m.qty); return i.reorder && q < i.reorder; }); if (low.length) add('warn', low.length + ' stock item(s) below reorder level', 'inventory'); });
    tryit(() => { if (b.vouchers.length < 3000) { const r = AR.risk().filter(x => /high|critical/i.test(x.level || '')); if (r.length) add('bad', r.length + ' customer(s) at high receivable risk', 'o2c'); } });
    tryit(() => { if (b.vouchers.length && !b.controls.lockDate) add('info', 'No accounting period is locked yet', 'ctl'); });
    tryit(() => { const lb = App.core.settings.lastBackup; if (!lb || (Date.now() - new Date(lb)) / DAY > 7) add('info', 'No backup in the last 7 days', 'settings'); });
    return out;
  },
  mount() { const host = $('.top-actions'); if (!host || host.querySelector('.bell')) return; host.insertAdjacentHTML('afterbegin', `<button class="icon-btn bell" data-act="notif" aria-label="Notifications">${icon('alert')}<span class="badge" hidden></span></button>`); this.refresh(); },
  refresh() { const bd = $('.bell .badge'); if (!bd) return; const n = this.items().filter(i => i.sev !== 'info').length; bd.hidden = !n; bd.textContent = n > 9 ? '9+' : n; }
};
Actions.notif = () => { const it = Notif.items(); UI.modal({ title: 'Notifications', body: it.length ? `<ul class="list">${it.map(i => `<li><div class="what"><b>${esc(i.t)}</b></div><span class="chip ${i.sev === 'bad' ? 'bad' : i.sev === 'warn' ? 'warn' : 'info'}">${i.sev === 'bad' ? 'Urgent' : i.sev === 'warn' ? 'Action' : 'Note'}</span><button class="btn sm" data-act="go" data-arg="${i.go}" data-close-modal>Open</button></li>`).join('')}</ul><p class="muted small" style="margin-top:10px">Computed live from your books and due dates. External notifications are never sent unless you send an email yourself.</p>` : '<div class="empty"><b>All clear</b>Nothing needs attention right now.</div>', actions: [{ label: 'Close', kind: 'primary' }] }); };
document.addEventListener('click', e => { if (e.target.closest('[data-close-modal]')) { const c = $('#modal-root [data-close]'); if (c) setTimeout(() => c.click(), 0); } });
(() => { const base = renderShell; renderShell = function () { base(); Notif.mount(); }; })();

/* ---------- Command palette with record search ---------- */
openPalette = function () {
  const b = Books.cur(), base = [
    ...MODULES.filter(m => App.can(m.perm, 'view')).map(m => ({ label: m.title, group: m.group, icon: m.icon, run: () => Router.go(m.id) })),
    { label: 'Open AI Copilot', group: 'Action', icon: 'sparkle', run: () => Copilot.toggle(true) }, { label: 'Compose email', group: 'Action', icon: 'mail', run: () => composeEmail() },
    { label: 'Notifications', group: 'Action', icon: 'alert', run: () => Actions.notif() }, { label: 'Run data integrity check', group: 'Action', icon: 'shield', run: () => Actions.integrity() }, { label: 'Run calculation self-test', group: 'Action', icon: 'checklist', run: () => Actions.selftest() },
    { label: 'Switch light or dark theme', group: 'Action', icon: 'moon', run: () => Actions.theme() }, { label: 'Next colour style', group: 'Action', icon: 'sparkle', run: () => Actions['skin-next']() },
    { label: 'Verify audit trail', group: 'Action', icon: 'shield', run: () => { Router.go('log'); Actions['log-verify'](); } }, { label: 'Export backup', group: 'Action', icon: 'download', run: () => Actions['backup-export']() }, { label: 'Lock screen', group: 'Action', icon: 'lock', run: () => Actions.lock() }];
  const root = $('#modal-root');
  root.innerHTML = `<div class="scrim"><div class="palette" role="dialog" aria-modal="true" aria-label="Command palette"><input type="search" id="pal-in" placeholder="Jump to a module, or search vouchers, parties and ledgers…" aria-label="Search"><ul id="pal-list" role="listbox"></ul></div></div>`;
  let sel = 0, shown = base;
  const records = q => {
    if (q.length < 2 || !b.vouchers.length) return []; const out = [], has = s => String(s || '').toLowerCase().includes(q);
    b.parties.filter(p => has(p.name) || has(p.id) || has(p.gstin) || has(p.pan)).slice(0, 6).forEach(p => out.push({ label: p.name + ' (' + p.id + ')', group: p.kind === 'V' ? 'Vendor' : 'Customer', icon: 'users', run: () => Actions['open-ledger'](p.id) }));
    b.accounts.filter(a => !a.party && has(a.name)).slice(0, 5).forEach(a => out.push({ label: a.name, group: 'Ledger', icon: 'book', run: () => Actions['open-ledger'](a.id) }));
    b.vouchers.filter(v => has(v.no) || has(v.narr) || has(v.ref) || has(v.meta && v.meta.billNo) || has(String(Books.amt(v)))).slice(0, 8).forEach(v => out.push({ label: v.no + ' · ' + String(v.narr).slice(0, 44) + ' · ' + fmtINR(Books.amt(v)), group: 'Voucher', icon: 'file', run: () => Actions['v-view'](v.id) }));
    return out;
  };
  const draw = () => { $('#pal-list').innerHTML = shown.length ? shown.map((it, i) => `<li role="option" aria-selected="${i === sel}" class="${i === sel ? 'sel' : ''}" data-i="${i}">${icon(it.icon)}<span>${esc(it.label)}</span><span class="grp">${esc(it.group)}</span></li>`).join('') : '<li class="muted">No matches</li>'; const s = $('#pal-list .sel'); s && s.scrollIntoView && s.scrollIntoView({ block: 'nearest' }); };
  const close = () => { root.innerHTML = ''; document.removeEventListener('keydown', key); };
  const run = i => { const it = shown[i]; close(); it && it.run(); };
  const key = e => { if (e.key === 'Escape') close(); else if (e.key === 'ArrowDown') { sel = Math.min(shown.length - 1, sel + 1); draw(); e.preventDefault(); } else if (e.key === 'ArrowUp') { sel = Math.max(0, sel - 1); draw(); e.preventDefault(); } else if (e.key === 'Enter') { run(sel); e.preventDefault(); } };
  document.addEventListener('keydown', key);
  $('#pal-in').addEventListener('input', e => { const q = e.target.value.toLowerCase().trim(); shown = [...base.filter(it => (it.label + ' ' + it.group).toLowerCase().includes(q)), ...records(q)]; sel = 0; draw(); });
  $('#pal-list').addEventListener('click', e => { const li = e.target.closest('[data-i]'); if (li) run(+li.dataset.i); });
  root.querySelector('.scrim').addEventListener('mousedown', e => { if (e.target.classList.contains('scrim')) close(); });
  draw(); $('#pal-in').focus();
};

/* ---------- Data integrity check ---------- */
const Integrity = {
  async run() {
    const b = Books.cur(), fy = App.session.fy || fyNow(), R = [], add = (name, ok, detail, warn) => R.push({ name, ok, detail, warn: !!warn }), ids = new Set(b.accounts.map(a => a.id));
    const unb = b.vouchers.filter(v => Math.abs(sum(v.lines, l => (l.dr || 0) - (l.cr || 0))) > 0.005); add('Every voucher balances (debits = credits)', !unb.length, unb.length ? unb.length + ' unbalanced: ' + unb.slice(0, 3).map(v => v.no).join(', ') : b.vouchers.length + ' vouchers checked');
    const orph = b.vouchers.filter(v => v.lines.some(l => !ids.has(l.acc))); add('No voucher line points to a missing ledger', !orph.length, orph.length ? orph.length + ' voucher(s): ' + orph.slice(0, 3).map(v => v.no).join(', ') : 'All ledger references resolve');
    const nos = {}; b.vouchers.forEach(v => { nos[v.no] = (nos[v.no] || 0) + 1; }); const dn = Object.entries(nos).filter(([, n]) => n > 1); add('Voucher numbers are unique', !dn.length, dn.length ? dn.length + ' duplicated: ' + dn.slice(0, 3).map(x => x[0]).join(', ') : 'No duplicates');
    const pa = b.parties.filter(p => !ids.has(p.id)); add('Every party has a ledger account', !pa.length, pa.length ? pa.length + ' parties without an account' : b.parties.length + ' parties linked');
    const mp = b.vouchers.filter(v => v.meta && v.meta.party && !b.parties.some(p => p.id === v.meta.party)); add('Voucher party references exist', !mp.length, mp.length ? mp.length + ' vouchers point to a missing party' : 'All party references resolve');
    const mt = b.vouchers.filter(v => (v.type === 'Sales' || v.type === 'Purchase') && v.status === 'posted' && v.meta && v.meta.total && Math.abs(v.meta.total - (v.type === 'Sales' ? sum(v.lines.filter(l => l.acc === v.meta.party), l => l.dr || 0) : sum(v.lines.filter(l => l.acc === v.meta.party), l => l.cr || 0) + (v.meta.tds || 0))) > 0.05); add('Invoice and bill totals agree with their ledger lines', !mt.length, mt.length ? mt.length + ' mismatch(es): ' + mt.slice(0, 3).map(v => v.no).join(', ') : 'Totals agree');
    try { const tb = Rep.trial(fy).reduce((s, x) => s + x.close, 0), bs = Rep.bs(fy), cf = Rep.cf(fy); add('Trial balance nets to zero', Math.abs(tb) < 0.01, 'Difference ' + fmt2(Math.abs(tb) < 0.005 ? 0 : tb)); add('Balance sheet balances', Math.abs(bs.diff) < 0.01, 'Difference ' + fmt2(Math.abs(bs.diff) < 0.005 ? 0 : bs.diff)); add('Cash flow reconciles to cash and bank', Math.abs(cf.diff) < 0.01, 'Difference ' + fmt2(Math.abs(cf.diff) < 0.005 ? 0 : cf.diff)); } catch (e) { add('Statements can be built', false, e.message); }
    try { const neg = ['cash', 'bank'].map(a => ({ a, v: Rep.bucketsAt ? 0 : 0 })); void neg; const bal = id => { const acc = impAcc(b, id); let x = acc ? acc.op || 0 : 0; Books.posted().forEach(v => v.lines.forEach(l => { if (l.acc === id) x += (l.dr || 0) - (l.cr || 0); })); return x; }; const c = bal('cash'), k = bal('bank'); add('Cash and bank balances are not negative', c >= -0.005 && k >= -0.005, 'Cash ' + fmtINR(c) + ', bank ' + fmtINR(k), true); } catch (e) { /* skip */ }
    const neg = b.items.filter(i => i.opQty + sum((b.moves || []).filter(m => m.item === i.id), m => m.type === 'IN' ? m.qty : -m.qty) < 0); add('No stock item is negative', !neg.length, neg.length ? neg.map(i => i.name).join(', ') : b.items.length + ' items checked', true);
    const pan = {}; b.parties.filter(p => p.kind === 'V' && p.pan).forEach(p => { (pan[p.pan] = pan[p.pan] || []).push(p.id); }); const dp = Object.values(pan).filter(a => a.length > 1); add('No two vendors share a PAN', !dp.length, dp.length ? dp.map(a => a.join(' & ')).join('; ') : 'PANs are unique', true);
    const inv = b.vouchers.filter(v => v.type === 'Sales').map(v => parseInt(String(v.no).split('/').pop(), 10)).filter(n => n).sort((x, y) => x - y); let gaps = 0; for (let i = 1; i < inv.length; i++) gaps += inv[i] - inv[i - 1] - 1; add('Sales invoice numbers have no gaps', !gaps, gaps ? gaps + ' number(s) missing in the sequence' : 'Sequence is continuous', true);
    try { const c = await Log.verify(); add('Audit trail chain is intact', c.ok, c.ok ? c.count + ' entries verified' : 'Broken at entry ' + c.at); } catch (e) { add('Audit trail chain is intact', false, e.message); }
    return R;
  }
};
Actions.integrity = async () => {
  const R = await Integrity.run(), bad = R.filter(r => !r.ok && !r.warn).length, warn = R.filter(r => !r.ok && r.warn).length;
  UI.modal({ title: 'Data integrity check', wide: true, body: `<div class="note ${bad ? 'bad' : warn ? 'warn' : 'good'}" style="margin-bottom:12px"><b>${bad ? bad + ' failure(s)' : 'No failures'}</b>${warn ? ', ' + warn + ' warning(s)' : ''}. Checked ${R.length} rules across vouchers, ledgers, parties, statements, stock and the audit trail.</div><div class="table-wrap"><table class="t"><tbody>${R.map(r => `<tr><td style="width:90px"><span class="chip ${r.ok ? 'good' : r.warn ? 'warn' : 'bad'}">${r.ok ? 'Pass' : r.warn ? 'Warning' : 'Fail'}</span></td><td>${esc(r.name)}</td><td class="small muted">${esc(r.detail)}</td></tr>`).join('')}</tbody></table></div>`, actions: [{ label: 'Close', kind: 'primary' }] });
  Log.add('Data integrity check run', bad + ' failures, ' + warn + ' warnings');
};

/* ---------- In-app calculation self-test ---------- */
const SelfTest = {
  run() {
    const R = [], t = (name, got, exp, tol = 0.5) => R.push({ name, got, exp, ok: Math.abs(got - exp) <= tol }), IT = (g, r, x = {}) => IncomeTax.compute({ gross: g, regime: r, ...x }).total;
    t('New regime, ₹12.75L salary: nil after 87A rebate', IT(1275000, 'new'), 0, 0); t('New regime, ₹13L: marginal relief', IT(1300000, 'new'), 26000, 1); t('New regime, ₹20L', IT(2000000, 'new'), 192400, 1);
    t('Old regime, ₹15L with ₹1.5L under 80C', IT(1500000, 'old', { c80: 150000 }), 210600, 1); t('Old regime, taxable ₹5L: rebate to nil', IT(550000, 'old'), 0, 0); t('Old regime, ₹8L', IT(800000, 'old'), 65000, 1);
    const p = Payroll.calc({ id: 'x', gross: 20000, basicPct: 50, regime: 'new' }, '2026-10', null, '24'), q = Payroll.calc({ id: 'y', gross: 60000, basicPct: 50, regime: 'new' }, '2026-10', null, '24');
    t('PF employee 12% of ₹10,000 basic', p.ee, 1200, .01); t('ESI employee 0.75% of ₹20,000', p.esiEE, 150, 1); t('ESI employer 3.25% of ₹20,000', p.esiER, 650, 1); t('Professional tax, Gujarat, ₹20,000', p.pt, 200, 0); t('PF capped at ₹15,000 wage ceiling', q.ee, 1800, .01); t('No ESI above ₹21,000', q.esiEE, 0, 0);
    t('TDS 194C, individual PAN: 1%', TaxAlerts.rate('194C', 'ABCPE1234F'), 1, 0); t('TDS 194C, company PAN: 2%', TaxAlerts.rate('194C', 'ABCCE1234F'), 2, 0); t('TDS 194J: 10%', TaxAlerts.rate('194J', 'ABCCE1234F'), 10, 0); t('TDS 194I rent: 10%', TaxAlerts.rate('194I', 'ABCCE1234F'), 10, 0); t('TDS with no PAN: 20% (s.206AA)', TaxAlerts.rate('194J', ''), 20, 0);
    t('GSTIN with correct check character accepted', GST.validate(GST.make('24', 'AAACN1234A')).ok ? 1 : 0, 1, 0); t('GSTIN with wrong check character rejected', GST.validate('24AAACN1234A1Z5').ok ? 1 : 0, 0, 0);
    t('Depreciation, ₹10L plant, 15 years, 5% residual', FA.annual({ cost: 1000000, cls: 'pm' }), 63333.33, 1); t('Part-year depreciation (used from 1 Oct)', FA.dep({ cost: 1000000, cls: 'pm', use: '2026-10-01' }, '2026-04-01', '2027-03-31'), 63333.33 * 182 / 365, 60);
    if (hasBooks()) { const fy = App.session.fy || fyNow(); t('Books: trial balance nets to zero', Rep.trial(fy).reduce((s, x) => s + x.close, 0), 0, .01); t('Books: balance sheet balances', Rep.bs(fy).diff, 0, .01); t('Books: cash flow reconciles', Rep.cf(fy).diff, 0, .01); t('Books: unbalanced vouchers', Books.cur().vouchers.filter(v => Math.abs(sum(v.lines, l => (l.dr || 0) - (l.cr || 0))) > 0.005).length, 0, 0); if (Books.cur().bankStmt) t('Books: bank reconciliation proves out', BankRec.run().brs.diff, 0, .01); }
    return R;
  }
};
Actions.selftest = () => { const R = SelfTest.run(), f = R.filter(r => !r.ok).length; UI.modal({ title: 'Calculation self-test', wide: true, body: `<div class="note ${f ? 'bad' : 'good'}" style="margin-bottom:12px"><b>${R.length - f} of ${R.length} checks pass.</b> Each case is worked out by hand from the law (rates as of ${esc(CONFIG.lawAsOf)}). Re-run after you edit any rate in CONFIG.</div><div class="table-wrap"><table class="t"><thead><tr><th></th><th>Case</th><th class="amt">Expected</th><th class="amt">Got</th></tr></thead><tbody>${R.map(r => `<tr><td><span class="chip ${r.ok ? 'good' : 'bad'}">${r.ok ? 'Pass' : 'Fail'}</span></td><td>${esc(r.name)}</td><td class="amt">${fmt2(r.exp)}</td><td class="amt">${fmt2(r.got)}</td></tr>`).join('')}</tbody></table></div>`, actions: [{ label: 'Close', kind: 'primary' }] }); Log.add('Self-test run', (R.length - f) + '/' + R.length + ' pass'); };

/* ---------- New ledger ---------- */
const SCH_LBL = { nca_ppe: 'Property, plant and equipment', nca_oth: 'Other non-current assets', ca_inv: 'Inventories', ca_rec: 'Trade receivables', ca_cash: 'Cash and cash equivalents', ca_loans: 'Short-term loans and advances', ca_oth: 'Other current assets', eq_cap: 'Share capital', eq_res: 'Reserves and surplus', ncl_borrow: 'Long-term borrowings', ncl_prov: 'Long-term provisions', cl_borrow: 'Short-term borrowings', cl_pay: 'Trade payables', cl_oth: 'Other current liabilities', cl_prov: 'Short-term provisions', rev_ops: 'Revenue from operations', rev_oth: 'Other income', exp_cogs: 'Cost of materials / purchases', exp_inv: 'Changes in inventories', exp_emp: 'Employee benefit expense', exp_fin: 'Finance costs', exp_dep: 'Depreciation', exp_oth: 'Other expenses', exp_tax: 'Tax expense' };
const SCH_BY = { A: ['ca_oth', 'ca_cash', 'ca_rec', 'ca_inv', 'ca_loans', 'nca_ppe', 'nca_oth'], L: ['cl_oth', 'cl_pay', 'cl_borrow', 'cl_prov', 'ncl_borrow', 'ncl_prov', 'eq_cap', 'eq_res'], I: ['rev_ops', 'rev_oth'], E: ['exp_oth', 'exp_cogs', 'exp_emp', 'exp_fin', 'exp_dep', 'exp_inv', 'exp_tax'] };
Actions['acc-add'] = () => {
  if (!App.can('r2r', 'create')) { UI.toast('Your role cannot add ledgers.', 'error'); return; } const b = Books.cur(), groups = [...new Set(b.accounts.map(a => a.group))];
  UI.modal({ title: 'New ledger', body: `<div class="form-grid"><div class="field full"><label for="al-n">Ledger name</label><input id="al-n" type="text"></div><div class="field"><label for="al-nat">Nature</label><select id="al-nat"><option value="E">Expense</option><option value="I">Income</option><option value="A">Asset</option><option value="L">Liability</option></select></div><div class="field"><label for="al-g">Group</label><input id="al-g" type="text" list="al-gl" placeholder="e.g. Indirect expenses"><datalist id="al-gl">${groups.map(g => `<option value="${esc(g)}">`).join('')}</datalist></div><div class="field full"><label for="al-s">Appears in the financial statements under</label><select id="al-s"></select><span class="hint">This decides the Schedule III line the ledger rolls up to.</span></div><div id="al-err" class="err full"></div></div>`,
    onOpen: el => { const fill = () => { $('#al-s', el).innerHTML = SCH_BY[$('#al-nat', el).value].map(k => `<option value="${k}">${esc(SCH_LBL[k])}</option>`).join(''); }; $('#al-nat', el).addEventListener('change', fill); fill(); },
    actions: [{ label: 'Cancel' }, { label: 'Create ledger', kind: 'primary', onClick: el => { const n = $('#al-n', el).value.trim(), g = $('#al-g', el).value.trim() || 'Other', nat = $('#al-nat', el).value, sch = $('#al-s', el).value, err = m => { $('#al-err', el).textContent = m; return false; }; if (n.length < 2) return err('Enter a ledger name.'); if (b.accounts.some(a => a.name.toLowerCase() === n.toLowerCase())) return err('A ledger with this name already exists.'); let id = 'x_' + n.toLowerCase().replace(/[^a-z0-9]+/g, '_').slice(0, 20), k = 1; while (b.accounts.some(a => a.id === id)) id = id.replace(/_\d+$/, '') + '_' + (++k); b.accounts.push({ id, name: n, group: g, nat, sch, op: 0 }); Books.save(); Log.add('Ledger created', n + ' (' + g + ')'); UI.toast('Ledger created.', 'good'); Router.render(); } }] });
};

/* ---------- Table sort, filter and paging (all screens) ---------- */
const Tbl = {
  enhance() {
    const v = $('#view'); if (!v) return;
    $$('.table-wrap', v).forEach(w => { const t = w.querySelector('table.t'); if (!t || w.dataset.tbl) return; w.dataset.tbl = '1'; const rows = t.querySelectorAll('tbody tr'); $$('thead th', t).forEach((th, i) => { if (th.textContent.trim()) { th.dataset.sortable = i; } }); if (rows.length > 12) { w.insertAdjacentHTML('beforebegin', `<div class="tbl-tools"><input type="search" placeholder="Filter ${rows.length} rows…" aria-label="Filter table rows" data-tf><span class="muted small" data-tc></span></div>`); } });
  }
};
document.addEventListener('input', e => { const f = e.target.closest && e.target.closest('[data-tf]'); if (!f) return; const w = f.closest('.tbl-tools').nextElementSibling, q = f.value.toLowerCase().trim(); let n = 0; $$('tbody tr', w).forEach(r => { const ok = !q || r.textContent.toLowerCase().includes(q); r.style.display = ok ? '' : 'none'; if (ok) n++; }); f.closest('.tbl-tools').querySelector('[data-tc]').textContent = q ? n + ' match' + (n === 1 ? '' : 'es') : ''; });
document.addEventListener('click', e => {
  const th = e.target.closest && e.target.closest('table.t th[data-sortable]'); if (!th) return; const t = th.closest('table'), i = +th.dataset.sortable, asc = th.dataset.dir !== 'asc', body = t.tBodies[0]; if (!body) return;
  const val = r => { const s = (r.cells[i] ? r.cells[i].textContent : '').trim().replace(/[₹,\s]|Dr$|Cr$/g, ''); const n = parseFloat(s); return isNaN(n) || !/^[\-\(]?[\d.]/.test(s) ? s.toLowerCase() : n; };
  const rows = [...body.rows].sort((a, b) => { const x = val(a), y = val(b); return (typeof x === 'number' && typeof y === 'number' ? x - y : String(x).localeCompare(String(y), 'en', { numeric: true })) * (asc ? 1 : -1); });
  rows.forEach(r => body.appendChild(r)); $$('th', t).forEach(h => { h.dataset.dir = ''; h.textContent = h.textContent.replace(/ [▲▼]$/, ''); }); th.dataset.dir = asc ? 'asc' : 'desc'; th.textContent += asc ? ' ▲' : ' ▼';
});

/* ---------- Extra tool bars on selected screens ---------- */
(() => {
  const base = Router.render.bind(Router);
  Router.render = function () {
    App.ui.gridLim = App.route === App.__lastRoute ? App.ui.gridLim : 150; App.__lastRoute = App.route; base();
    try { Tbl.enhance(); Notif.refresh(); const v = $('#view'); if (!v) return; const old = v.querySelector('.tool-bar'); if (old) old.remove(); let html = '';
      if (App.route === 'ledgers' && App.can('r2r', 'create')) html = `<button class="btn sm" data-act="acc-add">${icon('plus')}New ledger</button>`;
      if (App.route === 'ctl' || App.route === 'settings') html = `<button class="btn sm primary" data-act="integrity">${icon('shield')}Run data integrity check</button><button class="btn sm" data-act="selftest">${icon('checklist')}Run calculation self-test</button>${App.route === 'settings' ? `<span class="small muted" style="margin-left:8px">Auto-lock after</span><input type="number" min="1" max="240" value="${App.core.settings.idleMin || CONFIG.idleMinutes}" data-change="idle-min" style="width:70px;height:32px" aria-label="Auto-lock minutes"><span class="small muted">minutes idle</span>` : ''}`;
      if (html) v.insertAdjacentHTML('afterbegin', `<div class="tool-bar">${html}</div>`); } catch (e) { console.error(e); }
  };
})();
Actions['grid-more'] = () => { App.ui.gridLim = (App.ui.gridLim || 150) + 200; Router.render(); };
Actions['grid-all'] = () => { App.ui.gridLim = 1e9; Router.render(); };

function pagerHTML(n) { const lim = App.ui.gridLim || 150; return `<div class="row" style="justify-content:center;padding:10px"><span class="muted small">Showing ${Math.min(lim, n)} of ${n} rows</span><button class="btn sm" data-act="grid-more">Show 200 more</button><button class="btn sm" data-act="grid-all">Show all</button></div>`; }
