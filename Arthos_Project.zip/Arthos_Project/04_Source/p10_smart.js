/* ===================== SMART IMPORT HUB, FORMATTED EXPORTS, STATEMENT ASSISTANT ===================== */
const Lazy = { _p: {}, script(url) { if (this._p[url]) return this._p[url]; return this._p[url] = new Promise((res, rej) => { const s = document.createElement('script'); s.src = url; s.onload = res; s.onerror = () => { delete this._p[url]; rej(new Error('Could not load ' + url.split('/').pop() + '. In this build the feature needs an internet connection; the offline build includes it.')); }; document.head.appendChild(s); }); } };
const NUMRE = /^[\(\-]?₹?\s?[\d,]+(\.\d+)?\)?(\s?(Dr|Cr))?$/;
const toNum = v => { if (typeof v === 'number') return v; const s = String(v ?? '').trim(); if (!NUMRE.test(s.replace(/\u00A0/g, ' '))) return null; const neg = /^\(|^-/.test(s) || /\sDr$/.test(s) && false; const n = parseFloat(s.replace(/[^\d.]/g, '')); return isNaN(n) ? null : (neg ? -n : n); };
const coLine = () => { const c = App.company; return [c.address && (c.address + (c.city ? ', ' + c.city : '') + (c.pincode ? ' - ' + c.pincode : '')), [c.gstin && 'GSTIN ' + c.gstin, c.pan && 'PAN ' + c.pan, c.cin && 'CIN ' + c.cin].filter(Boolean).join('   ')].filter(Boolean); };

/* ---------- PDF export with letterhead, rupee sign and page numbers ---------- */
const PDFX = {
  fonts(doc) { if (typeof PDF_FONTS === 'undefined') return doc; if (!doc.__f) { doc.addFileToVFS('DejaVuSans.ttf', PDF_FONTS.reg); doc.addFont('DejaVuSans.ttf', 'DejaVu', 'normal'); doc.addFileToVFS('DejaVuSans-Bold.ttf', PDF_FONTS.bold); doc.addFont('DejaVuSans-Bold.ttf', 'DejaVu', 'bold'); doc.__f = 1; } doc.setFont('DejaVu', 'normal'); return doc; },
  doc(landscape) { if (!window.jspdf || !window.jspdf.jsPDF) throw new Error('The PDF library did not load. Check your connection and reload.'); return this.fonts(new window.jspdf.jsPDF({ orientation: landscape ? 'landscape' : 'portrait', unit: 'pt', format: 'a4', compress: true })); },
  letterhead(doc, title, sub) {
    const W = doc.internal.pageSize.getWidth(), L = 40; doc.setFont('DejaVu', 'bold'); doc.setFontSize(15); doc.setTextColor(19, 33, 60); doc.text(App.company.name, L, 44); doc.setFont('DejaVu', 'normal'); doc.setFontSize(8); doc.setTextColor(90); let y = 58; coLine().forEach(t => { doc.text(t, L, y); y += 11; });
    doc.setDrawColor(19, 33, 60); doc.setLineWidth(1.2); doc.line(L, y + 2, W - L, y + 2); doc.setLineWidth(.4); doc.line(L, y + 5, W - L, y + 5); y += 24; doc.setTextColor(19, 33, 60); doc.setFont('DejaVu', 'bold'); doc.setFontSize(12.5); doc.text(title, L, y); y += 14; if (sub) { doc.setFont('DejaVu', 'normal'); doc.setFontSize(8.5); doc.setTextColor(90); doc.text(sub, L, y); y += 8; } doc.setTextColor(0); return y + 8;
  },
  footer(doc) { const n = doc.getNumberOfPages(), W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight(); for (let i = 1; i <= n; i++) { doc.setPage(i); doc.setFont('DejaVu', 'normal'); doc.setFontSize(7.5); doc.setTextColor(110); doc.setDrawColor(200); doc.line(40, H - 34, W - 40, H - 34); doc.text('Prepared on Arthos.AI. Working copy; does not replace professional judgment.', 40, H - 22); doc.text('Page ' + i + ' of ' + n, W - 40, H - 22, { align: 'right' }); } doc.setTextColor(0); },
  table(title, head, body, name, opt = {}) {
    const doc = this.doc(opt.landscape != null ? opt.landscape : head.length > 6), y = this.letterhead(doc, title, opt.sub || ('FY ' + fyLabel(App.session.fy || fyNow()) + '   |   Amounts in ₹ unless stated   |   Generated ' + fmtDate(new Date())));
    const numCol = head.map((h, i) => body.length && body.filter(r => toNum(r[i]) !== null || r[i] === '' || r[i] == null).length / body.length > .7 && body.some(r => toNum(r[i]) !== null));
    const cell = c => c == null ? '' : typeof c === 'number' ? fmt2(c) : /^-?\d{5,}\.\d+$/.test(String(c)) ? fmt2(parseFloat(c)) : String(c);
    doc.autoTable({ head: [head.map(String)], body: body.map(r => r.map(cell)), startY: y, theme: 'grid', margin: { left: 40, right: 40, bottom: 44 }, styles: { font: 'DejaVu', fontSize: 8, cellPadding: 3.5, lineColor: [215, 220, 228], lineWidth: .4, textColor: [30, 38, 56] }, headStyles: { fillColor: [19, 33, 60], textColor: 255, fontStyle: 'bold', halign: 'left' }, alternateRowStyles: { fillColor: [246, 248, 251] }, columnStyles: Object.fromEntries(numCol.map((n, i) => [i, n ? { halign: 'right' } : {}]).filter(x => Object.keys(x[1]).length)), didParseCell: d => { if (d.section === 'body' && /^(total|grand total|net )/i.test(String(d.row.raw[0] || ''))) { d.cell.styles.fontStyle = 'bold'; d.cell.styles.fillColor = [233, 238, 246]; } if (d.section === 'head' && numCol[d.column.index]) d.cell.styles.halign = 'right'; } });
    this.footer(doc); if (name) Files.download(name, doc.output('blob')); return doc;
  }
};
PDF.doc = l => PDFX.doc(l); PDF.table = (t, h, b, n) => PDFX.table(t, h, b, n);

/* ---------- Excel export with real formatting (ExcelJS), falling back to plain SheetJS ---------- */
const XL = {
  async lib() { if (window.ExcelJS) return window.ExcelJS; await Lazy.script('https://cdn.jsdelivr.net/npm/exceljs@4.4.0/dist/exceljs.min.js'); return window.ExcelJS; },
  INR: '[>=10000000]##\\,##\\,##\\,##0.00;[>=100000]##\\,##\\,##0.00;##,##0.00',
  async build(sheets, opt = {}) {
    const E = await this.lib(), wb = new E.Workbook(); wb.creator = 'Arthos.AI'; wb.created = new Date(); const navy = 'FF13213C', band = 'FFF4F6FA', line = 'FFD5DAE3';
    for (const s of sheets) {
      const ws = wb.addWorksheet(String(s.name || 'Sheet').slice(0, 31), { views: [{ state: 'frozen', ySplit: 6 }], pageSetup: { orientation: s.head.length > 6 ? 'landscape' : 'portrait', fitToPage: true, fitToWidth: 1, fitToHeight: 0, paperSize: 9, margins: { left: .5, right: .5, top: .6, bottom: .7, header: .3, footer: .3 } }, headerFooter: { oddFooter: '&LPrepared on Arthos.AI&CPage &P of &N&R&D' } });
      const nc = s.head.length, last = ws.getColumn(nc).letter; ws.mergeCells('A1:' + last + '1'); ws.mergeCells('A2:' + last + '2'); ws.mergeCells('A3:' + last + '3'); ws.mergeCells('A4:' + last + '4');
      ws.getCell('A1').value = App.company.name; ws.getCell('A1').font = { name: 'Calibri', size: 16, bold: true, color: { argb: navy } };
      ws.getCell('A2').value = coLine().join('   '); ws.getCell('A2').font = { size: 9, color: { argb: 'FF5A6478' } };
      ws.getCell('A3').value = s.title || s.name; ws.getCell('A3').font = { size: 13, bold: true, color: { argb: navy } }; ws.getCell('A4').value = s.sub || ('FY ' + fyLabel(App.session.fy || fyNow()) + '   |   Generated ' + fmtDate(new Date())); ws.getCell('A4').font = { size: 9, color: { argb: 'FF5A6478' } };
      for (let c = 1; c <= nc; c++) ws.getCell(4, c).border = { bottom: { style: 'medium', color: { argb: navy } } };
      const hr = ws.getRow(6); s.head.forEach((h, i) => { const c = hr.getCell(i + 1); c.value = h; c.font = { bold: true, color: { argb: 'FFFFFFFF' } }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: navy } }; c.alignment = { vertical: 'middle', horizontal: 'left', wrapText: true }; c.border = { top: { style: 'thin', color: { argb: line } }, bottom: { style: 'thin', color: { argb: line } }, left: { style: 'thin', color: { argb: line } }, right: { style: 'thin', color: { argb: line } } }; }); hr.height = 22;
      const numCol = s.head.map((h, i) => s.body.length && s.body.some(r => toNum(r[i]) !== null) && s.body.filter(r => toNum(r[i]) !== null || r[i] === '' || r[i] == null).length / s.body.length > .7);
      s.body.forEach((r, ri) => { const row = ws.getRow(7 + ri), tot = /^(total|grand total|net )/i.test(String(r[0] || '')); r.forEach((v, i) => { const c = row.getCell(i + 1), n = numCol[i] ? toNum(v) : null; c.value = n !== null ? n : (v == null ? '' : v); if (n !== null) { c.numFmt = XL.INR; c.alignment = { horizontal: 'right' }; } else c.alignment = { vertical: 'top', wrapText: true }; c.border = { top: { style: 'hair', color: { argb: line } }, bottom: { style: 'hair', color: { argb: line } }, left: { style: 'hair', color: { argb: line } }, right: { style: 'hair', color: { argb: line } } }; if (ri % 2) c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: band } }; if (tot) { c.font = { bold: true }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE6ECF5' } }; c.border = { top: { style: 'thin', color: { argb: navy } }, bottom: { style: 'double', color: { argb: navy } } }; } }); });
      s.head.forEach((h, i) => { const w = Math.min(60, Math.max(10, String(h).length + 3, ...s.body.slice(0, 80).map(r => String(r[i] ?? '').length + 2))); ws.getColumn(i + 1).width = s.widths && s.widths[i] ? s.widths[i] : w; });
      ws.autoFilter = { from: { row: 6, column: 1 }, to: { row: 6 + s.body.length, column: nc } };
      const fr = 8 + s.body.length; ws.mergeCells(fr, 1, fr, nc); ws.getCell(fr, 1).value = 'Prepared on Arthos.AI. This working copy assists professionals and does not replace professional judgment.'; ws.getCell(fr, 1).font = { italic: true, size: 8.5, color: { argb: 'FF6B7488' } };
    }
    return wb;
  },
  async download(sheets, name) { try { const wb = await this.build(sheets), buf = await wb.xlsx.writeBuffer(); Files.download(name, new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })); } catch (e) { const plain = Object.fromEntries(sheets.map(s => [s.name.slice(0, 28), s.body.map(r => Object.fromEntries(s.head.map((h, i) => [h, r[i]])))])); Files.download(name, Files.xlsx(plain)); UI.toast('Formatted Excel needs an internet connection in this build, so a plain workbook was saved.', 'error'); } }
};
Actions.exp = async arg => {
  const [id, f] = arg.split('|'), d = Exp.reg[id]; if (!d) return; const nm = d.title.replace(/\W+/g, '_');
  try { if (f === 'pdf') PDFX.table(d.title, d.head, d.body, nm + '.pdf'); else if (f === 'csv') Files.download(nm + '.csv', Files.csv(d.body.map(r => Object.fromEntries(d.head.map((h, i) => [h, r[i]])))), 'text/csv'); else await XL.download([{ name: d.title.slice(0, 28), title: d.title, head: d.head, body: d.body }], nm + '.xlsx'); Log.add('Report exported', d.title + ' (' + f + ')'); } catch (e) { UI.toast(e.message, 'error'); }
};

/* ---------- Readers: sheets, text PDFs, scans and photos ---------- */
const Rd = {
  async pdfjs() {
    if (!window.pdfjsLib) await Lazy.script('https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.min.js');
    const L = window.pdfjsLib; if (!L.GlobalWorkerOptions.workerSrc || !this._w) { const el = document.getElementById('pdf-worker-src'); let txt = el && el.textContent; if (!txt) { const r = await fetch('https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js'); txt = await r.text(); } this._w = URL.createObjectURL(new Blob([txt], { type: 'text/javascript' })); L.GlobalWorkerOptions.workerSrc = this._w; } return L;
  },
  async pdf(file, opt = {}) {
    const L = await this.pdfjs(), doc = await L.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise, pages = [];
    for (let p = 1; p <= doc.numPages; p++) { const pg = await doc.getPage(p), c = await pg.getTextContent(), its = c.items.filter(i => i.str && i.str.trim()).map(i => ({ x: i.transform[4], y: i.transform[5], s: i.str, w: i.width })); its.sort((a, b) => b.y - a.y || a.x - b.x); const lines = []; let cur = [], ly = null; its.forEach(i => { if (ly !== null && Math.abs(i.y - ly) > 3) { lines.push(cur); cur = []; } cur.push(i); ly = i.y; }); if (cur.length) lines.push(cur);
      pages.push({ lines: lines.map(l => { l.sort((a, b) => a.x - b.x); let t = '', px = null; l.forEach(i => { if (px !== null) { const g = i.x - px; t += g > 9 ? '  ' : g > 0.5 ? ' ' : ''; } t += i.s; px = i.x + i.w; }); return t.trim(); }).filter(Boolean), page: pg }); }
    const text = pages.map(p => p.lines.join('\n')).join('\n'); return { doc, pages, text, scanned: text.replace(/\s/g, '').length < 40 * pages.length };
  },
  async b64(file, max = 1600) { return new Promise((res, rej) => { const img = new Image(), u = URL.createObjectURL(file); img.onload = () => { const k = Math.min(1, max / Math.max(img.width, img.height)), c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(u); res(c.toDataURL('image/jpeg', .88).split(',')[1]); }; img.onerror = () => { URL.revokeObjectURL(u); rej(new Error('Could not open the image.')); }; img.src = u; }); },
  async ocr(blobOrFile, hint) {
    if (AI.ready()) { try { const data = await this.b64(blobOrFile), d = await AI.call({ system: 'You are an OCR engine for Indian accounting documents. Transcribe ALL text exactly as printed, one line per row, separating table columns with two spaces. Keep amounts with commas and decimals. Do not summarise or add commentary.', messages: [{ role: 'user', content: [{ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data } }, { type: 'text', text: 'Transcribe this ' + (hint || 'document') + '.' }] }] }); return { text: AI.text(d), via: 'Claude vision' }; } catch (e) { if (!/Tesseract|offline/i.test(e.message) && !navigator.onLine === false) { /* fall through to Tesseract */ } this._aiErr = e.message; } }
    try { await Lazy.script('https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js'); const r = await window.Tesseract.recognize(blobOrFile, 'eng'); return { text: r.data.text, via: 'Tesseract OCR' }; } catch (e) { throw new Error('Could not read this image. ' + (this._aiErr ? 'AI vision: ' + this._aiErr + ' ' : '') + 'Browser OCR needs an internet connection. Use a text-based PDF or Excel instead, or connect AI in Settings.'); }
  },
  async any(file) {
    const n = file.name || 'file', ext = (n.split('.').pop() || '').toLowerCase();
    if (['xlsx', 'xls', 'csv'].includes(ext)) { const r = await Imp.read(file); return { kind: 'sheet', name: n, rows: r.rows, grid: r.grid, file }; }
    if (ext === 'json') return { kind: 'json', name: n, ...(await Imp.read(file)), file };
    if (ext === 'txt') { const t = await file.text(); return { kind: 'text', name: n, text: t, lines: t.split(/\r?\n/), via: 'text', file }; }
    if (ext === 'pdf' || file.type === 'application/pdf') { const p = await this.pdf(file); if (!p.scanned) return { kind: 'text', name: n, text: p.text, lines: p.text.split('\n'), via: 'PDF text', file, pages: p.pages.length }; let all = [], via = ''; const lim = Math.min(p.pages.length, 6); for (let i = 0; i < lim; i++) { const vp = p.pages[i].page.getViewport({ scale: 2 }), c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height; await p.pages[i].page.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise; const blob = await new Promise(r => c.toBlob(r, 'image/png')), o = await this.ocr(blob, 'page ' + (i + 1) + ' of a scanned PDF'); all.push(o.text); via = o.via; } const t = all.join('\n'); return { kind: 'text', name: n, text: t, lines: t.split(/\r?\n/), via: 'Scanned PDF read by ' + via, file, pages: p.pages.length }; }
    if (/^image\//.test(file.type) || ['png', 'jpg', 'jpeg', 'webp', 'bmp'].includes(ext)) { const o = await this.ocr(file, 'document'); return { kind: 'text', name: n, text: o.text, lines: o.text.split(/\r?\n/), via: 'Image read by ' + o.via, file }; }
    throw new Error('Unsupported file type: .' + ext + '. Use Excel, CSV, PDF, an image or JSON.');
  }
};

/* ---------- Classifier and text parsers ---------- */
const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
const DATE_RE = /(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}|\d{1,2}[ \-](?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[ \-,]*\d{2,4})/ig;
const parseDate = s => { s = String(s).trim(); let m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})$/); if (m) { let y = +m[3]; if (y < 100) y += 2000; return y + '-' + String(m[2]).padStart(2, '0') + '-' + String(m[1]).padStart(2, '0'); } m = s.match(/^(\d{1,2})[ \-]([a-z]{3})[a-z]*[ \-,]*(\d{2,4})$/i); if (m) { let y = +m[3]; if (y < 100) y += 2000; return y + '-' + String(MONTHS[m[2].toLowerCase()]).padStart(2, '0') + '-' + String(m[1]).padStart(2, '0'); } return null; };
const Cls = {
  detect(text) {
    const t = text.slice(0, 20000), lines = t.split('\n'), dated = lines.filter(l => /^\s*\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}/.test(l)).length;
    if (/narration|particulars|withdrawal|deposit|statement of account/i.test(t) && dated >= 5) return 'bank';
    if (/balance sheet|statement of profit|notes (to|forming)|cash flow statement|annual report/i.test(t) && /total assets|equity|revenue from operations/i.test(t)) return 'annual';
    if (/gstin/i.test(t) && /(tax invoice|invoice no|bill of supply|invoice number)/i.test(t)) return 'invoice';
    if (/show cause|drc-01|asmt-10|notice under section|scrutiny of returns/i.test(t)) return 'notice';
    if (dated >= 8) return 'bank'; return 'unknown';
  },
  bank(lines) {
    const rows = [], warn = []; let opening = null, prev = null; const AMT = /-?\d[\d,]*\.\d{2}\b/g;
    for (let raw of lines) {
      const line = raw.replace(/\s+/g, ' ').trim(); if (!line) continue; const om = line.match(/opening balance.*?(-?\d[\d,]*\.\d{2})/i); if (om) { opening = parseFloat(om[1].replace(/,/g, '')); prev = opening; continue; }
      const dm = [...line.matchAll(DATE_RE)]; if (!dm.length || dm[0].index > 3) { if (rows.length && !/(page \d|statement|closing|total|account|branch|ifsc|customer)/i.test(line) && !line.match(AMT)) rows[rows.length - 1].narr += ' ' + line; continue; }
      const nums = (line.match(AMT) || []).map(x => parseFloat(x.replace(/,/g, ''))); if (!nums.length) continue; let rest = line; dm.forEach(m => { rest = rest.replace(m[0], ' '); }); rest = rest.replace(AMT, ' ').replace(/\s+(Cr|Dr)\b/gi, ' ').replace(/\s+/g, ' ').trim();
      const date = parseDate(dm[0][0]); if (!date) continue; let amt, bal = null; if (nums.length >= 2) { bal = nums[nums.length - 1]; amt = nums[nums.length - 2]; } else amt = nums[0];
      let dir; if (prev !== null && bal !== null) { const dl = Math.round((bal - prev) * 100) / 100; dir = dl >= 0 ? 'in' : 'out'; if (Math.abs(Math.abs(dl) - amt) > 0.02) warn.push('Balance does not follow on ' + fmtDate(date) + ' (' + fmt2(amt) + ')'); } else dir = /\bCR\b|NEFT CR|DEPOSIT|RECEIPT/i.test(line) && !/\bDR\b/i.test(line) ? 'in' : 'out';
      const refm = rest.match(/\b(?:CHQ\s*\d{4,8}|\d{9,22}|[A-Z]{4}[A-Z0-9]?\d{8,16})\b/); if (refm && /^\d{9,22}$/.test(refm[0]) && rest.endsWith(refm[0])) rest = rest.slice(0, -refm[0].length).trim(); rows.push({ date, narr: rest, ref: refm ? refm[0].replace(/^CHQ\s*/, '') : '', w: dir === 'out' ? amt : 0, d: dir === 'in' ? amt : 0, bal: bal !== null ? bal : (prev !== null ? Math.round((prev + (dir === 'in' ? amt : -amt)) * 100) / 100 : 0) }); if (bal !== null) prev = bal; else if (prev !== null) prev = rows[rows.length - 1].bal;
    }
    if (!rows.length) throw new Error('No transactions found. The file does not look like a bank statement with dated rows.');
    if (opening === null) opening = Math.round((rows[0].bal - rows[0].d + rows[0].w) * 100) / 100; rows.forEach(r => { r.narr = r.narr.replace(/\s+/g, ' ').trim(); });
    rows.unshift({ date: rows[0].date, narr: 'OPENING BALANCE B/F', ref: '', w: 0, d: 0, bal: opening }); return { bank: 'Imported', rows, opening, closing: rows[rows.length - 1].bal, to: rows[rows.length - 1].date, warnings: warn };
  },
  invoice(text) {
    const t = text.replace(/\u00A0/g, ' '), g = [...t.matchAll(/\b\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]\b/g)].map(m => m[0]), mine = App.company.gstin;
    const pick = re => { const m = t.match(re); return m ? m[1].trim() : ''; }, amt = re => { const m = t.match(re); return m ? parseFloat(m[1].replace(/,/g, '')) : 0; };
    const invNo = pick(/(?:invoice\s*(?:no\.?|number|#)|bill\s*no\.?)\s*[:\-]?\s*([A-Z0-9\/\-]{3,20})/i), dstr = pick(/(?:invoice\s*)?date\s*[:\-]?\s*(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}|\d{1,2}[ \-][A-Za-z]{3,9}[ \-,]*\d{2,4})/i), hsn = pick(/(?:hsn\/sac|hsn|sac)\D{0,20}(\d{4,8})/i) || pick(/\b(\d{6,8})\b/);
    const taxable = amt(/taxable\s*(?:value|amount)?\D{0,12}([\d,]+\.\d{2})/i), cg = amt(/cgst[^\d]{0,14}([\d,]+\.\d{2})/i), sg = amt(/sgst[^\d]{0,14}([\d,]+\.\d{2})/i), ig = amt(/igst[^\d]{0,14}([\d,]+\.\d{2})/i), total = amt(/(?:grand\s*)?total\D{0,12}([\d,]+\.\d{2})/i), rate = taxable ? Math.round((cg + sg + ig) / taxable * 100) : 18;
    const seller = g.find(x => x !== mine) || '', buyerIsMe = mine && g.includes(mine) && (t.search(mine) > t.search(seller) || !seller), name = (t.split('\n').map(x => x.trim()).filter(x => x && !/tax invoice|gstin|invoice|date/i.test(x))[0]) || '';
    return { vendorGstin: seller, vendorName: name, invNo, date: dstr ? parseDate(dstr) : null, hsn, taxable, cgst: cg, sgst: sg, igst: ig, total: total || r2(taxable + cg + sg + ig), rate, direction: mine && g[0] === mine ? 'sales' : 'purchase', gstins: g };
  }
};

/* ---------- Suggestion engine for bank rows ---------- */
const STOP = new Set(['PVT', 'LTD', 'LLP', 'AND', 'CO', 'NEFT', 'IMPS', 'RTGS', 'UPI', 'INV', 'REF', 'THE', 'FOR', 'CHQ', 'TRF', 'TRANSFER', 'PAYMENT', 'HDFC', 'SBIN', 'ICIC', 'UTIB', 'KKBK']);
const stoks = s => String(s || '').toUpperCase().replace(/[^A-Z0-9 ]/g, ' ').split(/\s+/).filter(w => w.length >= 4 && !STOP.has(w) && !/^\d+$/.test(w) && !/^[A-Z]{4}0/.test(w));
const stem = n => stoks(n).slice(0, 2).join(' ');
const Sug = {
  row(r, b) {
    const t = r.narr.toUpperCase(), dir = r.dir, learn = (b.stmtMap || {})[stem(r.narr)];
    const mk = (acc, conf, why, extra = {}) => { const party = Books.party(acc); let type = dir === 'in' ? 'Receipt' : 'Payment'; if (extra.type) type = extra.type; return { type, acc, conf, why, party: party ? party.id : null, ...extra }; };
    const k = BankRec.classify(r); if (/CHQ RETURN|CHQ RTN/.test(t) && !/CHGS/.test(t)) { const [ty, pre] = BankRec.propose({ ...r, cls: k }); return { type: 'Journal', acc: pre.lines[0].acc, conf: .8, why: k.hint, pre, specialKind: k.kind }; }
    if (/CHGS|CHARGES|MAINT/.test(t) && !/GST CHALLAN/.test(t)) return mk('bankchg', .9, 'Bank charges: ' + k.hint);
    if (/INT\.?PD|INTEREST CREDIT|INT\.CR/.test(t)) return mk('int_inc', .88, 'Interest credited by the bank. TDS may be deducted (see 26AS).');
    if (/UNKNOWN|UNIDENTIFIED/.test(t)) return mk('susp', .5, 'Remitter unknown. Held in suspense until identified; do not credit income.', { flag: 'suspense' });
    const code = (t.match(/\b[VC]\d{3}\b/) || [])[0]; if (code && Books.party(code)) return mk(code, .96, 'Party code ' + code + ' found in the narration.');
    if (learn) return mk(learn, .9, 'Learned from your earlier correction.');
    const A = new Set(stoks(r.narr)); let best = null; b.parties.forEach(p => { const P = stoks(p.name); if (!P.length) return; let ov = 0; P.forEach(w => { if (A.has(w)) ov++; }); const sc = ov / P.length; if (ov >= 1 && sc >= .5 && (!best || sc > best.sc || (sc === best.sc && ov > best.ov))) best = { p, sc, ov }; });
    if (best && best.ov >= 2) return mk(best.p.id, +(.72 + .2 * best.sc).toFixed(2), 'Narration matches the party name ' + best.p.name + '.'); if (best && best.sc === 1) return mk(best.p.id, .7, 'Narration matches the party name ' + best.p.name + '.');
    const al = ALIAS.find(a => a[0].test(t)); if (al) { const a0 = al[1][0]; const isCash = a0 === 'cash'; if (isCash) return dir === 'out' ? { type: 'Contra', acc: 'cash', conf: .85, why: 'Cash withdrawal moves money from bank to cash.', hint: 'Check the cash book; large round-sum withdrawals are reviewed by auditors.' } : { type: 'Contra', acc: 'cash', conf: .8, why: 'Cash deposit moves money from cash to bank.' }; const hints = { rent: 'TDS u/s 194I applies on rent above the annual threshold. Use the full form to deduct TDS.', power: 'Record the electricity bill in Purchases to claim input tax credit where allowed.', tds_p: 'Challan deposit. Match it to the TDS deducted for the month.', pf_p: 'Provident fund deposit. Match to the payroll payable.', sal_p: 'Salary payment. Match to the payroll payable.', go_c: 'GST challan. Post the set-off through the GST payable ledgers.' }; return mk(a0, .75, 'Narration keyword matches the ' + Books.accName(a0) + ' ledger.', { hint: hints[a0] || '' }); }
    return mk('susp', .2, 'No party, keyword or earlier correction matched. Park in Suspense or choose the ledger.', { flag: 'unknown' });
  },
  build(st) {
    const b = Books.cur(); b.stmtPosted = b.stmtPosted || {}; b.stmtMap = b.stmtMap || {}; const book = []; Books.posted().forEach(v => v.lines.forEach(l => { if (l.acc === 'bank' && (l.dr || l.cr)) book.push({ v, date: v.date, dir: l.dr > 0 ? 'in' : 'out', amt: l.dr || l.cr, used: false }); }));
    return st.rows.map((r, i) => ({ i, ...r, dir: r.d > 0 ? 'in' : 'out', amt: r.d > 0 ? r.d : r.w })).filter(r => r.narr !== 'OPENING BALANCE B/F' && r.amt > 0).map(r => {
      r.key = [r.date, r.dir, r.amt, r.ref].join('|'); let inB = null; const m = book.find(k => !k.used && k.dir === r.dir && Math.abs(k.amt - r.amt) < .005 && Math.abs(daysBetween(r.date, k.date)) <= 5); if (m) { m.used = true; inB = m.v.no; } if (b.stmtPosted[r.key]) inB = b.stmtPosted[r.key];
      r.inBooks = inB; r.sug = inB ? null : this.row(r, b); r.sel = !!(r.sug && r.sug.conf >= .7 && r.ref); return r;
    });
  }
};
const Stm = {
  st: null, rows: [], src: '', via: '', warn: [],
  load(st, src, via) { this.st = st; this.src = src; this.via = via || ''; this.warn = st.warnings || []; this.rows = Sug.build(st); App.ui.stmSet = true; Router.go('stmt'); },
  async post(rows) {
    const b = Books.cur(); let ok = 0, pend = 0; const skipped = [];
    for (const r of rows) {
      const s = r.sug, amt = r.amt, ref = (r.ref || r.refInput || '').trim(); if (!ref) { skipped.push(fmtDate(r.date) + ': add a reference'); continue; }
      let type = s.type, lines;
      if (s.pre && s.type === 'Journal') lines = s.pre.lines.map(l => ({ acc: l.acc, dr: r2(+l.dr || 0), cr: r2(+l.cr || 0) })); else if (type === 'Receipt') lines = [{ acc: 'bank', dr: amt, cr: 0 }, { acc: s.acc, dr: 0, cr: amt }]; else if (type === 'Payment') lines = [{ acc: s.acc, dr: amt, cr: 0 }, { acc: 'bank', dr: 0, cr: amt }]; else lines = r.dir === 'out' ? [{ acc: s.acc, dr: amt, cr: 0 }, { acc: 'bank', dr: 0, cr: amt }] : [{ acc: 'bank', dr: amt, cr: 0 }, { acc: s.acc, dr: 0, cr: amt }];
      if (!s.acc || !lines.every(l => l.acc)) { skipped.push(fmtDate(r.date) + ': choose a ledger'); continue; }
      const v = { id: uid('v'), no: '', type, date: r.date, narr: (s.pre ? s.pre.narr : r.narr.slice(0, 120) + ' (bank statement)'), lines, status: 'posted', maker: App.user.name, makerId: App.user.id, checker: null, ai: !!r.aiUsed, createdAt: new Date().toISOString(), meta: { party: Books.party(s.acc) ? s.acc : undefined, bankRow: r.key, source: 'statement' }, ref }, as = Ctl.assess(v);
      if (as.blocks.length) { skipped.push(fmtDate(r.date) + ': ' + as.blocks[0]); continue; } v.flags = as.flags; v.status = as.needs ? 'pending' : 'posted'; v.no = Books.nextNo(b, v.type, fyOfDate(v.date)); b.vouchers.push(v); b.stmtPosted[r.key] = v.no; r.inBooks = v.no; r.sug = null; r.sel = false; ok++; if (v.status === 'pending') pend++;
    }
    Books.save(); renderNav(); await Log.add('Entries created from bank statement', ok + ' voucher(s) from ' + (Stm.src || 'statement') + (pend ? ', ' + pend + ' sent for approval' : '')); return { ok, pend, skipped };
  }
};
Views.stmt = () => {
  const can = App.can('r2r', 'create'), b = Books.cur(), R = Stm.rows, todo = R.filter(r => !r.inBooks), inb = R.length - todo.length, tin = sum(R, r => r.d || (r.dir === 'in' ? r.amt : 0)), tout = sum(R, r => r.w || 0);
  const drop = `<div class="card" style="margin-bottom:16px"><div class="drop" data-drop="stm">${can ? `Drop a bank statement here (Excel, CSV, PDF, or a photo or scan), or <label class="link" style="cursor:pointer">choose a file<input type="file" accept=".xlsx,.xls,.csv,.pdf,.png,.jpg,.jpeg,.webp,.txt" data-change="stm-file" class="sr"></label>` : 'Your role cannot import statements.'}<div class="small muted" style="margin-top:6px">The statement is read, checked line by line against its running balance, matched to your books, and entries are suggested for everything not yet recorded.</div></div><div class="row" style="margin-top:10px"><span class="small muted">Try a sample:</span><button class="btn sm" data-act="stm-sample" data-arg="xlsx">Excel</button><button class="btn sm" data-act="stm-sample" data-arg="pdf">PDF</button><button class="btn sm" data-act="stm-sample" data-arg="png">Scanned image (needs AI or internet OCR)</button></div></div>`;
  let body = ''; if (!Stm.st) body = '<div class="empty"><b>No statement loaded</b>Drop one above to see parsed lines, checks and suggested entries.</div>'; else {
    const chk = Stm.warn.length ? `<div class="note warn" style="margin-bottom:12px"><b>${Stm.warn.length} line(s) fail the running-balance check.</b> The reading may be wrong for these rows; compare with the original. <details><summary class="link">Show</summary><ul class="plain small">${Stm.warn.slice(0, 12).map(w => `<li>${esc(w)}</li>`).join('')}</ul></details></div>` : '<div class="note good" style="margin-bottom:12px"><b>Running balance checks out</b> for every line (opening ' + fmtINR(Stm.st.opening, 2) + ', closing ' + fmtINR(Stm.st.closing, 2) + ').</div>';
    const sel = todo.filter(r => r.sel).length; body = `<div class="kpis" style="margin-bottom:12px"><div class="kpi"><div class="k">Lines read</div><div class="v">${R.length}</div></div><div class="kpi"><div class="k">Money in / out</div><div class="v" style="font-size:15px">${fmtINRShort(tin)} / ${fmtINRShort(tout)}</div></div><div class="kpi"><div class="k">Already in books</div><div class="v">${inb}</div></div><div class="kpi"><div class="k">To record</div><div class="v">${todo.length}</div></div></div>${chk}
    <div class="row" style="margin-bottom:10px"><b>${esc(Stm.src)}</b><span class="chip">${esc(Stm.via || 'parsed')}</span><span class="spacer"></span>${can ? `<button class="btn sm" data-act="stm-auto">Select confident (70%+)</button><button class="btn sm" data-act="stm-ai" ${AI.ready() ? '' : 'disabled'}>${icon('sparkle')}Ask AI about unsure rows</button><button class="btn sm" data-act="stm-use">Use for bank reconciliation</button><button class="btn sm primary" data-act="stm-post" ${sel ? '' : 'disabled'}>Create ${sel} entr${sel === 1 ? 'y' : 'ies'}</button>` : ''}</div>
    <div class="table-wrap"><table class="t"><thead><tr><th></th><th>Date</th><th>Narration</th><th>Reference</th><th class="amt">Out</th><th class="amt">In</th><th>Status and suggested entry</th></tr></thead><tbody>${R.slice(0, 300).map(r => `<tr><td>${r.inBooks ? '' : `<input type="checkbox" data-change="stm-sel" data-arg="${r.i}" aria-label="Select line" ${r.sel ? 'checked' : ''}>`}</td><td class="num" style="white-space:nowrap">${fmtDate(r.date)}</td><td class="small" style="max-width:300px">${esc(r.narr)}</td><td class="small mono">${r.ref ? esc(r.ref) : r.inBooks ? '' : `<input type="text" placeholder="UTR / ref" data-change="stm-ref" data-arg="${r.i}" style="height:30px;width:120px" aria-label="Reference">`}</td><td class="amt">${r.dir === 'out' ? fmt2(r.amt) : ''}</td><td class="amt">${r.dir === 'in' ? fmt2(r.amt) : ''}</td><td style="min-width:300px">${r.inBooks ? `<span class="chip good">In books</span> <span class="small muted">${esc(r.inBooks)}</span>` : `<div class="row" style="flex-wrap:nowrap;gap:6px"><span class="chip ${r.sug.conf >= .7 ? 'good' : r.sug.conf >= .45 ? 'warn' : 'bad'}">${r.sug.type} ${Math.round(r.sug.conf * 100)}%</span><div style="flex:1;min-width:180px"><select data-change="stm-acc" data-arg="${r.i}" aria-label="Ledger">${accOpts(r.sug.acc)}</select></div></div><div class="small muted" style="margin-top:3px">${esc(r.sug.why)}${r.sug.hint ? ' ' + esc(r.sug.hint) : ''}</div><div class="row" style="margin-top:3px"><button class="link small" data-act="stm-edit" data-arg="${r.i}">Open full entry form</button></div>`}</td></tr>`).join('')}</tbody></table></div>${R.length > 300 ? `<p class="muted small">Showing the first 300 of ${R.length} lines.</p>` : ''}`; }
  return `<div class="page-head"><div><h1>Statement assistant</h1><p class="sub">Upload a bank statement in any format and get entries suggested line by line. Nothing is posted until you create the entries, and every entry follows the approval rules.</p></div><div class="head-actions">${Stm.st ? `<button class="btn" data-act="stm-clear">Clear</button>` : ''}</div></div>${hasBooks() ? drop + body : noBooks('statement assistant')}`;
};
Changes['stm-file'] = async el => { const f = el.files[0]; el.value = ''; if (f) await Smart.handle([f], 'bank'); };
Changes['stm-sel'] = el => { const r = Stm.rows[+el.dataset.arg]; if (r) { r.sel = el.checked; Router.render(); } };
Changes['stm-ref'] = el => { const r = Stm.rows[+el.dataset.arg]; if (r) { r.refInput = el.value.trim(); if (r.refInput) r.sel = true; Router.render(); } };
Changes['stm-acc'] = el => { const r = Stm.rows[+el.dataset.arg]; if (!r || !el.value) return; const b = Books.cur(); r.sug.acc = el.value; r.sug.conf = .95; r.sug.why = 'Chosen by you. Arthos.AI will remember this for similar lines.'; r.sug.pre = null; if (r.sug.type === 'Journal') r.sug.type = r.dir === 'in' ? 'Receipt' : 'Payment'; if (r.sug.acc === 'cash') r.sug.type = 'Contra'; else if (r.sug.type === 'Contra') r.sug.type = r.dir === 'in' ? 'Receipt' : 'Payment'; const s = stem(r.narr); if (s) { b.stmtMap = b.stmtMap || {}; b.stmtMap[s] = el.value; Books.save(); } r.sel = !!r.ref || !!r.refInput; Router.render(); };
Actions['stm-auto'] = () => { Stm.rows.forEach(r => { if (!r.inBooks && r.sug && r.sug.conf >= .7 && (r.ref || r.refInput)) r.sel = true; }); Router.render(); };
Actions['stm-clear'] = () => { Stm.st = null; Stm.rows = []; Router.render(); };
Actions['stm-use'] = async () => { const b = Books.cur(); if (b.bankStmt && !(await UI.confirm('Replace the bank statement used for reconciliation?', 'The current statement (' + b.bankStmt.rows.length + ' rows) will be replaced by ' + esc(Stm.src) + '.', 'Replace', true))) return; b.bankStmt = Stm.st; b.bankDone = {}; Books.save(); Log.add('Statement set for reconciliation', Stm.src); UI.toast('Bank reconciliation now uses this statement.', 'good'); Router.go('bankrec'); };
Actions['stm-edit'] = i => { const r = Stm.rows[+i], s = r.sug, ty = s.type === 'Journal' ? 'Journal' : s.type; if (s.pre) { VForm.open('Journal', s.pre); return; } VForm.open(ty, { date: r.date, ref: r.ref || r.refInput || '', bankAcc: 'bank', acc: s.acc, amount: String(r.amt), narr: r.narr.slice(0, 120) + ' (bank statement)' }); };
Actions['stm-post'] = async () => { const rows = Stm.rows.filter(r => r.sel && !r.inBooks); if (!rows.length) return; const sus = rows.filter(r => r.sug.acc === 'susp').length; if (sus && !(await UI.confirm('Post ' + sus + ' line(s) to Suspense?', 'These lines could not be matched to a party or ledger. They will sit in the Suspense ledger until you clear them, and the month-end close will flag it.', 'Post anyway'))) return; const r = await Stm.post(rows); Router.render(); UI.modal({ title: 'Entries created', body: `<div class="note ${r.ok ? 'good' : 'warn'}"><b>${r.ok} entr${r.ok === 1 ? 'y' : 'ies'} created.</b> ${r.pend ? r.pend + ' sent to the approval inbox.' : ''}</div>${r.skipped.length ? `<p style="margin-top:10px"><b>${r.skipped.length} skipped:</b></p><ul class="plain small">${r.skipped.slice(0, 12).map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}`, actions: [{ label: 'Close', kind: 'primary' }] }); };
Actions['stm-ai'] = async () => {
  const unsure = Stm.rows.filter(r => !r.inBooks && r.sug && r.sug.conf < .7).slice(0, 12); if (!unsure.length) { UI.toast('No unsure rows.'); return; } const b = Books.cur(), accs = b.accounts.filter(a => !a.party).map(a => a.id + '=' + a.name).join('; '), parties = b.parties.slice(0, 80).map(p => p.id + '=' + p.name).join('; ');
  UI.toast('Asking Claude about ' + unsure.length + ' rows…'); try { const d = await AI.call({ system: 'You classify Indian bank statement lines into ledgers. Reply with ONLY JSON: {"rows":[{"i":number,"acc":"ledger id","why":"max 12 words"}]}. Use only these ledger ids. Ledgers: ' + accs + '. Parties: ' + parties + '. If unsure use susp.', messages: [{ role: 'user', content: JSON.stringify(unsure.map(r => ({ i: r.i, dir: r.dir, amt: r.amt, narr: r.narr }))) }] }); const j = AI.parseJSON(AI.text(d)); let n = 0; (j.rows || []).forEach(x => { const r = Stm.rows.find(z => z.i === x.i); if (r && x.acc && accIdOk(x.acc)) { r.sug.acc = x.acc; r.sug.conf = .65; r.sug.why = 'AI suggestion: ' + (x.why || ''); r.aiUsed = true; n++; } }); Log.add('AI classified statement rows', n + ' rows', { ai: true }); Router.render(); UI.toast(n + ' suggestions updated. Review them before creating entries.', 'good'); } catch (e) { UI.toast(e.message, 'error'); }
};
const accIdOk = id => !!Books.cur().accounts.find(a => a.id === id);

/* ---------- Sample statements (also used to build the sample-data folders) ---------- */
const SampleDocs = {
  rows(n = 36) { const co = App.company, s = (App.books[co.id] && App.books[co.id].bankStmt) || Lab.get(co).seed.books.bankStmt; return s.rows.filter(r => r.narr !== 'OPENING BALANCE B/F').slice(-n); },
  opening(rows, all) { const s = (App.books[App.company.id] && App.books[App.company.id].bankStmt) || Lab.get(App.company).seed.books.bankStmt; const i = s.rows.indexOf(rows[0]); return i > 0 ? s.rows[i - 1].bal : s.opening; },
  pdf(n = 36) {
    const rows = this.rows(n), op = this.opening(rows), doc = PDFX.doc(false), y = PDFX.letterhead(doc, 'Statement of Account: HDFC Bank Current Account', 'Account 50200012345678   |   Period ' + fmtDate(rows[0].date) + ' to ' + fmtDate(rows[rows.length - 1].date));
    const f = d => { const x = new Date(d); return String(x.getDate()).padStart(2, '0') + '/' + String(x.getMonth() + 1).padStart(2, '0') + '/' + x.getFullYear(); };
    doc.autoTable({ head: [['Date', 'Narration', 'Chq./Ref.No.', 'Withdrawal Amt.', 'Deposit Amt.', 'Closing Balance']], body: [[f(rows[0].date), 'OPENING BALANCE B/F', '', '', '', fmt2(op)], ...rows.map(r => [f(r.date), r.narr, r.ref, r.w ? fmt2(r.w) : '', r.d ? fmt2(r.d) : '', fmt2(r.bal)])], startY: y, theme: 'grid', margin: { left: 40, right: 40, bottom: 44 }, styles: { font: 'DejaVu', fontSize: 7, cellPadding: 2.5, lineColor: [215, 220, 228], lineWidth: .3 }, headStyles: { fillColor: [19, 33, 60], textColor: 255 }, columnStyles: { 0: { cellWidth: 52 }, 1: { cellWidth: 170 }, 2: { cellWidth: 66 }, 3: { halign: 'right' }, 4: { halign: 'right' }, 5: { halign: 'right' } } });
    PDFX.footer(doc); return doc.output('blob');
  },
  async png(n = 22) {
    const rows = this.rows(n), c = document.createElement('canvas'), W = 1240, H = 230 + rows.length * 30 + 60; c.width = W; c.height = H; const x = c.getContext('2d'); x.fillStyle = '#fbfbf8'; x.fillRect(0, 0, W, H); x.fillStyle = '#111'; x.font = 'bold 24px Arial'; x.fillText('HDFC BANK LTD   Statement of Account', 40, 50); x.font = '15px Arial'; x.fillText(App.company.name + '   A/c 50200012345678', 40, 80);
    x.font = 'bold 14px Arial'; ['Date', 'Narration', 'Chq/Ref', 'Withdrawal', 'Deposit', 'Balance'].forEach((h, i) => x.fillText(h, [40, 140, 720, 840, 980, 1100][i], 125)); x.fillRect(40, 134, W - 80, 2); x.font = '13px Arial'; const op = this.opening(rows); const f = d => { const z = new Date(d); return String(z.getDate()).padStart(2, '0') + '/' + String(z.getMonth() + 1).padStart(2, '0') + '/' + String(z.getFullYear()).slice(2); };
    let y = 162; x.fillText(f(rows[0].date), 40, y); x.fillText('OPENING BALANCE B/F', 140, y); x.fillText(fmt2(op), 1100, y); rows.forEach(r => { y += 30; x.fillText(f(r.date), 40, y); x.fillText(r.narr.slice(0, 62), 140, y); x.fillText(r.ref, 720, y); if (r.w) x.fillText(fmt2(r.w), 840, y); if (r.d) x.fillText(fmt2(r.d), 980, y); x.fillText(fmt2(r.bal), 1100, y); });
    return new Promise(res => c.toBlob(res, 'image/png'));
  },
  xlsxRows() { const rows = this.rows(60), op = this.opening(rows); const f = d => d.slice(8, 10) + '/' + d.slice(5, 7) + '/' + d.slice(2, 4); return [{ Date: f(rows[0].date), Narration: 'OPENING BALANCE B/F', 'Chq./Ref.No.': '', 'Withdrawal Amt.': '', 'Deposit Amt.': '', 'Closing Balance': op.toFixed(2) }, ...rows.map(r => ({ Date: f(r.date), Narration: r.narr, 'Chq./Ref.No.': r.ref, 'Withdrawal Amt.': r.w ? r.w.toFixed(2) : '', 'Deposit Amt.': r.d ? r.d.toFixed(2) : '', 'Closing Balance': r.bal.toFixed(2) }))]; }
};

SampleDocs.billPdf = function (v, o = {}) {
  const doc = PDFX.doc(false), co = App.company, W = doc.internal.pageSize.getWidth(); doc.setFont('DejaVu', 'bold'); doc.setFontSize(16); doc.text(v.name, 40, 60); doc.setFont('DejaVu', 'normal'); doc.setFontSize(9); doc.text('GSTIN ' + (o.gstin || v.gstin) + '   ' + (v.state || ''), 40, 76); doc.setFont('DejaVu', 'bold'); doc.setFontSize(13); doc.text('TAX INVOICE', W - 40, 60, { align: 'right' }); doc.setFont('DejaVu', 'normal'); doc.setFontSize(9);
  doc.text('Invoice No: ' + o.no, W - 40, 76, { align: 'right' }); doc.text('Invoice Date: ' + o.date, W - 40, 90, { align: 'right' }); doc.text('Bill to: ' + co.name, 40, 120); doc.text('GSTIN ' + co.gstin, 40, 133);
  const tx = o.taxable, r = o.rate || 18, intra = (o.gstin || v.gstin).slice(0, 2) === co.state, cg = intra ? r2(tx * r / 200) : 0, ig = intra ? 0 : r2(tx * r / 100);
  doc.autoTable({ head: [['Description', 'HSN/SAC', 'Qty', 'Rate', 'Amount']], body: [[o.desc || 'Polymer raw material', o.hsn || '390120', o.qty || 100, fmt2(tx / (o.qty || 100)), fmt2(tx)]], startY: 160, styles: { font: 'DejaVu', fontSize: 9 }, headStyles: { fillColor: [19, 33, 60] } });
  let y = doc.lastAutoTable.finalY + 24; [['Taxable value', tx], ...(intra ? [['CGST @ ' + r / 2 + '%', cg], ['SGST @ ' + r / 2 + '%', cg]] : [['IGST @ ' + r + '%', ig]]), ['Total', r2(tx + cg * 2 + ig)]].forEach(([k, x]) => { doc.setFont('DejaVu', k === 'Total' ? 'bold' : 'normal'); doc.text(k, W - 200, y); doc.text(fmt2(x), W - 40, y, { align: 'right' }); y += 15; });
  doc.setFontSize(8); doc.setTextColor(120); doc.text('Subject to local jurisdiction. E and OE.', 40, 780); return doc.output('blob');
};
Actions['stm-sample'] = async kind => {
  try { if (kind === 'xlsx') { const wb = Files.xlsx({ Statement: SampleDocs.xlsxRows() }), buf = await wb.arrayBuffer(), f = new File([buf], 'Sample_Statement.xlsx'); await Smart.handle([f], 'bank'); } else if (kind === 'pdf') { const f = new File([SampleDocs.pdf()], 'Sample_Statement.pdf', { type: 'application/pdf' }); await Smart.handle([f], 'bank'); } else { const f = new File([await SampleDocs.png()], 'Sample_Statement_Scan.png', { type: 'image/png' }); await Smart.handle([f], 'bank'); } } catch (e) { UI.toast(e.message, 'error'); }
};

/* ---------- Routing of anything that is dropped or chosen ---------- */
const Smart = {
  async handle(files, hint) {
    files = [...files]; if (!files.length || !App.session.userId) return; if (!App.can('r2r', 'create')) { UI.toast('Your role cannot import data.', 'error'); return; }
    for (const f of files) {
      try {
        UI.toast('Reading ' + f.name + '…'); const d = await Rd.any(f);
        if (d.kind === 'json') { await Imp.run([f]); continue; }
        if (d.kind === 'sheet') { const type = Imp.detect(Object.keys(d.rows[0] || {})); if (hint === 'bank' || type === 'bank') { Stm.load(BankRec.parse(d.grid), f.name, 'Spreadsheet'); continue; } if (type) { await Imp.run([f]); continue; } this.choose(d); continue; }
        const kind = hint === 'bank' ? 'bank' : Cls.detect(d.text);
        if (kind === 'bank') { Stm.load(Cls.bank(d.lines), f.name, d.via); continue; }
        if (kind === 'invoice') { this.invoice(d); continue; }
        if (kind === 'annual' && typeof IndAS !== 'undefined') { IndAS.add([f]); Router.go('indas'); continue; }
        if (kind === 'notice') { Studio.notice = d.text.slice(0, 6000); App.ui.stTab = 'notice'; Router.go('aistudio'); UI.toast('Notice text loaded into the AI Studio.', 'good'); continue; }
        this.choose(d);
      } catch (e) { UI.toast(f.name + ': ' + e.message, 'error'); }
    }
  },
  invoice(d) {
    const x = Cls.invoice(d.text), b = Books.cur(), party = b.parties.find(p => p.kind === 'V' && x.vendorGstin && p.gstin === x.vendorGstin) || b.parties.find(p => p.kind === 'V' && x.vendorName && stoks(p.name).some(w => stoks(x.vendorName).includes(w)));
    const intra = x.vendorGstin && x.vendorGstin.slice(0, 2) === App.company.state; Log.add('Bill read from file', d.name + ' (' + d.via + ')');
    if (x.direction === 'sales') { UI.toast('This looks like a sales invoice issued by your company. Check the customer and items.', 'good'); VForm.open('Sales', { ref: x.invNo, narr: 'Sales invoice ' + x.invNo, items: [{ desc: 'Per invoice ' + x.invNo, hsn: x.hsn, qty: 1, rate: String(x.taxable || ''), gst: x.rate || 18, ledger: 'sales' }] }); return; }
    VForm.open('Purchase', { party: party ? party.id : '', billNo: x.invNo, date: x.date || isoToday(), narr: 'Purchase per bill ' + (x.invNo || '') + ' from ' + (party ? party.name : x.vendorName), items: [{ desc: 'Goods or services per bill ' + (x.invNo || ''), hsn: x.hsn, qty: 1, rate: String(x.taxable || ''), gst: [0, 5, 18, 40].includes(x.rate) ? x.rate : 18, ledger: party && ({ '194C': 'jobwork', '194J': 'prof', '194H': 'comm' }[party.tds]) || 'purch' }], ai: false });
    UI.toast('Bill read via ' + d.via + '. Review every field; missing items are listed in the form.', 'good');
  },
  choose(d) {
    UI.modal({ title: 'What is ' + d.name + '?', body: '<p class="muted" style="margin-bottom:12px">Arthos.AI could not tell from the contents. Choose where it belongs.</p><div class="stack" style="gap:8px">' + [['bank', 'Bank statement', 'Parse lines and suggest entries'], ['purchase', 'Purchase bill', 'Read it into a purchase voucher'], ['sales', 'Sales invoice', 'Read it into a sales voucher'], ['annual', 'Annual report', 'Ind AS first-time adoption guide'], ['notice', 'Notice', 'Draft a reply in the AI Studio']].map(([k, t, s]) => `<button class="btn" data-ch="${k}" style="justify-content:flex-start;height:auto;padding:10px 14px"><span><b>${t}</b><br><span class="small muted">${s}</span></span></button>`).join('') + '</div>', actions: [{ label: 'Cancel' }], onOpen: (el, close) => $$('[data-ch]', el).forEach(bt => bt.addEventListener('click', async () => { close(); const k = bt.dataset.ch; try { if (k === 'bank') Stm.load(d.grid ? BankRec.parse(d.grid) : Cls.bank(d.lines), d.name, d.via || 'Spreadsheet'); else if (k === 'purchase' || k === 'sales') { const x = Cls.invoice(d.text || ''); VForm.open(k === 'sales' ? 'Sales' : 'Purchase', { billNo: x.invNo, ref: x.invNo }); } else if (k === 'annual') { if (typeof IndAS !== 'undefined') { IndAS.add([d.file]); Router.go('indas'); } } else { Studio.notice = (d.text || '').slice(0, 6000); App.ui.stTab = 'notice'; Router.go('aistudio'); } } catch (e) { UI.toast(e.message, 'error'); } })) });
  }
};
/* global drag and drop and a top-bar upload button */
(() => {
  const ov = document.createElement('div'); ov.id = 'drop-ov'; ov.innerHTML = '<div><b>Drop to import</b><span>Excel, CSV, PDF, images or JSON: bank statements, bills, masters, journals, annual reports</span></div>'; ov.hidden = true; document.body.appendChild(ov);
  const hasFiles = e => e.dataTransfer && [...(e.dataTransfer.types || [])].includes('Files'); let depth = 0;
  window.addEventListener('dragenter', e => { if (!hasFiles(e) || !App.session.userId) return; depth++; ov.hidden = false; });
  window.addEventListener('dragover', e => { if (hasFiles(e)) e.preventDefault(); });
  window.addEventListener('dragleave', e => { if (!hasFiles(e)) return; depth = Math.max(0, depth - 1); if (!depth) ov.hidden = true; });
  window.addEventListener('drop', e => { if (!hasFiles(e)) return; e.preventDefault(); depth = 0; ov.hidden = true; if (e.defaultPrevented && e.target.closest && e.target.closest('[data-drop="imp"]')) return; if (!App.session.userId) return; Smart.handle(e.dataTransfer.files, e.target.closest && e.target.closest('[data-drop="stm"]') ? 'bank' : undefined); }, true);
  const base = renderShell; renderShell = function () { base(); const host = $('.top-actions'); if (host && !host.querySelector('.upl')) host.insertAdjacentHTML('afterbegin', `<label class="icon-btn upl" style="cursor:pointer" title="Upload any file: statement, bill, master, journal or annual report" aria-label="Upload a file">${icon('upload')}<input type="file" multiple class="sr" data-change="smart-file" accept=".xlsx,.xls,.csv,.pdf,.png,.jpg,.jpeg,.webp,.txt,.json"></label>`); };
  Changes['smart-file'] = el => { const f = [...el.files]; el.value = ''; Smart.handle(f); };
})();
MODULES.splice(MODULES.findIndex(m => m.id === 'bankrec') + 1, 0, { id: 'stmt', title: 'Statement assistant', group: 'Record to report', icon: 'upload', perm: 'r2r', live: true });
