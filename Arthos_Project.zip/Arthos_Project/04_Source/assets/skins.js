const SKINS = [
 {
  "id": "ledger",
  "name": "Ledger",
  "tag": "Professional",
  "mode": "auto",
  "sw": [
   "#13213C",
   "#1C7050",
   "#F2F4F3"
  ],
  "blurb": "Navy ink and ledger green. The default for audit rooms."
 },
 {
  "id": "boardroom",
  "name": "Boardroom",
  "tag": "Corporate",
  "mode": "auto",
  "sw": [
   "#FFFFFF",
   "#1B5FC1",
   "#EEF2F8"
  ],
  "blurb": "Clean blue with a light sidebar. Looks like a listed-company MIS pack."
 },
 {
  "id": "midnight",
  "name": "Midnight Terminal",
  "tag": "Data-dense",
  "mode": "dark",
  "sw": [
   "#05080D",
   "#F2A93B",
   "#070B12"
  ],
  "blurb": "Monospace, amber on black. For long reconciliation sessions."
 },
 {
  "id": "gulabi",
  "name": "Gulabi",
  "tag": "Aesthetic",
  "mode": "light",
  "sw": [
   "#3A1428",
   "#B3295B",
   "#FDF1F4"
  ],
  "blurb": "Jaipur rose, plum and gold with serif headings."
 },
 {
  "id": "aurora",
  "name": "Aurora Glass",
  "tag": "Aesthetic",
  "mode": "dark",
  "sw": [
   "#2B1B6B",
   "#C5F6ED",
   "#0B0A24"
  ],
  "blurb": "Gradient mesh and frosted glass panels."
 },
 {
  "id": "ocean",
  "name": "Ocean",
  "tag": "Fresh",
  "mode": "light",
  "sw": [
   "#0B3A4A",
   "#0D6B85",
   "#EEF6F8"
  ],
  "blurb": "Teal and cool white with a deep-sea sidebar."
 },
 {
  "id": "forest",
  "name": "Forest",
  "tag": "Calm dark",
  "mode": "dark",
  "sw": [
   "#08100C",
   "#6EE7A0",
   "#0B1410"
  ],
  "blurb": "Deep green with mint highlights. Easy on the eyes at night."
 },
 {
  "id": "paper",
  "name": "Paper",
  "tag": "Minimal",
  "mode": "light",
  "sw": [
   "#F0F0EC",
   "#1A1A1A",
   "#F7F7F5"
  ],
  "blurb": "Black on white with serif headings. Reads like a printed report."
 },
 {
  "id": "marigold",
  "name": "Marigold",
  "tag": "Warm",
  "mode": "light",
  "sw": [
   "#2E1065",
   "#AF3B0B",
   "#FBF4EC"
  ],
  "blurb": "Orange accents on warm white with an indigo sidebar."
 },
 {
  "id": "contrast",
  "name": "High Contrast",
  "tag": "Accessible",
  "mode": "light",
  "sw": [
   "#000000",
   "#0033CC",
   "#FFFFFF"
  ],
  "blurb": "Pure black and white with heavy borders. WCAG AAA text."
 }
];
