/* ===================== IMPORT CENTER ===================== */
const IMP_FILE = { vendors: 'Vendor_Master', customers: 'Customer_Master', bank: 'Bank_Statement_HDFC', opening: 'Opening_Balances', journal: 'Journal_Dump', gstr2b: 'GSTR2B', assets: 'Fixed_Assets', employees: 'Employees', stock: 'Stock_Count' };
const IMP_NAME = { vendors: 'vendor master', customers: 'customer master', bank: 'bank statement', opening: 'opening balances', journal: 'journal vouchers', salesreg: 'sales register', purchasereg: 'purchase register', gstr2b: 'GSTR-2B', 'gstr2b-json': 'GSTR-2B (JSON)', assets: 'fixed asset register', employees: 'employee master', stock: 'stock and count', info: 'reference file' };
const IMP_MOD = { vendors: ['p2p', 'Purchases & payables'], customers: ['o2c', 'Sales & receivables'], bank: ['bankrec', 'Bank reconciliation'], opening: ['reports', 'Financial statements'], journal: ['vouchers', 'Vouchers & journals'], gstr2b: ['gst', 'GST'], assets: ['assets', 'Fixed assets'], employees: ['payroll', 'Payroll'], stock: ['inventory', 'Inventory'] };
const IMP_BAR = { vouchers: ['journal'], reports: ['opening'], bankrec: ['bank'], p2p: ['vendors'], o2c: ['customers'], inventory: ['stock'], payroll: ['employees'], assets: ['assets'], gst: ['gstr2b'] };
const IMP_ORDER = ['opening', 'vendors', 'customers', 'journal', 'purchasereg', 'salesreg', 'bank', 'gstr2b', 'gstr2b-json', 'assets', 'employees', 'stock', 'info'];
const impNum = v => { const n = parseFloat(String(v ?? '').replace(/[^0-9.\-]/g, '')); return isNaN(n) ? 0 : n; };
const impStr = v => String(v ?? '').trim();
const impDate = s => {
  s = impStr(s); let m;
  if ((m = s.match(/^(\d{4})-(\d{2})-(\d{2})/))) return m[0];
  if ((m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/))) { let y = +m[3]; if (y < 100) y += 2000; return y + '-' + String(m[2]).padStart(2, '0') + '-' + String(m[1]).padStart(2, '0'); }
  const d = new Date(s); return isNaN(d) ? '' : iso(d);
};
const impAcc = (b, id) => b.accounts.find(a => a.id === id);
const impEnsureParty = (b, p) => {
  const kind = p.kind, a = impAcc(b, p.id);
  if (a) { a.name = p.name; a.party = p.id; }
  else b.accounts.push({ id: p.id, name: p.name, group: kind === 'V' ? 'Sundry Creditors' : 'Sundry Debtors', nat: kind === 'V' ? 'L' : 'A', sch: kind === 'V' ? 'cl_pay' : 'ca_rec', op: 0, party: p.id });
};
const impUpsert = (b, p) => { const i = b.parties.findIndex(x => x.id === p.id); if (i >= 0) { p.active = b.parties[i].active === false ? false : true; b.parties[i] = Object.assign({}, b.parties[i], p); } else b.parties.push(p); impEnsureParty(b, p); };

const z0 = x => Math.abs(x) < 0.005 ? 0 : x;
const Imp = {
  last: [],
  files(co) {
    const real = App.books[co.id], seed = Lab.get(co).seed.books; App.books[co.id] = seed;
    try { return Lab.files(co); } finally { if (real) App.books[co.id] = real; else delete App.books[co.id]; }
  },
  detect(cols) {
    const has = re => cols.some(c => re.test(String(c)));
    if (has(/^vendor code$/i)) return 'vendors';
    if (has(/^customer code$/i)) return 'customers';
    if (has(/withdrawal/i) && has(/deposit/i)) return 'bank';
    if (has(/^voucher$/i) && has(/^ledger$/i) && has(/^debit$/i)) return 'journal';
    if (has(/^ledger$/i) && has(/^debit$/i) && has(/^credit$/i) && has(/^nature$/i)) return 'opening';
    if (has(/^invoice$/i) && has(/^taxable$/i) && has(/^customer$/i)) return 'salesreg';
    if (has(/vendor bill/i) && has(/^taxable$/i)) return 'purchasereg';
    if (has(/invoice number/i) && has(/gstin/i)) return 'gstr2b';
    if (has(/put to use/i)) return 'assets';
    if (has(/gross per month/i)) return 'employees';
    if (has(/opening qty/i)) return 'stock';
    if (has(/login enabled/i) || has(/ai-drafted/i)) return 'info';
    if (has(/date/i) && has(/narr|desc|particular|remark/i) && has(/withdraw|debit/i) && has(/deposit|credit/i)) return 'bank';
    return null;
  },
  read(file) {
    return new Promise((res, rej) => {
      const rd = new FileReader(); rd.onerror = () => rej(new Error('Could not read ' + file.name));
      if (/\.json$/i.test(file.name)) { rd.onload = () => { try { res({ name: file.name, json: JSON.parse(rd.result) }); } catch (e) { rej(new Error(file.name + ' is not valid JSON.')); } }; rd.readAsText(file); return; }
      if (!libOK('XLSX')) { rej(new Error('The Excel library did not load. Check your connection and reload.')); return; }
      const isCsv = /\.csv$/i.test(file.name);
      rd.onload = () => {
        try {
          const wb = isCsv ? XLSX.read(String(rd.result).replace(/^\uFEFF/, ''), { type: 'string', raw: true }) : XLSX.read(rd.result, { type: 'array', cellDates: true }), ws = wb.Sheets[wb.SheetNames[0]], o = { raw: false, dateNF: 'yyyy-mm-dd' };
          res({ name: file.name, rows: XLSX.utils.sheet_to_json(ws, { ...o, defval: '' }), grid: XLSX.utils.sheet_to_json(ws, { ...o, header: 1 }) });
        } catch (e) { rej(new Error(file.name + ': ' + e.message)); }
      };
      isCsv ? rd.readAsText(file) : rd.readAsArrayBuffer(file);
    });
  },
  async run(fileList, forced) {
    const files = [...fileList]; if (!files.length) return;
    if (!App.can('r2r', 'create')) { UI.toast('Your role cannot import data.', 'error'); return; }
    const out = [], loaded = [];
    for (const f of files) { try { loaded.push(await this.read(f)); } catch (e) { out.push({ file: f.name, type: '—', ok: false, msg: e.message }); } }
    loaded.forEach(l => { l.type = forced || (l.json ? 'gstr2b-json' : this.detect(Object.keys(l.rows[0] || {}))); });
    loaded.sort((a, b) => IMP_ORDER.indexOf(a.type) - IMP_ORDER.indexOf(b.type));
    if (loaded.some(l => l.type === 'journal') && hasBooks() && !(await UI.confirm('Replace all vouchers?', 'Importing a journal file replaces every voucher in ' + esc(App.company.name) + ' with the vouchers in the file. Masters stay. Pending and rejected vouchers are removed.', 'Replace and import', true))) return;
    for (const l of loaded) {
      if (!l.type) { out.push({ file: l.name, type: 'Not recognised', ok: false, msg: 'The column headings do not match any sample layout. Download a sample file from this page and use it as a template.' }); continue; }
      try { const r = this.importers[l.type](l, Books.cur()); out.push({ file: l.name, type: IMP_NAME[l.type], ok: true, msg: r.msg, warn: r.warn || [] }); Log.add('Data imported', l.name + ': ' + IMP_NAME[l.type] + ', ' + r.msg); }
      catch (e) { out.push({ file: l.name, type: IMP_NAME[l.type] || l.type, ok: false, msg: e.message }); }
    }
    Books.save(); this.last = out; renderNav(); Router.render();
    const ok = out.filter(x => x.ok).length; UI.toast(ok + ' of ' + out.length + ' file' + (out.length === 1 ? '' : 's') + ' imported.', ok === out.length ? 'good' : 'error');
  },
  derive(b) {
    b.vouchers.forEach(v => {
      const m = v.meta = v.meta || {}; const pl = v.lines.find(l => { const a = impAcc(b, l.acc); return a && a.party; }); if (pl && !m.party) m.party = pl.acc;
      const p = m.party ? Books.party(m.party) : null, net = (k, sign) => r2(sum(v.lines.filter(l => l.acc === k), l => sign * ((l.cr || 0) - (l.dr || 0))));
      if (v.type === 'Sales' || v.type === 'Credit Note') {
        const sg = v.type === 'Sales' ? 1 : -1, taxable = net('sales', sg), c = net('go_c', sg), s = net('go_s', sg), i = net('go_i', sg), rate = taxable ? Math.round((c + s + i) / taxable * 100) : 18;
        Object.assign(m, { taxable, cgst: c, sgst: s, igst: i, rate, total: r2(taxable + c + s + i), pos: p ? partyState(p) : '', due: iso(addD(dparse(v.date), p?.terms || 30)), items: [{ desc: 'Goods and services', hsn: '', qty: 1, rate: taxable, gst: rate, amount: taxable }] }); if (v.type === 'Sales') m.invNo = v.no;
      } else if (v.type === 'Purchase' || v.type === 'Debit Note') {
        const skip = a => a === m.party || /^(gi_|go_|tds_p)/.test(a), gi = k => r2(sum(v.lines.filter(l => l.acc === k), l => v.type === 'Purchase' ? (l.dr || 0) - (l.cr || 0) : (l.cr || 0) - (l.dr || 0)));
        const taxable = r2(sum(v.lines.filter(l => !skip(l.acc)), l => v.type === 'Purchase' ? (l.dr || 0) - (l.cr || 0) : (l.cr || 0) - (l.dr || 0))), c = gi('gi_c'), s = gi('gi_s'), i = gi('gi_i'), tds = r2(sum(v.lines.filter(l => l.acc === 'tds_p'), l => v.type === 'Purchase' ? (l.cr || 0) - (l.dr || 0) : (l.dr || 0) - (l.cr || 0))), rate = taxable ? Math.round((c + s + i) / taxable * 100) : 18;
        Object.assign(m, { taxable, cgst: c, sgst: s, igst: i, tds, tdsSec: tds ? (p?.tds && p.tds !== 'None' ? p.tds : '') : '', itc: (c + s + i) > 0, rate, total: r2(taxable + c + s + i), pos: p ? partyState(p) : '', billNo: m.billNo || '', items: [{ desc: 'Goods and services', hsn: '', qty: 1, rate: taxable, gst: rate, amount: taxable, ledger: 'purch' }] });
      }
    });
  },
  importers: {
    vendors(f, b) {
      let n = 0, badG = 0; f.rows.forEach(r => {
        const id = impStr(r['Vendor Code']); if (!id) return; const gstin = impStr(r['GSTIN']).toUpperCase(), reg = impStr(r['GST Registration']);
        impUpsert(b, { id, kind: 'V', name: impStr(r['Vendor Name']), gstin, pan: impStr(r['PAN']).toUpperCase(), state: impStr(r['State']), constitution: impStr(r['Constitution']), msme: impStr(r['MSME Status']), udyam: impStr(r['Udyam No']), bank: impStr(r['Bank Name']), ifsc: impStr(r['IFSC']), acct: impStr(r['Bank Account']), terms: impNum(r['Payment Terms (days)']) || 30, tds: impStr(r['TDS Section']) || 'None', email: impStr(r['Email']), phone: impStr(r['Phone']) });
        n++; if ((gstin && !GST.validate(gstin).ok) || (!gstin && /regular/i.test(reg))) badG++;
      });
      if (!n) throw new Error('No vendor rows found.'); return { msg: n + ' vendors imported', warn: badG ? [badG + ' vendor(s) have a missing or invalid GSTIN. The master checks will list them.'] : [] };
    },
    customers(f, b) {
      let n = 0, badG = 0; f.rows.forEach(r => {
        const id = impStr(r['Customer Code']); if (!id) return; const gstin = impStr(r['GSTIN']).toUpperCase();
        impUpsert(b, { id, kind: 'C', name: impStr(r['Customer Name']), gstin, pan: impStr(r['PAN']).toUpperCase(), state: impStr(r['State']), limit: impNum(r['Credit Limit']), terms: impNum(r['Credit Days']) || 30, email: impStr(r['Email']) });
        n++; if (gstin && !GST.validate(gstin).ok) badG++;
      });
      if (!n) throw new Error('No customer rows found.'); return { msg: n + ' customers imported', warn: badG ? [badG + ' customer(s) have an invalid GSTIN.'] : [] };
    },
    bank(f, b) { b.bankStmt = BankRec.parse(f.grid); b.bankDone = {}; return { msg: b.bankStmt.rows.length + ' statement rows imported. Open Bank reconciliation.' }; },
    opening(f, b) {
      const before = b.accounts.map(a => a.op), byName = new Map(b.accounts.filter(a => !a.party).map(a => [a.name.toLowerCase(), a]));
      b.accounts.forEach(a => { if (!a.party) a.op = 0; }); let dr = 0, cr = 0, made = 0, rows = 0;
      f.rows.forEach(r => {
        const name = impStr(r.Ledger); if (!name) return; const D = impNum(r.Debit), C = impNum(r.Credit); let a = byName.get(name.toLowerCase());
        if (!a) {
          const nat = /asset/i.test(r.Nature) ? 'A' : /liab/i.test(r.Nature) ? 'L' : /income/i.test(r.Nature) ? 'I' : 'E';
          a = { id: 'x_' + name.toLowerCase().replace(/[^a-z0-9]+/g, '_').slice(0, 24), name, group: impStr(r.Group) || 'Imported', nat, sch: { A: 'ca_oth', L: 'cl_oth', I: 'rev_oth', E: 'exp_oth' }[nat], op: 0 }; b.accounts.push(a); byName.set(name.toLowerCase(), a); made++;
        }
        a.op = r2((a.op || 0) + D - C); dr += D; cr += C; rows++;
      });
      if (Math.abs(dr - cr) > 0.01) { b.accounts.forEach((a, i) => { if (i < before.length) a.op = before[i]; }); b.accounts.length = before.length; throw new Error('Opening balances do not balance: debits ' + fmt2(dr) + ' and credits ' + fmt2(cr) + ' differ by ' + fmt2(dr - cr) + '. Nothing was changed.'); }
      return { msg: rows + ' opening balances applied' + (made ? ', ' + made + ' new ledger(s) created' : '') + '. Debits equal credits at ' + fmt2(dr) };
    },
    journal(f, b) {
      const names = new Map(); b.accounts.forEach(a => { if (!names.has(a.name.toLowerCase())) names.set(a.name.toLowerCase(), a.id); });
      const groups = new Map(); f.rows.forEach(r => { const no = impStr(r.Voucher); if (!no) return; if (!groups.has(no)) groups.set(no, []); groups.get(no).push(r); });
      const out = [], skipped = [], unknown = new Set();
      groups.forEach((rs, no) => {
        const lines = []; let bad = false;
        rs.forEach(r => { const id = names.get(impStr(r.Ledger).toLowerCase()); if (!id) { unknown.add(impStr(r.Ledger)); bad = true; return; } lines.push({ acc: id, dr: r2(impNum(r.Debit)), cr: r2(impNum(r.Credit)) }); });
        if (bad) { skipped.push(no + ' (unknown ledger)'); return; }
        const dr = sum(lines, l => l.dr), cr = sum(lines, l => l.cr); if (Math.abs(dr - cr) > 0.01) { skipped.push(no + ' (unbalanced by ' + fmt2(dr - cr) + ')'); return; }
        const r0 = rs[0], type = VTYPES[impStr(r0.Type)] ? impStr(r0.Type) : 'Journal', date = impDate(r0.Date); if (!date) { skipped.push(no + ' (bad date)'); return; }
        let at = new Date(impStr(r0['Entered at'])); if (isNaN(at)) at = new Date(date + 'T10:00:00');
        out.push({ id: uid('v'), no, type, date, narr: impStr(r0.Narration) || type + ' voucher', lines: lines.filter(l => l.dr || l.cr), status: 'posted', maker: impStr(r0.Maker) || 'Imported', makerId: null, checker: impStr(r0.Checker) || null, ai: false, createdAt: at.toISOString(), meta: {}, ref: '' });
      });
      if (!out.length) throw new Error('No valid vouchers found. ' + (unknown.size ? 'Unknown ledgers: ' + [...unknown].slice(0, 5).join(', ') + '. Import the masters and opening balances first.' : ''));
      out.sort((a, c) => a.date < c.date ? -1 : a.date > c.date ? 1 : 0); b.vouchers = out; b.seq = {};
      out.forEach(v => { const k = v.type + fyOfDate(v.date), n = parseInt(String(v.no).split('/').pop(), 10) || 0; if (n > (b.seq[k] || 0)) b.seq[k] = n; });
      Imp.derive(b);
      return { msg: out.length + ' vouchers imported (' + sum(out, v => v.lines.length) + ' lines)', warn: [...(skipped.length ? [skipped.length + ' voucher(s) skipped: ' + skipped.slice(0, 4).join('; ') + (skipped.length > 4 ? '…' : '')] : []), 'GST details were rebuilt from the ledger lines. Upload the purchase register as well to restore vendor bill numbers for duplicate checks.'] };
    },
    purchasereg(f, b) { let n = 0; f.rows.forEach(r => { const v = b.vouchers.find(x => x.no === impStr(r.Voucher)); if (v) { v.meta = v.meta || {}; v.meta.billNo = impStr(r['Vendor bill']); n++; } }); if (!b.vouchers.length) throw new Error('Import the journal file first, then the purchase register.'); return { msg: n + ' vendor bill numbers matched to vouchers' }; },
    salesreg(f, b) { let n = 0; f.rows.forEach(r => { if (b.vouchers.some(x => x.no === impStr(r.Invoice))) n++; }); if (!b.vouchers.length) throw new Error('Import the journal file first.'); return { msg: n + ' of ' + f.rows.length + ' invoices matched to vouchers. GST values come from the ledger lines.' }; },
    gstr2b(f, b) { b.gstr2b = GSTR2B.parse(f.grid); return { msg: b.gstr2b.length + ' GSTR-2B invoices loaded. Open GST, then GSTR-2B reconciliation.' }; },
    'gstr2b-json'(f, b) { const j = f.json; if (!Array.isArray(j) || !j.length || !('gstin' in j[0]) || !('inv' in j[0])) throw new Error('This JSON is not in the sample layout. Use the GSTR-2B Excel file instead.'); b.gstr2b = j; return { msg: j.length + ' GSTR-2B invoices loaded' }; },
    assets(f, b) {
      const inv = Object.fromEntries(Object.entries(CONFIG.fa.names).map(([k, v]) => [v.toLowerCase(), k])); const out = [];
      f.rows.forEach(r => { const id = impStr(r.ID); if (!id) return; const cl = impStr(r.Class).toLowerCase(); out.push({ id, name: impStr(r.Asset), cls: inv[cl] || (CONFIG.fa.life[cl] ? cl : 'pm'), cost: impNum(r.Cost), use: impDate(r['Put to use']), loc: impStr(r.Location) }); });
      if (!out.length) throw new Error('No asset rows found.'); b.assets = out; return { msg: out.length + ' assets imported. Open Fixed assets for depreciation.' };
    },
    employees(f, b) {
      const out = []; f.rows.forEach(r => { const id = impStr(r.ID); if (!id) return; const rf = impDate(r['Revised from']); out.push({ id, name: impStr(r.Name), desig: impStr(r.Designation), doj: impDate(r.Joined), gross: impNum(r['Gross per month']), basicPct: 50, pan: impStr(r.PAN).toUpperCase(), uan: impStr(r.UAN), regime: 'new', ...(rf && impNum(r['Revised gross']) ? { revFrom: rf.slice(0, 7), revGross: impNum(r['Revised gross']) } : {}) }); });
      if (!out.length) throw new Error('No employee rows found.'); b.employees = out; return { msg: out.length + ' employees imported. Open Payroll and run a month.' };
    },
    stock(f, b) {
      const items = [], counts = {}; f.rows.forEach((r, i) => { const name = impStr(r.Item); if (!name) return; const old = b.items.find(x => x.name.toLowerCase() === name.toLowerCase()), id = old ? old.id : 'IT' + String(i + 1).padStart(2, '0'); items.push({ id, name, hsn: impStr(r.HSN), unit: impStr(r.Unit) || 'nos', reorder: impNum(r['Reorder level']), opQty: impNum(r['Opening qty']), opRate: impNum(r['Opening rate']), expiry: impDate(r.Expiry) }); if (impStr(r['Physical count']) !== '') counts[id] = impNum(r['Physical count']); });
      if (!items.length) throw new Error('No stock rows found.'); b.items = items; b.counts = counts; b.moves = (b.moves || []).filter(m => items.some(x => x.id === m.item)); return { msg: items.length + ' items and ' + Object.keys(counts).length + ' physical counts imported' };
    },
    info(f) { return { msg: 'Recognised as a reference file (answer key or log). Nothing to import.' }; }
  },
  checks() {
    const b = Books.cur(), fy = App.session.fy || fyNow(), safe = fn => { try { return fn(); } catch (e) { return 'n/a'; } };
    const R = safe(() => Risk.run()), has = t => Array.isArray(R.F) ? R.F.filter(f => f.test === t).length : 0, pend = b.vouchers.filter(v => v.status === 'pending');
    const bk = safe(() => BankRec.run()), fc = safe(() => Fc.run({})), dup = safe(() => Dup.scan().length), ars = safe(() => AR.risk()), tx = safe(() => TaxAlerts.scan().length), itc = safe(() => TaxAlerts.itcReversals().rows.length);
    const bs = safe(() => Rep.bs(fy)), cf = safe(() => Rep.cf(fy)), tb = safe(() => Rep.trial(fy).reduce((s, x) => s + x.close, 0));
    const hi = Array.isArray(ars) ? ars.filter(x => /high|critical/i.test(x.level || '')).length : 'n/a';
    return [
      ['Approval inbox', 'approvals', 'Sign in as Neha (PIN 3333) and approve or reject. Try a voucher above her limit.', `${pend.length} waiting, ${pend.filter(v => v.ai).length} AI-drafted, ${pend.filter(v => Books.amt(v) > 500000).length} above the ₹5,00,000 finance-manager limit (Admin only).`],
      ['Vouchers', 'vouchers', 'Press F7 for a journal. Over ₹50,000 goes to approval; under it posts at once.', 'Posting preview, GST/TDS alerts and duplicate checks update as you type.'],
      ['Financial statements', 'reports', 'Open Trial balance, Balance sheet and Cash flow.', `Trial balance difference ${fmt2(z0(tb))}, balance sheet difference ${fmt2(z0(bs.diff))}, cash flow difference ${fmt2(z0(cf.diff))}. All should be 0.00.`],
      ['Bank reconciliation', 'bankrec', 'Open the Suggested and Unmatched tabs, then the statement (BRS).', Array.isArray(bk.ub) || bk.ub ? `${bk.matched.length} matched, ${bk.sugg.length} suggested, ${bk.ub.length} bank items not in books, ${bk.uk.length} book items not at bank. BRS difference ${fmt2(z0(bk.brs.diff))}.` : 'Load the sample company first.'],
      ['Purchases & payables', 'p2p', 'Check Duplicates, Vendors and MSME tabs.', `${dup} duplicate invoice/payment finding(s); ${has('Split purchases')} split-purchase pattern(s); ${has('Vendor master')} vendor-master issue(s); ${has('MSME alert')} MSME alert(s).`],
      ['Sales & receivables', 'o2c', 'Open Receivables risk. Create a sales invoice for a customer over their limit.', `${has('Credit limit breach')} credit-limit breach(es); ${hi} customer(s) rated High or Critical.`],
      ['GST', 'gst', 'Run GSTR-3B, then Reconciliation with the sample GSTR-2B, then Alerts.', `${itc} bill(s) unpaid beyond 180 days (ITC reversal); ${has('GST alert')} GST alert(s); reconciliation lists matched, mismatched and missing invoices.`],
      ['Income tax & TDS', 'incometax', 'Open the TDS check and the regime calculator.', `${tx} TDS/tax alert(s) from the books; ${has('TDS alert')} flagged in the risk tests.`],
      ['Inventory', 'inventory', 'Compare FIFO against weighted average and open the physical count.', 'Count differences and an expired batch are planted in the stock file.'],
      ['Payroll', 'payroll', 'Run the latest month and open a payslip PDF.', 'One employee crosses the ESI ceiling mid-year; PF is capped at ₹15,000 of basic.'],
      ['Fixed assets', 'assets', 'Compare Companies Act and Income Tax depreciation.', 'One asset was put to use in under 180 days, so the Income Tax rate is halved.'],
      ['Risk & anomalies', 'risk', 'Open Findings, then Benford’s Law.', Array.isArray(R.F) ? `${R.F.length} findings, risk score ${R.score}/100 (${R.level}); Benford MAD ${(R.bf.mad || 0).toFixed(4)} (${R.bf.level}).` : 'n/a'],
      ['Month-end close', 'close', 'Run the close agent for the last full month.', 'Expect failures on depreciation, prepaid expenses and the suspense balance.'],
      ['Cash flow forecast', 'cashflow', 'Move the what-if sliders.', Array.isArray(fc.wk) ? `${fc.short.length} of ${fc.wk.length} weeks fall below the safety buffer.` : 'n/a'],
      ['Users & controls', 'ctl', 'Run the control tests and open the deficiency tracker.', 'Failed tests become deficiencies; the IFC report summarises them.'],
      ['Audit trail', 'log', 'Verify the chain, then simulate tampering.', 'Every import, approval and posting above is in the trail.']
    ];
  },
  dl(type) {
    const f = this.files(App.company).find(x => x.file === IMP_FILE[type]); if (!f) { UI.toast('Sample file not available.', 'error'); return; }
    try { Files.download(f.file + '.xlsx', Files.xlsx({ [f.title.slice(0, 28)]: f.rows })); Log.add('Sample file downloaded', f.file + '.xlsx'); } catch (e) { UI.toast(e.message, 'error'); }
  },
  bar() {
    const v = $('#view'), types = IMP_BAR[App.route]; if (!v || !types) return; const old = v.querySelector('.imp-bar'); if (old) old.remove();
    const can = App.can('r2r', 'create'), btns = types.map(t => `<button class="btn sm" data-act="imp-dl" data-arg="${t}">Sample ${IMP_NAME[t]} (.xlsx)</button>${can ? `<label class="btn sm" style="cursor:pointer">Upload ${IMP_NAME[t]}<input type="file" accept=".xlsx,.xls,.csv,.json" data-change="imp-one" data-arg="${t}" class="sr"></label>` : ''}`).join(' ');
    v.insertAdjacentHTML('afterbegin', `<div class="imp-bar note" style="margin-bottom:14px;display:flex;gap:8px;align-items:center;flex-wrap:wrap"><b style="font-weight:600">Test data</b>${!hasBooks() && can ? '<button class="btn sm primary" data-act="imp-all">Load complete sample company</button>' : ''}${btns}<button class="link" data-act="go" data-arg="import">Import center</button></div>`);
  }
};
(() => { const base = Router.render.bind(Router); Router.render = function () { base(); try { Imp.bar(); } catch (e) { console.error(e); } }; })();

Views.import = () => {
  const co = App.company, can = App.can('r2r', 'create'), has = hasBooks(), b = Books.cur(), F = Imp.files(co);
  const stat = has ? `<div class="row" style="margin-top:10px"><span class="chip good">${b.vouchers.length} vouchers</span><span class="chip">${b.parties.length} parties</span><span class="chip">${b.employees.length} employees</span><span class="chip">${b.assets.length} assets</span><span class="chip">${b.items.length} stock items</span><span class="chip">${b.bankStmt ? b.bankStmt.rows.length + ' bank rows' : 'no bank statement'}</span><span class="chip">${(b.gstr2b || []).length} GSTR-2B rows</span></div>` : '<div class="note warn" style="margin-top:10px">This company has no books yet. One click below loads a full sample year.</div>';
  const res = Imp.last.length ? `<div class="table-wrap" style="margin-top:14px"><table class="t"><thead><tr><th>File</th><th>Detected as</th><th>Result</th></tr></thead><tbody>${Imp.last.map(r => `<tr><td>${esc(r.file)}</td><td>${esc(r.type)}</td><td>${r.ok ? '<span class="chip good">Imported</span> ' : '<span class="chip bad">Failed</span> '}${esc(r.msg)}${(r.warn || []).map(w => `<div class="small muted">${esc(w)}</div>`).join('')}</td></tr>`).join('')}</tbody></table></div>` : '';
  const types = Object.keys(IMP_FILE), rows = types.map(t => { const f = F.find(x => x.file === IMP_FILE[t]); return { t, f }; }).filter(x => x.f);
  const fileTbl = `<div class="table-wrap"><table class="t"><thead><tr><th>Module</th><th>Sample file</th><th>Tests</th><th class="amt">Rows</th><th class="amt">Planted issues</th><th></th></tr></thead><tbody>${rows.map(({ t, f }) => `<tr><td><button class="link" data-act="go" data-arg="${IMP_MOD[t][0]}">${esc(IMP_MOD[t][1])}</button></td><td>${esc(f.file)}</td><td class="small muted">${esc(f.desc || '')}</td><td class="amt">${f.rows.length}</td><td class="amt">${f.planted || 0}</td><td class="amt"><div class="row-actions"><button class="btn sm" data-act="imp-dl" data-arg="${t}">Download</button>${can ? `<label class="btn sm" style="cursor:pointer">Upload<input type="file" accept=".xlsx,.xls,.csv,.json" data-change="imp-one" data-arg="${t}" class="sr"></label>` : ''}</div></td></tr>`).join('')}</tbody></table></div>`;
  const chk = has ? `<div class="table-wrap"><table class="t"><thead><tr><th>Module</th><th>What to do</th><th>What you should see in this data</th><th></th></tr></thead><tbody>${Imp.checks().map(c => `<tr><td style="white-space:nowrap">${esc(c[0])}</td><td class="small">${esc(c[2])}</td><td class="small">${esc(c[3])}</td><td class="amt"><button class="btn sm" data-act="go" data-arg="${c[1]}">Open</button></td></tr>`).join('')}</tbody></table></div>` : '<div class="empty"><b>Load the sample company to see the test checklist</b>It lists what to click in every module and the result you should get, using live counts from your data.</div>';
  return `<div class="page-head"><div><h1>Import & sample data</h1><p class="sub">Everything you need to test every module: load a complete sample company in one click, or upload the sample files one by one. Files are recognised by their column headings.</p></div><div class="head-actions">${App.can('lab', 'export') ? `<button class="btn" data-act="lab-pack">${icon('download')}Judge Demo Pack (ZIP)</button>` : ''}</div></div>
  <div class="grid-2 even"><div class="card"><h2>1. One click: complete sample company</h2><p class="muted small" style="margin-top:6px">A full financial year for ${esc(co.name)}: vouchers, masters, bank statement, GSTR-2B, payroll, assets and stock, with deliberate errors planted for the controls and AI features to catch.</p>${stat}<div class="row" style="margin-top:14px">${can ? `<button class="btn primary" data-act="imp-all" style="height:42px;padding:0 20px">${icon('flask')}${has ? 'Reload sample year' : 'Load complete sample company'}</button>` : '<span class="muted small">Your role cannot load data.</span>'}</div></div>
  <div class="card"><h2>2. Upload your own files</h2><p class="muted small" style="margin-top:6px">Drop several files at once. Masters and opening balances load first, then journals, then the rest. Excel (.xlsx, .xls) and CSV are accepted.</p><div class="drop" data-drop="imp" style="margin-top:12px">${can ? `Drag files here or <label class="link" style="cursor:pointer">choose files<input type="file" multiple accept=".xlsx,.xls,.csv,.json" data-change="imp-files" class="sr"></label>` : 'Your role cannot import data.'}</div>${res}</div></div>
  <div class="card" style="margin-bottom:18px"><div class="card-head"><h2>3. What each sample file tests</h2><span class="muted small">Download, inspect, edit, upload again</span></div>${fileTbl}</div>
  <div class="card"><div class="card-head"><h2>4. Test checklist</h2><span class="muted small">Counts are live from your data</span></div>${chk}</div>`;
};

Actions['imp-all'] = async () => {
  if (!App.can('r2r', 'create')) { UI.toast('Your role cannot load data.', 'error'); return; }
  if (hasBooks() && !(await UI.confirm('Reload the sample year?', 'This replaces all vouchers, parties and masters for ' + esc(App.company.name) + ' with the sample year. Settings and users stay.', 'Reload', true))) return;
  Books.reseed(); const b = Books.cur(); if (!(b.gstr2b || []).length) { try { b.gstr2b = GSTR2B.sample(); } catch (e) { /* optional */ } } Books.save();
  Imp.last = []; Log.add('Complete sample company loaded', App.company.name + ', ' + b.vouchers.length + ' vouchers'); UI.toast('Sample company loaded: ' + b.vouchers.length + ' vouchers. See the checklist below.', 'good'); renderNav(); Router.go('import');
};
Actions['imp-dl'] = t => Imp.dl(t);
Changes['imp-files'] = el => { const f = [...el.files]; el.value = ''; Imp.run(f); };
Changes['imp-one'] = el => { const f = [...el.files], t = el.dataset.arg; el.value = ''; Imp.run(f, t); };
document.addEventListener('dragover', e => { if (e.target.closest && e.target.closest('[data-drop="imp"]')) { e.preventDefault(); e.target.closest('[data-drop="imp"]').style.borderColor = 'var(--accent)'; } });
document.addEventListener('dragleave', e => { const d = e.target.closest && e.target.closest('[data-drop="imp"]'); if (d) d.style.borderColor = ''; });
document.addEventListener('drop', e => { const d = e.target.closest && e.target.closest('[data-drop="imp"]'); if (!d) return; e.preventDefault(); d.style.borderColor = ''; Imp.run([...e.dataTransfer.files]); });
MODULES.splice(MODULES.findIndex(m => m.id === 'lab'), 0, { id: 'import', title: 'Import & sample data', group: 'Tools', icon: 'upload', perm: 'lab', live: true });

(() => { const base = Books.reseed.bind(Books); Books.reseed = function () { base(); const b = this.cur(); if (!(b.gstr2b || []).length) { try { b.gstr2b = GSTR2B.sample(); this.save(); } catch (e) { /* optional */ } } }; })();
