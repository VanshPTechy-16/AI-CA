/* ===================== WELCOME, ACCESS, VALIDATION, ENTITY TEMPLATES ===================== */
/* ---------- Reporting frameworks (FRF) registry; the statement engine extends this ---------- */
const FRF = {
  list: {
    indas: { name: 'Ind AS (Schedule III, Division II)', short: 'Ind AS', law: 'Companies Act, 2013; Companies (Indian Accounting Standards) Rules, 2015' },
    as: { name: 'Accounting Standards (Schedule III, Division I)', short: 'AS', law: 'Companies Act, 2013; Companies (Accounting Standards) Rules, 2021' },
    llp: { name: 'LLP and partnership firms (Accounting Standards)', short: 'AS (LLP)', law: 'LLP Act, 2008; ICAI Guidance Note on Accounting and Auditing by LLPs' },
    noncorp: { name: 'Non-corporate entities (Accounting Standards)', short: 'AS (Non-corporate)', law: 'Accounting Standards notified for Level II/III non-corporate entities' },
    trust: { name: 'Trusts and NGOs (Income and Expenditure format)', short: 'Trust format', law: 'ICAI Guidance Note on Accounting by Charitable Institutions; Income-tax Act' }
  },
  name(id) { return (this.list[id] || {}).name || id; }
};

/* ---------- Statutory validators: every message states the required format ---------- */
const Val = {
  ok: (extra = {}) => ({ ok: true, msg: '', ...extra }), bad: (msg, hint) => ({ ok: false, msg, hint }),
  gstin(v, opt = {}) {
    v = String(v || '').toUpperCase().trim(); if (!v) return opt.optional ? this.ok() : this.bad('GSTIN is required. Format: 2-digit state code + 10-character PAN + entity number + Z + check digit (for example 24AAACN1234A1Z8).');
    const r = GST.validate(v); if (!r.ok) return this.bad('Invalid GSTIN: ' + r.reason); if (opt.pan && r.pan !== String(opt.pan).toUpperCase()) return this.bad('GSTIN contains PAN ' + r.pan + ' but the PAN entered is ' + String(opt.pan).toUpperCase() + '. Characters 3 to 12 of a GSTIN are the PAN.');
    return this.ok(r);
  },
  pan(v, opt = {}) {
    v = String(v || '').toUpperCase().trim(); if (!v) return opt.optional ? this.ok() : this.bad('PAN is required. Format: 5 letters + 4 digits + 1 letter (for example AAACN1234A).');
    if (!/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(v)) return this.bad('Invalid PAN. Format: 5 letters + 4 digits + 1 letter (for example AAACN1234A).');
    const t = CONFIG.panTypes[v[3]]; if (!t) return this.bad('The 4th character of a PAN must be one of ' + Object.keys(CONFIG.panTypes).join(', ') + ' (holder type). You entered ' + v[3] + '.');
    if (opt.constitution) { const want = { 'Private Limited': 'C', 'Public Limited': 'C', 'LLP': 'F', 'Partnership firm': 'F', 'Proprietorship': 'P', 'Trust': 'T' }[opt.constitution]; if (want && v[3] !== want) return this.bad('PAN 4th character is ' + v[3] + ' (' + t + ') but the constitution is ' + opt.constitution + '. It should be ' + want + '.'); }
    return this.ok({ type: t });
  },
  tan(v, o = {}) { v = String(v || '').toUpperCase().trim(); if (!v) return o.optional ? this.ok() : this.bad('TAN is required. Format: 4 letters + 5 digits + 1 letter (for example AHMA12345B).'); return /^[A-Z]{4}[0-9]{5}[A-Z]$/.test(v) ? this.ok() : this.bad('Invalid TAN. Format: 4 letters + 5 digits + 1 letter (for example AHMA12345B).'); },
  cin(v, o = {}) { v = String(v || '').toUpperCase().trim(); if (!v) return o.optional ? this.ok() : this.bad('CIN is required. Format: 21 characters, for example U24100GJ2015PTC123456.'); return /^[LU][0-9]{5}[A-Z]{2}[0-9]{4}[A-Z]{3}[0-9]{6}$/.test(v) ? this.ok() : this.bad('Invalid CIN. Format: L or U + 5-digit industry code + 2-letter state + 4-digit year + 3-letter company type + 6-digit number (21 characters).'); },
  llpin(v, o = {}) { v = String(v || '').toUpperCase().trim(); if (!v) return o.optional ? this.ok() : this.bad('LLPIN is required. Format: AAA-1234.'); return /^[A-Z]{3}-[0-9]{4}$/.test(v) ? this.ok() : this.bad('Invalid LLPIN. Format: 3 letters, a hyphen and 4 digits (for example AAB-1234).'); },
  ifsc(v, o = {}) { v = String(v || '').toUpperCase().trim(); if (!v) return o.optional ? this.ok() : this.bad('IFSC is required. Format: 4 letters + 0 + 6 letters or digits (for example HDFC0001234).'); return /^[A-Z]{4}0[A-Z0-9]{6}$/.test(v) ? this.ok() : this.bad('Invalid IFSC. Format: 4 letters, the digit 0, then 6 letters or digits (for example HDFC0001234).'); },
  account(v, o = {}) { v = String(v || '').trim(); if (!v) return o.optional ? this.ok() : this.bad('Bank account number is required (9 to 18 digits).'); return /^[0-9]{9,18}$/.test(v) ? this.ok() : this.bad('Invalid account number. Use 9 to 18 digits with no spaces.'); },
  udyam(v, o = {}) { v = String(v || '').toUpperCase().trim(); if (!v) return o.optional ? this.ok() : this.bad('Udyam number is required for MSME vendors. Format: UDYAM-XX-00-0000000.'); return /^UDYAM-[A-Z]{2}-[0-9]{2}-[0-9]{7}$/.test(v) ? this.ok() : this.bad('Invalid Udyam number. Format: UDYAM-XX-00-0000000 (for example UDYAM-GJ-01-1234567).'); },
  pin(v, o = {}) { v = String(v || '').trim(); if (!v) return o.optional ? this.ok() : this.bad('PIN code is required (6 digits).'); return /^[1-9][0-9]{5}$/.test(v) ? this.ok() : this.bad('Invalid PIN code. Use 6 digits, not starting with 0 (for example 380001).'); },
  mobile(v, o = {}) { v = String(v || '').replace(/[\s+\-]/g, '').replace(/^91(?=[6-9]\d{9}$)/, ''); if (!v) return o.optional ? this.ok() : this.bad('Mobile number is required (10 digits).'); return /^[6-9][0-9]{9}$/.test(v) ? this.ok() : this.bad('Invalid mobile number. Use 10 digits starting with 6, 7, 8 or 9.'); },
  email(v, o = {}) { v = String(v || '').trim(); if (!v) return o.optional ? this.ok() : this.bad('Email is required.'); return /^[^\s@,]+@[^\s@,]+\.[^\s@,]{2,}$/.test(v) ? this.ok() : this.bad('Invalid email. Format: name@company.in'); },
  date(v, o = {}) { v = String(v || '').trim(); if (!v) return o.optional ? this.ok() : this.bad('Date is required (DD-MM-YYYY).'); if (!/^\d{4}-\d{2}-\d{2}$/.test(v) || isNaN(new Date(v))) return this.bad('Invalid date. Use a real calendar date.'); if (o.noFuture && v > isoToday()) return this.bad('The date cannot be in the future.'); if (o.min && v < o.min) return this.bad('The date cannot be before ' + fmtDate(o.min) + '.'); return this.ok(); },
  amount(v, o = {}) { const n = parseFloat(v); if (v === '' || v == null || isNaN(n)) return o.optional ? this.ok() : this.bad('Enter an amount in rupees (numbers only).'); if (n < 0 && !o.allowNeg) return this.bad('The amount cannot be negative.'); if (o.positive && n <= 0) return this.bad('The amount must be greater than zero.'); if (Math.round(n * 100) / 100 !== n) return this.bad('Use at most 2 decimal places for rupee amounts.'); return this.ok(); },
  state(v) { return CONFIG.states.some(s => s[0] === String(v)) ? this.ok() : this.bad('Invalid state code. Use a 2-digit GST state code (for example 24 for Gujarat).'); },
  invoiceNo(v, o = {}) { v = String(v || '').trim(); if (!v) return this.bad('Invoice number is required.'); if (v.length > 16) return this.bad('Invoice number can have at most 16 characters (Rule 46 of the CGST Rules). You entered ' + v.length + '.'); if (!/^[A-Za-z0-9\/\-]+$/.test(v)) return this.bad('Invoice number may contain only letters, digits, hyphen (-) and slash (/). Remove spaces and other symbols.'); return this.ok(); },
  gstRate(v) { return CONFIG.gst.rates.includes(+v) ? this.ok() : this.bad('GST rate must be one of ' + CONFIG.gst.rates.join('%, ') + '%.'); },
  hsnDigits() { try { const b = Books.cur(), fy = App.session.fy || fyNow(), r = fyRange(fy); const t = sum(b.vouchers.filter(v => v.status === 'posted' && v.type === 'Sales' && v.date >= r.from && v.date <= r.to), v => (v.meta && v.meta.taxable) || 0); return t > 5e7 ? 6 : 4; } catch (e) { return 4; } },
  hsn(code, o = {}) {
    code = String(code || '').replace(/\s/g, ''); const svc = !!o.service; if (!code) return this.bad('HSN/SAC code is required on a tax invoice. Goods: HSN of ' + this.hsnDigits() + ' or more digits; services: 6-digit SAC starting with 99.');
    if (!/^[0-9]+$/.test(code)) return this.bad('HSN/SAC must contain digits only.');
    if (code.startsWith('99')) { if (code.length !== 6) return this.bad('A service code (SAC) must have exactly 6 digits and start with 99 (for example 998313).'); }
    else { if (svc) return this.bad('Services use a 6-digit SAC starting with 99, not an HSN.'); if (![2, 4, 6, 8].includes(code.length)) return this.bad('HSN must have 4, 6 or 8 digits. You entered ' + code.length + '.'); const need = o.export ? 8 : this.hsnDigits(); if (code.length < need) return this.bad('At least ' + need + ' digits are required for ' + (o.export ? 'exports' : 'your turnover band (' + (need === 6 ? 'above' : 'up to') + ' ₹5 crore)') + '. You entered ' + code.length + '.'); }
    const row = (CONFIG.hsn || []).find(h => code.startsWith(h[0]) || h[0].startsWith(code.slice(0, 4))); const out = { ok: true, msg: '', known: !!row, rate: row ? row[2] : null, desc: row ? row[1] : '' };
    if (!row) out.warn = 'This code is not in the built-in HSN master. Confirm the code and rate on the GST portal.';
    if (row && o.rate != null && o.rate !== '' && +o.rate !== row[2]) return this.bad('HSN ' + code + ' (' + row[1] + ') attracts GST at ' + row[2] + '%, but ' + o.rate + '% is entered.');
    return out;
  }
};
/* inline field feedback helper for forms */
const fieldMsg = (r) => r.ok ? (r.warn ? `<span class="hint" style="color:var(--amber)">${esc(r.warn)}</span>` : '') : `<span class="err">${esc(r.msg)}</span>`;

/* ---------- Assessee-wise chart of accounts ---------- */
const Entity = {
  info: {
    proprietor: { frf: 'noncorp', label: 'Proprietorship', owner: 'Proprietor', headNote: 'Capital account of the proprietor with drawings' },
    partnership: { frf: 'llp', label: 'Partnership / LLP', owner: 'Partners', headNote: 'Partners’ capital and current accounts' },
    pvt: { frf: 'as', label: 'Private company', owner: 'Shareholders', headNote: 'Share capital, reserves and surplus' },
    listed: { frf: 'indas', label: 'Public / listed company', owner: 'Shareholders', headNote: 'Equity share capital and other equity' },
    trust: { frf: 'trust', label: 'Trust / NGO', owner: 'Trustees', headNote: 'Corpus and general funds' },
    cafirm: { frf: 'noncorp', label: 'CA firm', owner: 'Partners', headNote: 'Partners’ capital and current accounts' }
  },
  template(b, co) {
    const rename = (id, name, group) => { const a = b.accounts.find(x => x.id === id); if (a) { a.name = name; if (group) a.group = group; } };
    const add = (id, name, group, nat, sch) => { if (!b.accounts.some(x => x.id === id)) b.accounts.push({ id, name, group, nat, sch, op: 0, sys: true }); };
    switch (co && co.profile) {
      case 'proprietor': rename('cap', 'Proprietor’s Capital Account', 'Capital'); rename('res', 'Capital reserve (opening adjustments)'); add('drawings', 'Drawings (Proprietor)', 'Capital', 'L', 'eq_res'); add('propint', 'Interest on Capital (memo)', 'Indirect expenses', 'E', 'exp_fin'); break;
      case 'partnership': case 'cafirm': rename('cap', 'Partners’ Capital Accounts', 'Capital'); rename('res', 'Partners’ Current Accounts (opening)'); add('pcur', 'Partners’ Current Accounts', 'Capital', 'L', 'eq_res'); add('pdraw', 'Partners’ Drawings', 'Capital', 'L', 'eq_res'); add('pint', 'Interest on Partners’ Capital', 'Finance costs', 'E', 'exp_fin'); add('prem', 'Partners’ Remuneration', 'Employee cost', 'E', 'exp_emp'); if (co.profile === 'cafirm') add('proffee', 'Professional Fees Received', 'Revenue', 'I', 'rev_ops'); break;
      case 'pvt': case 'listed': add('secprem', 'Securities Premium', 'Reserves', 'L', 'eq_res'); add('divpay', 'Dividend Payable', 'Provisions', 'L', 'cl_oth'); add('dirrem', 'Directors’ Remuneration', 'Employee cost', 'E', 'exp_emp'); add('auditfee', 'Auditors’ Remuneration', 'Indirect expenses', 'E', 'exp_oth'); if (co.profile === 'listed') add('lodrfee', 'Listing and Depository Fees', 'Indirect expenses', 'E', 'exp_oth'); break;
      case 'trust': rename('cap', 'Corpus Fund', 'Funds'); rename('res', 'General Fund (accumulated surplus)', 'Funds'); add('restr', 'Restricted / Designated Funds', 'Funds', 'L', 'eq_res'); add('donation', 'Donations and Grants Received', 'Income', 'I', 'rev_ops'); add('progfee', 'Programme and Service Fees', 'Income', 'I', 'rev_ops'); add('prog', 'Programme Expenses', 'Expenditure', 'E', 'exp_oth'); add('adminx', 'Administrative Expenses', 'Expenditure', 'E', 'exp_oth'); break;
    }
  },
  frfFor(co) { return (co && co.frf) || (this.info[co && co.profile] || this.info.pvt).frf; }
};
(() => { const base = Books.blank.bind(Books); Books.blank = function (co) { const b = base(co); try { Entity.template(b, co); } catch (e) { console.error(e); } return b; }; })();

/* ---------- Company access ---------- */
const Access = {
  can(user, coId) { return !user.companies || !user.companies.length || user.companies.includes(coId); },
  companiesFor(user) { return App.core.companies.filter(c => this.can(user, c.id)); },
  reqs() { App.core.accessRequests = App.core.accessRequests || []; return App.core.accessRequests; }
};
renderSwitchers = function () {
  const co = App.company, list = Access.companiesFor(App.user); if (!list.some(c => c.id === co.id)) { App.core.activeCompanyId = list[0] ? list[0].id : co.id; }
  const cur = App.company;
  $('#co-select').innerHTML = list.map(c => `<option value="${c.id}" ${c.id === cur.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('') + (App.role && App.role.id === 'admin' ? '<option value="__add">+ Add company…</option>' : '');
  const fyNow_ = fyStartOf(), start = Math.min(cur.fyStart || fyNow_, fyNow_); const ys = []; for (let y = fyNow_; y >= start; y--) ys.push(y);
  if (!App.session.fy || !ys.includes(App.session.fy)) App.session.fy = cur.fyStart || fyNow_;
  $('#fy-select').innerHTML = ys.map(y => `<option value="${y}" ${y === App.session.fy ? 'selected' : ''}>FY ${fyLabel(y)}</option>`).join('');
};

/* ---------- Welcome page ---------- */
const WL = { co: null, user: null, q: '' };
const DEMO_PEOPLE = [['Riya Shah', 'riya.s', 'admin', '1234'], ['Amit Patel', 'amit.p', 'accountant', '2222'], ['Neha Mehta', 'neha.m', 'approver', '3333'], ['Karthik Iyer', 'karthik.i', 'auditor', '4444']];
function renderWelcome() {
  const cos = App.core.companies;
  $('#app').innerHTML = `<div class="auth">${authSide('Every ledger, every return, every control.', 'Choose a company to continue. Each person sees only the companies they have been given access to.')}
  <main class="auth-main"><div class="auth-card" id="wl-main"></div></main></div>`;
  WL.co ? drawSignIn() : drawCompanies();
}
function drawCompanies() {
  const cos = App.core.companies, q = WL.q.toLowerCase(), shown = cos.filter(c => !q || (c.name + ' ' + (c.gstin || '') + ' ' + profileOf(c).name).toLowerCase().includes(q));
  $('#wl-main').innerHTML = `<h1>Welcome to ${esc(CONFIG.app.name)}</h1><p class="muted" style="margin-top:6px">Select the company you want to work on.</p>
    ${cos.length > 3 ? `<div class="field" style="margin-top:16px"><label class="sr" for="wl-q">Search companies</label><input id="wl-q" type="search" placeholder="Search companies by name or GSTIN…" value="${esc(WL.q)}"></div>` : ''}
    <div class="co-grid" role="list" style="margin-top:16px">${shown.length ? shown.map(c => `<button class="co-card" role="listitem" data-act="wl-co" data-arg="${c.id}"><span class="avatar">${esc(initials(c.name))}</span><span class="co-meta"><b>${esc(c.name)}</b><small>${esc(profileOf(c).name)} · ${esc(stateName(c.state))}${c.gstin ? ' · ' + esc(c.gstin) : ''}</small></span>${c.demo ? '<span class="chip info">Sample</span>' : ''}</button>`).join('') : `<div class="empty" style="grid-column:1/-1"><b>${cos.length ? 'No company matches' : 'No companies yet'}</b>${cos.length ? 'Clear the search.' : 'Create one, or load the sample company.'}</div>`}</div>
    <div class="row" style="margin-top:20px"><button class="btn primary" data-act="wl-new">${icon('plus')}Create new company</button><button class="btn" data-act="wl-request">${icon('users')}Request access</button>${cos.some(c => c.id === 'co_demo') ? '' : `<button class="btn" data-act="ob-demo">${icon('flask')}Load sample company</button>`}</div>
    <p class="muted small" style="margin-top:18px">Running in ${esc(Env.label)}. ${esc(Store.label)}.</p>`;
  const qi = $('#wl-q'); if (qi) { qi.addEventListener('input', e => { WL.q = e.target.value; const pos = e.target.selectionStart; drawCompanies(); const n = $('#wl-q'); n.focus(); n.setSelectionRange(pos, pos); }); }
}
function drawSignIn() {
  const co = App.core.companies.find(c => c.id === WL.co); if (!co) { WL.co = null; return drawCompanies(); }
  const users = App.core.users.filter(u => u.active && Access.can(u, co.id)); if (!WL.user || !users.some(u => u.id === WL.user)) WL.user = users[0] && users[0].id;
  const demo = { 'riya.s': '1234', 'amit.p': '2222', 'neha.m': '3333', 'karthik.i': '4444' };
  $('#wl-main').innerHTML = `<button class="link" data-act="wl-back">← Choose another company</button><h1 style="margin-top:10px">${esc(co.name)}</h1><p class="muted" style="margin-top:6px">${esc(profileOf(co).name)} · ${esc(stateName(co.state))}. Choose your name, then enter your PIN.</p>
    ${co.demo && App.core.settings.demoPins ? `<div class="note warn" style="margin-top:14px"><b>Sample company PINs:</b> ${users.filter(u => u.demoPin).map(u => `${esc(u.name)} (${esc(App.core.roles.find(r => r.id === u.roleId)?.name)}): <span class="mono">${demo[u.username] || '—'}</span>`).join('; ')}.</div>` : ''}
    ${users.length ? `<div class="users-pick" role="radiogroup" aria-label="Choose user">${users.map(u => `<button class="upick ${u.id === WL.user ? 'on' : ''}" role="radio" aria-checked="${u.id === WL.user}" data-act="wl-user" data-arg="${u.id}"><span class="avatar">${esc(initials(u.name))}</span><span><b style="font-weight:500">${esc(u.name)}</b><small>${esc(App.core.roles.find(r => r.id === u.roleId)?.name || '')}</small></span></button>`).join('')}</div>
    <div class="pin-row"><div class="field" style="flex:1"><label for="login-pin">PIN</label><input id="login-pin" type="password" inputmode="numeric" maxlength="6" autocomplete="current-password"></div><button class="btn primary" data-act="wl-go" style="height:38px">Sign in</button></div><div id="login-err" class="err" style="margin-top:10px" aria-live="assertive"></div>` : '<div class="note warn" style="margin-top:16px">Nobody has access to this company yet. Ask an Admin to add you, or request access below.</div>'}
    <div class="row" style="margin-top:18px"><button class="btn" data-act="wl-request" data-arg="${co.id}">${icon('users')}Request access to this company</button></div>`;
  const pin = $('#login-pin'); if (pin) { pin.focus(); pin.addEventListener('keydown', e => { if (e.key === 'Enter') Actions['wl-go'](); }); }
}
renderLogin = function () { WL.co = null; WL.q = ''; renderWelcome(); };
Object.assign(Actions, {
  'wl-co': id => { WL.co = id; WL.user = null; drawSignIn(); },
  'wl-back': () => { WL.co = null; drawCompanies(); },
  'wl-user': id => { WL.user = id; $$('.upick').forEach(b => { const on = b.dataset.arg === id; b.classList.toggle('on', on); b.setAttribute('aria-checked', on); }); const e = $('#login-err'); if (e) e.textContent = ''; const p = $('#login-pin'); if (p) { p.value = ''; p.focus(); } },
  'wl-go': async () => {
    const u = App.core.users.find(x => x.id === WL.user), co = WL.co; if (!u || !co) return; const err = $('#login-err'), f = App.loginFails[u.id] || { count: 0, until: 0 };
    if (Date.now() < f.until) { err.textContent = `Too many wrong attempts. Try again in ${Math.ceil((f.until - Date.now()) / 1000)} seconds.`; return; }
    if (await Sec.hashPin($('#login-pin').value, u.salt) !== u.pinHash) { f.count++; if (f.count >= 5) { f.until = Date.now() + 30000; f.count = 0; } App.loginFails[u.id] = f; Log.add('Failed sign-in', u.name + ' for ' + (App.core.companies.find(c => c.id === co) || {}).name + (f.until > Date.now() ? ' (locked for 30 seconds)' : '')); err.textContent = f.until > Date.now() ? 'Five wrong attempts. Sign-in is locked for 30 seconds.' : 'That PIN is wrong.'; $('#login-pin').value = ''; $('#login-pin').focus(); return; }
    App.loginFails[u.id] = { count: 0, until: 0 }; App.core.activeCompanyId = co; App.session.userId = u.id; App.saveCore(); enterApp();
  },
  'wl-new': () => { if (!App.core.users.length) { renderOnboarding(); return; } newCompanyModal(); },
  'wl-request': (coId) => requestAccessModal(coId),
  'ob-demo': async () => {
    const R = rng('demo-company'); const pan = Lab.pan(R, 'C', 'Narmada'); let co = App.core.companies.find(c => c.id === 'co_demo');
    if (!co) { co = { id: 'co_demo', name: 'Narmada Polymers Pvt Ltd', profile: 'pvt', gstin: GST.make('24', pan), pan, state: '24', fyStart: fyStartOf(), createdAt: new Date().toISOString(), demo: true }; App.core.companies.push(co); }
    Object.assign(co, Demo2.profile(co)); const roleOk = id => App.core.roles.some(r => r.id === id);
    for (const [name, username, roleId, pin] of DEMO_PEOPLE) { if (App.core.users.some(u => u.username === username) || !roleOk(roleId)) continue; const salt = Sec.salt(); App.core.users.push({ id: uid('u'), name, username, roleId, salt, pinHash: await Sec.hashPin(pin, salt), active: true, demoPin: true, companies: ['co_demo'], createdAt: new Date().toISOString() }); }
    App.core.onboarded = true; App.core.settings.demoPins = true; if (!App.core.activeCompanyId) App.core.activeCompanyId = co.id;
    const items = Compliance.list(co, 45, 0).filter(i => i.days < 0), f = {}, skip = items.filter(i => i.id === 'gstr3b').pop(); items.forEach(i => { if (i !== skip) f[i.key] = { by: 'Riya Shah', at: new Date(+i.due - 2 * DAY).toISOString() }; }); App.core.filings[co.id] = f;
    App.books[co.id] = clone(Lab.get(co).seed.books); Store.save('books_' + co.id, App.books[co.id]); App.saveCore();
    await Log.add('Sample company loaded', co.name); WL.co = co.id; WL.user = null; renderWelcome(); UI.toast('Sample company ready. Its sign-in PINs are shown on screen.', 'good');
  }
});
/* a fully populated sample company profile */
const Demo2 = { profile(co) { return { cin: 'U24100GJ2015PTC084512', tan: 'AHMN12345B', address: '14, GIDC Estate, Naroda Phase II', city: 'Ahmedabad', pincode: '382330', email: 'accounts@narmadapolymers.example', phone: '9825012345', upi: 'narmadapolymers@hdfcbank', bank: { name: 'HDFC Bank', branch: 'Naroda GIDC', acct: '50200012345678', ifsc: 'HDFC0001234' }, frf: 'as', incorpDate: '2015-06-12', signedDate: iso(addD(today0(), 14)), signPlace: 'Ahmedabad',
  auditor: { firm: 'Shah Desai & Associates', frn: '109876W', partner: 'CA Rohan Shah', mno: '123456', place: 'Ahmedabad', udin: '123456' + '280626' + 'AAABCD' },
  people: [{ name: 'Riya Shah', din: '07654321', desig: 'Managing Director' }, { name: 'Vivek Shah', din: '07654322', desig: 'Director' }, { name: 'Meera Patel', din: '08123456', desig: 'Independent Director' }], cs: { name: 'Anita Mehta', mno: 'A45678' }, cfo: { name: 'Neha Mehta' },
  shares: { authShares: '2500000', issuedShares: '1800000', parValue: '10', weighted: '1800000' }, holders: [{ name: 'Riya Shah', shares: '1080000', pct: '60' }, { name: 'Vivek Shah', shares: '540000', pct: '30' }, { name: 'Shah Family Trust', shares: '180000', pct: '10' }],
  py: { rev_ops: '110000000', rev_oth: '650000', exp_cogs: '61000000', exp_inv: '-400000', exp_emp: '19000000', exp_fin: '1350000', exp_dep: '1050000', exp_oth: '17500000', exp_tax: '2300000' },
  rp: [{ name: 'Vivek Shah', rel: 'Director', nature: 'Directors’ remuneration', amt: '1800000', bal: '150000' }, { name: 'Narmada Logistics LLP', rel: 'Entity in which a director is a partner', nature: 'Freight and logistics services availed', amt: '2450000', bal: '310000' }], cl: [{ desc: 'GST demand for FY 2023-24 under appeal before the Commissioner (Appeals); no provision made as outcome is expected to be favourable', amt: '480000' }, { desc: 'Bank guarantee issued to Torrent Power Limited', amt: '2500000' }], capCommit: '3500000', fees: { audit: '300000', tax: '100000', other: '25000' }, csr: { applicable: 'No', spent: '0' },
  security: 'Term loan from State Bank of India is secured by first charge on plant and machinery and personal guarantee of the directors; repayable in 60 monthly instalments, interest 10.5% per annum. Cash credit is secured by hypothecation of current assets.', events: 'No adjusting or significant non-adjusting events occurred between the reporting date and the date of approval of the financial statements.', goingConcern: 'Management has assessed the entity’s ability to continue as a going concern for at least twelve months from the reporting date and has identified no material uncertainty.', rpNil: false,
  reg: { benami: 'Nil. No proceedings have been initiated or are pending.', wilful: 'The company has not been declared a wilful defaulter by any bank or financial institution.', struck: 'Nil. No transactions with struck-off companies.', charges: 'Nil. All charges are registered with the Registrar of Companies.', layers: 'Complied. The company has no subsidiaries.', undisclosed: 'Nil.', crypto: 'Nil.', utilisation: 'No funds were advanced or loaned to any intermediaries or beneficiaries.', immovable: 'The company holds no immovable property in its name.' }, notes: { empBenefit: 'Gratuity is funded through a group gratuity policy; actuarial valuation as at the reporting date shows no material shortfall.', lease: 'No lease exceeding twelve months.' } }; } };

/* ---------- New company (authorised by an Admin PIN) ---------- */
function newCompanyModal() {
  const admins = App.core.users.filter(u => u.active && u.roleId === 'admin');
  UI.modal({ title: 'Create a new company', wide: true, body: `<div class="form-grid"><div class="field full"><label for="nc-name">Legal name</label><input id="nc-name" type="text"><span class="err" id="nc-name-e"></span></div>
    <div class="field"><label for="nc-prof">Entity type (assessee)</label><select id="nc-prof">${CONFIG.profiles.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select><span class="hint" id="nc-frf"></span></div>
    <div class="field"><label for="nc-state">State</label><select id="nc-state">${CONFIG.states.map(s => `<option value="${s[0]}" ${s[0] === '24' ? 'selected' : ''}>${esc(s[1])} (${s[0]})</option>`).join('')}</select></div>
    <div class="field"><label for="nc-pan">PAN</label><input id="nc-pan" type="text" maxlength="10" style="text-transform:uppercase"><span id="nc-pan-e"></span></div>
    <div class="field"><label for="nc-gst">GSTIN (optional)</label><input id="nc-gst" type="text" maxlength="15" style="text-transform:uppercase"><span id="nc-gst-e"></span></div>
    <div class="field"><label for="nc-fy">Books start from</label><select id="nc-fy">${[fyStartOf(), fyStartOf() - 1, fyStartOf() - 2].map(y => `<option value="${y}">FY ${fyLabel(y)}</option>`).join('')}</select></div>
    <div class="field"><label for="nc-seed">Starting data</label><select id="nc-seed"><option value="0">Empty books</option><option value="1">Load a sample year to explore</option></select></div>
    <div class="full"><hr style="border:0;border-top:1px solid var(--line)"></div>
    <div class="field"><label for="nc-adm">Authorise with an Admin</label><select id="nc-adm">${admins.map(a => `<option value="${a.id}">${esc(a.name)}</option>`).join('')}</select></div><div class="field"><label for="nc-pin">Admin PIN</label><input id="nc-pin" type="password" inputmode="numeric" maxlength="6"></div><div id="nc-err" class="err full"></div></div>`,
    onOpen: el => { const upd = () => { const f = Entity.info[$('#nc-prof', el).value]; $('#nc-frf', el).textContent = 'Reporting framework: ' + FRF.name(f.frf); $('#nc-pan-e', el).innerHTML = fieldMsg(Val.pan($('#nc-pan', el).value, { optional: true })); $('#nc-gst-e', el).innerHTML = fieldMsg(Val.gstin($('#nc-gst', el).value, { optional: true, pan: $('#nc-pan', el).value || undefined })); }; ['nc-prof', 'nc-pan', 'nc-gst'].forEach(i => $('#' + i, el).addEventListener('input', upd)); upd(); },
    actions: [{ label: 'Cancel' }, { label: 'Create company', kind: 'primary', onClick: async el => {
      const g = id => $('#' + id, el).value.trim(), err = m => { $('#nc-err', el).textContent = m; return false; }, name = g('nc-name'), pan = g('nc-pan').toUpperCase(), gstin = g('nc-gst').toUpperCase();
      if (name.length < 3) return err('Enter the full legal name of the company (at least 3 characters).');
      const vp = Val.pan(pan, { optional: true }); if (!vp.ok) return err(vp.msg); const vg = Val.gstin(gstin, { optional: true, pan: pan || undefined }); if (!vg.ok) return err(vg.msg);
      if (App.core.companies.some(c => c.name.toLowerCase() === name.toLowerCase())) return err('A company with this name already exists.');
      const adm = App.core.users.find(u => u.id === g('nc-adm')); if (!adm || await Sec.hashPin($('#nc-pin', el).value, adm.salt) !== adm.pinHash) return err('The Admin PIN is wrong.');
      const prof = g('nc-prof'), co = { id: uid('co'), name, profile: prof, gstin, pan: pan || (vg.ok && vg.pan) || '', state: vg.ok && vg.stateCode ? vg.stateCode : g('nc-state'), fyStart: +g('nc-fy'), frf: Entity.info[prof].frf, createdAt: new Date().toISOString() };
      App.core.companies.push(co); const pre = App.session.userId; App.session.userId = adm.id; App.books[co.id] = Books.blank(co); if (g('nc-seed') === '1') { App.books[co.id] = clone(Lab.get(co).seed.books); } Store.save('books_' + co.id, App.books[co.id]); App.saveCore(); await Log.add('Company created', name + ' (' + profileOf(co).name + ') by ' + adm.name); App.session.userId = pre;
      UI.toast(name + ' created. Sign in to continue.', 'good'); WL.co = co.id; WL.user = null; renderWelcome();
    } }] });
}

/* ---------- Request access ---------- */
function requestAccessModal(coId) {
  UI.modal({ title: 'Request access', body: `<p class="muted small" style="margin-bottom:12px">Your request goes to the company’s Admin, who sets your role and PIN. You will not be able to sign in until it is approved.</p><div class="form-grid"><div class="field"><label for="ra-n">Full name</label><input id="ra-n" type="text"></div><div class="field"><label for="ra-e">Email</label><input id="ra-e" type="email"><span id="ra-ee"></span></div>
    <div class="field"><label for="ra-m">Mobile (optional)</label><input id="ra-m" type="text" maxlength="14"><span id="ra-me"></span></div><div class="field"><label for="ra-r">Role you need</label><select id="ra-r">${App.core.roles.filter(r => r.id !== 'admin').map(r => `<option value="${r.id}" ${r.id === 'accountant' ? 'selected' : ''}>${esc(r.name)}</option>`).join('')}</select></div>
    <div class="field full"><label for="ra-c">Company</label><select id="ra-c">${App.core.companies.map(c => `<option value="${c.id}" ${c.id === coId ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div><div class="field full"><label for="ra-w">Why do you need access?</label><textarea id="ra-w" rows="3"></textarea></div><div id="ra-err" class="err full"></div></div>`,
    onOpen: el => { const upd = () => { $('#ra-ee', el).innerHTML = $('#ra-e', el).value ? fieldMsg(Val.email($('#ra-e', el).value)) : ''; $('#ra-me', el).innerHTML = fieldMsg(Val.mobile($('#ra-m', el).value, { optional: true })); }; ['ra-e', 'ra-m'].forEach(i => $('#' + i, el).addEventListener('input', upd)); },
    actions: [{ label: 'Cancel' }, { label: 'Send request', kind: 'primary', onClick: el => {
      const g = id => $('#' + id, el).value.trim(), err = m => { $('#ra-err', el).textContent = m; return false; };
      if (g('ra-n').length < 3) return err('Enter your full name.'); const ve = Val.email(g('ra-e')); if (!ve.ok) return err(ve.msg); const vm = Val.mobile(g('ra-m'), { optional: true }); if (!vm.ok) return err(vm.msg); if (g('ra-w').length < 5) return err('Tell the Admin why you need access (a short sentence is enough).');
      if (Access.reqs().some(r => r.email.toLowerCase() === g('ra-e').toLowerCase() && r.companyId === g('ra-c') && r.status === 'pending')) return err('You already have a pending request for this company.');
      Access.reqs().push({ id: uid('rq'), name: g('ra-n'), email: g('ra-e'), mobile: g('ra-m'), roleId: g('ra-r'), companyId: g('ra-c'), note: g('ra-w'), at: new Date().toISOString(), status: 'pending' }); App.saveCore(); Log.add('Access requested', g('ra-n') + ' for ' + (App.core.companies.find(c => c.id === g('ra-c')) || {}).name); UI.toast('Request sent to the company Admin.', 'good');
    } }] });
}

/* ---------- Admin: add users with company access, approve requests ---------- */
function userAccessModal({ title, req, user }) {
  const cos = App.core.companies, sel = new Set(user ? (user.companies && user.companies.length ? user.companies : cos.map(c => c.id)) : [req ? req.companyId : App.company.id]);
  UI.modal({ title, wide: true, body: `<div class="form-grid">${user ? '' : `<div class="field"><label for="ua-n">Full name</label><input id="ua-n" type="text" value="${esc(req ? req.name : '')}"></div><div class="field"><label for="ua-u">Username</label><input id="ua-u" type="text" placeholder="e.g. amit.p" value="${esc(req ? req.email.split('@')[0].toLowerCase().replace(/[^a-z0-9._-]/g, '') : '')}"></div>`}
    <div class="field"><label for="ua-r">Role</label><select id="ua-r">${App.core.roles.map(r => `<option value="${r.id}" ${(user ? user.roleId : req ? req.roleId : 'accountant') === r.id ? 'selected' : ''}>${esc(r.name)}</option>`).join('')}</select></div>
    ${user ? '' : `<div class="field"><label for="ua-p">Starting PIN (4 to 6 digits)</label><input id="ua-p" type="password" inputmode="numeric" maxlength="6"><span class="hint">They should change it at first sign-in.</span></div>`}
    <div class="field full"><label>Companies this person can open</label><div class="co-pick">${cos.map(c => `<label class="row small" style="gap:8px;cursor:pointer"><input type="checkbox" data-co="${c.id}" ${sel.has(c.id) ? 'checked' : ''}> ${esc(c.name)}</label>`).join('')}</div></div><div id="ua-warn" class="full"></div><div id="ua-err" class="err full"></div></div>`,
    onOpen: el => { const w = () => { const r = App.core.roles.find(x => x.id === $('#ua-r', el).value), c = Sod.roleConflicts(r); $('#ua-warn', el).innerHTML = c.length && !r.system ? `<div class="note warn">This role has ${c.length} segregation-of-duties conflict(s); the user will be flagged.</div>` : ''; }; $('#ua-r', el).addEventListener('change', w); w(); },
    actions: [{ label: 'Cancel' }, { label: user ? 'Save access' : 'Create user', kind: 'primary', onClick: async el => {
      const err = m => { $('#ua-err', el).textContent = m; return false; }, picked = $$('[data-co]', el).filter(i => i.checked).map(i => i.dataset.co); if (!picked.length) return err('Select at least one company.');
      const roleId = $('#ua-r', el).value, access = picked.length === cos.length ? [] : picked;
      if (user) { user.roleId = roleId; user.companies = access; App.saveCore(); Log.add('User access changed', user.name + ': ' + (access.length ? picked.length + ' companies' : 'all companies')); UI.toast('Access updated', 'good'); Router.render(); return; }
      const name = $('#ua-n', el).value.trim(), username = $('#ua-u', el).value.trim().toLowerCase(), p = $('#ua-p', el).value; if (name.length < 2) return err('Enter the user’s full name.'); if (!/^[a-z0-9._-]{3,30}$/.test(username)) return err('Username: 3 to 30 characters, lowercase letters, digits, dot, dash or underscore.'); if (App.core.users.some(u => u.username === username)) return err('That username is already taken.'); if (!/^\d{4,6}$/.test(p)) return err('PIN must be 4 to 6 digits.'); if (/^(\d)\1+$/.test(p) || '0123456789'.includes(p)) return err('Choose a PIN that is not a repeated or sequential pattern.');
      const salt = Sec.salt(); App.core.users.push({ id: uid('u'), name, username, roleId, salt, pinHash: await Sec.hashPin(p, salt), active: true, companies: access, createdAt: new Date().toISOString() });
      if (req) { req.status = 'approved'; req.decidedBy = App.user.name; req.decidedAt = new Date().toISOString(); }
      App.saveCore(); Log.add('User added', name + ' (' + username + ') as ' + App.core.roles.find(r => r.id === roleId).name + (req ? ', from access request' : '')); UI.toast('User created', 'good'); Router.render();
    } }] });
}
Actions['user-add'] = () => userAccessModal({ title: 'Add user' });
Actions['user-access'] = id => userAccessModal({ title: 'Company access', user: App.core.users.find(u => u.id === id) });
Actions['req-approve'] = id => userAccessModal({ title: 'Approve access request', req: Access.reqs().find(r => r.id === id) });
Actions['req-reject'] = id => { const r = Access.reqs().find(x => x.id === id); UI.modal({ title: 'Reject request', body: `<p style="margin-bottom:10px">Reject the request from <b>${esc(r.name)}</b>?</p><div class="field"><label for="rr">Reason (shown in the audit trail)</label><textarea id="rr" rows="2"></textarea></div>`, actions: [{ label: 'Cancel' }, { label: 'Reject', kind: 'danger', onClick: el => { const t = $('#rr', el).value.trim(); if (t.length < 3) { UI.toast('Enter a reason.', 'error'); return false; } r.status = 'rejected'; r.reason = t; r.decidedBy = App.user.name; r.decidedAt = new Date().toISOString(); App.saveCore(); Log.add('Access request rejected', r.name + ': ' + t); Router.render(); } }] }); };
(() => { const base = Views.users; Views.users = function () {
  let html = base(); if (App.ui.usersTab !== 'users' || !App.can('controls', 'view')) return html; const edit = App.can('controls', 'edit'), reqs = Access.reqs().slice().reverse();
  html += `<div class="card" style="margin-top:18px"><div class="card-head"><h2>Company access</h2><span class="muted small">Who can open which company</span></div><div class="table-wrap"><table class="t"><thead><tr><th>User</th><th>Companies</th><th></th></tr></thead><tbody>${App.core.users.map(u => `<tr><td>${esc(u.name)}</td><td>${Access.companiesFor(u).map(c => `<span class="chip">${esc(c.name)}</span>`).join(' ') || '—'}${!u.companies || !u.companies.length ? ' <span class="muted small">(all)</span>' : ''}</td><td class="amt">${edit ? `<button class="btn sm" data-act="user-access" data-arg="${u.id}">Change</button>` : ''}</td></tr>`).join('')}</tbody></table></div></div>
    <div class="card" style="margin-top:18px"><div class="card-head"><h2>Access requests</h2><span class="chip ${reqs.some(r => r.status === 'pending') ? 'warn' : ''}">${reqs.filter(r => r.status === 'pending').length} pending</span></div>${reqs.length ? `<div class="table-wrap"><table class="t"><thead><tr><th>Name</th><th>Company</th><th>Role wanted</th><th>Reason</th><th>Status</th><th></th></tr></thead><tbody>${reqs.map(r => `<tr><td><b style="font-weight:500">${esc(r.name)}</b><div class="small muted">${esc(r.email)}</div></td><td>${esc((App.core.companies.find(c => c.id === r.companyId) || {}).name || '—')}</td><td>${esc((App.core.roles.find(x => x.id === r.roleId) || {}).name || '')}</td><td class="small" style="max-width:240px">${esc(r.note)}</td><td><span class="chip ${r.status === 'approved' ? 'good' : r.status === 'rejected' ? 'bad' : 'warn'}">${r.status}</span></td><td class="amt">${edit && r.status === 'pending' ? `<div class="row-actions"><button class="btn sm primary" data-act="req-approve" data-arg="${r.id}">Approve</button><button class="btn sm danger" data-act="req-reject" data-arg="${r.id}">Reject</button></div>` : ''}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty"><b>No requests</b>People can ask for access from the first page.</div>'}</div>`;
  return html; }; })();
