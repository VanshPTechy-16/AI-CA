/* ===================== FORMS: MANDATORY FIELDS, CLOSE GUARD, SEARCHABLE SELECTS, REFRESH ===================== */
/* ---------- Modal close guard ---------- */
UI.modalBase = UI.modal;
UI.modal = function (o) {
  const guard = o.guard; if (!guard) return UI.modalBase(o);
  const close = UI.modalBase(o), root = $('#modal-root'), tryClose = e => { if (guard() === false) { e.stopImmediatePropagation(); e.preventDefault(); } };
  const x = root.querySelector('[data-close]'), scrim = root.querySelector('.scrim');
  if (x) x.addEventListener('click', tryClose, true); if (scrim) scrim.addEventListener('mousedown', e => { if (e.target.classList.contains('scrim')) tryClose(e); }, true);
  const key = e => { if (e.key === 'Escape' && root.querySelector('.modal') && !SS.open) tryClose(e); }; document.addEventListener('keydown', key, true);
  const obs = new MutationObserver(() => { if (!root.querySelector('.modal')) { document.removeEventListener('keydown', key, true); obs.disconnect(); } }); obs.observe(root, { childList: true });
  return close;
};

/* ---------- Mandatory fields for posting (what a detailed set of statements needs) ---------- */
VForm.missing = function () {
  const s = this.s, T = s.type, m = [], add = (key, label, msg) => m.push({ key, label, msg }), P = s.party ? Books.party(s.party) : null, A = s.acc ? Books.party(s.acc) : null, co = App.company;
  const vd = Val.date(s.date); if (!vd.ok) add('date', 'Date', vd.msg); else if (s.date > isoToday()) add('date', 'Date', 'A voucher cannot be dated in the future. Use today or an earlier date.');
  if (!s.narr || s.narr.trim().length < 5) add('narr', 'Narration', 'Describe the transaction in at least 5 characters. Auditors read this to understand the entry.');
  if (T === 'Journal') {
    const idx = s.lines.map((l, i) => ({ l, i })).filter(x => x.l.acc || nz(x.l.dr) || nz(x.l.cr)), used = idx.map(x => x.l); if (used.length < 2) add('lines', 'Lines', 'A journal needs at least two lines, one debit and one credit.');
    idx.forEach(({ l, i }) => { if (!l.acc) add('l' + i + ':acc', 'Line ' + (i + 1) + ' ledger', 'Choose the ledger for line ' + (i + 1) + '.'); if (!!nz(l.dr) === !!nz(l.cr)) add('l' + i + ':dr', 'Line ' + (i + 1) + ' amount', 'Enter either a debit or a credit on line ' + (i + 1) + ', not both and not neither.'); });
    const dr = sum(used, l => nz(l.dr)), cr = sum(used, l => nz(l.cr)); if (used.length >= 2 && Math.abs(dr - cr) > 0.005) add('lines', 'Balance', 'Debits ' + fmt2(dr) + ' and credits ' + fmt2(cr) + ' differ by ' + fmt2(Math.abs(dr - cr)) + '.');
  } else if (T === 'Payment' || T === 'Receipt' || T === 'Contra') {
    const va = Val.amount(s.amount, { positive: true }); if (!va.ok) add('amount', 'Amount', va.msg); if (!s.acc) add('acc', T === 'Payment' ? 'Paid to' : T === 'Receipt' ? 'Received from' : 'To account', 'Choose the ledger.');
    if (T === 'Contra' && s.acc && !['cash', 'bank'].includes(s.acc)) add('acc', 'To account', 'A contra entry moves money between cash and bank only.');
    if (s.bankAcc === 'bank' && T !== 'Contra') { const r = String(s.ref || '').trim(); if (!/^[A-Za-z0-9\-\/]{6,22}$/.test(r)) add('ref', 'UTR / cheque / reference', 'Enter the bank reference (UTR, cheque or transaction number): 6 to 22 letters or digits. It is needed to reconcile the bank statement.'); }
    if (T === 'Payment' && A && A.kind === 'V') { const sec = A.tds && A.tds !== 'None' ? A.tds : ''; if (sec && !s.tdsSec && !s.tdsAck && nz(s.amount) >= ((CONFIG.tds.find(t => t.sec === sec) || {}).single || 30000)) add('tdsSec', 'TDS', 'This vendor is set up for TDS under section ' + sec + '. Select the section, or tick the box confirming TDS is not applicable.'); }
  } else {
    const isS = T === 'Sales' || T === 'Credit Note', Q = isS ? P : P; if (!s.party) add('party', isS ? 'Customer' : 'Vendor', 'Choose the ' + (isS ? 'customer' : 'vendor') + '.');
    if (P) { const reg = P.gstin ? Val.gstin(P.gstin) : null; if (P.gstin && reg && !reg.ok && !s.b2c) add('party', 'GSTIN of ' + P.name, reg.msg + ' Correct it in the master, or tick "Treat as unregistered".'); if (!P.gstin && isS && T === 'Sales' && !s.b2c) add('party', 'GSTIN of ' + P.name, 'This customer has no GSTIN. Tick "Treat as unregistered" to raise a B2C invoice.'); if (!isS && !P.gstin && !s.b2c && s.itc) add('party', 'GSTIN of ' + P.name, 'This vendor has no GSTIN, so input tax credit cannot be claimed. Untick the credit box or tick "Treat as unregistered".'); }
    if (!isS) { const bn = Val.invoiceNo(s.billNo); if (!bn.ok) add('billNo', 'Vendor bill number', bn.msg); }
    const its = s.items.filter(i => i.desc || i.hsn || nz(i.rate)); if (!its.length) add('items', 'Items', 'Add at least one line item.');
    its.forEach((it, i) => { const n = 'Item ' + (i + 1); if (String(it.desc || '').trim().length < 3) add('i' + i + ':desc', n + ' description', 'Describe item ' + (i + 1) + ' (at least 3 characters).'); const h = Val.hsn(it.hsn, { rate: it.gst, service: false }); if (!h.ok) add('i' + i + ':hsn', n + ' HSN/SAC', h.msg); if (!(nz(it.qty) > 0)) add('i' + i + ':qty', n + ' quantity', 'Quantity must be greater than zero.'); if (!(nz(it.rate) > 0)) add('i' + i + ':rate', n + ' rate', 'Rate must be greater than zero.'); const gr = Val.gstRate(it.gst); if (!gr.ok) add('i' + i + ':gst', n + ' GST rate', gr.msg); if (!isS && !it.ledger) add('i' + i + ':ledger', n + ' expense ledger', 'Choose the expense or asset ledger. The financial statements are built from it.'); });
  }
  return m;
};
VForm.dirty = function () { return JSON.stringify(this.s) !== this._snap; };
VForm.guard = function () { if (!this.dirty() || this._warnedAt && Date.now() - this._warnedAt < 6000) return true; this._warnedAt = Date.now(); this.refresh(); return false; };
VForm.show = function () {
  if (this.closeFn) this.closeFn(); const s = this.s; this._warnedAt = 0; s._tried = false; this._snap = JSON.stringify(s);
  this.closeFn = UI.modal({ title: 'New ' + s.type + ' voucher', wide: true, body: this.body(), guard: () => this.guard(), actions: [{ label: 'Cancel', onClick: () => { if (this.dirty() && !(this._warnedAt && Date.now() - this._warnedAt < 6000)) { this._warnedAt = Date.now(); this.refresh(); return false; } } }, { label: 'Save', kind: 'primary', stay: true, onClick: async (el, close) => { if (await this.save()) close(); return false; } }], onOpen: el => { this.bind(el); this.refresh(); } });
};
const _vfRefresh = VForm.refresh.bind(VForm), _vfSave = VForm.save.bind(VForm);
VForm.refresh = function () {
  _vfRefresh(); const box = $('#vf-sum'); if (!box) return; const s = this.s, miss = this.missing(), warn = this._warnedAt && Date.now() - this._warnedAt < 6000;
  $$('.field-bad', $('.modal')).forEach(e => e.classList.remove('field-bad'));
  miss.forEach(x => { let q = null; const k = x.key; if (/^l(\d+):(acc|dr)$/.test(k)) { const [, i, f] = k.match(/^l(\d+):(acc|dr)$/); q = $(`[data-l="${i}:${f}"]`); } else if (/^i(\d+):(\w+)$/.test(k)) { const [, i, f] = k.match(/^i(\d+):(\w+)$/); q = $(`[data-i="${i}:${f}"]`); } else q = $(`[data-f="${k}"]`); if (q && (s._tried || ['hsn', 'billNo'].some(z => k.endsWith(z)))) q.classList.add('field-bad'); });
  const panel = `<div class="miss ${s._tried ? 'tried' : ''}" id="vf-miss"><div class="miss-h"><b>${miss.length ? miss.length + ' mandatory item' + (miss.length > 1 ? 's' : '') + ' to complete before posting' : 'All mandatory fields are complete'}</b>${miss.length ? '' : ' <span class="chip good">Ready to post</span>'}</div>${miss.length ? `<ul>${miss.map(x => `<li><button type="button" class="link" data-vf-focus="${esc(x.key)}">${esc(x.label)}</button>: ${esc(x.msg)}</li>`).join('')}</ul>` : ''}${warn ? '<div class="note warn" style="margin-top:8px"><b>You have unsaved entries.</b> Closing now discards them. Close again within a few seconds to discard, or keep working.</div>' : ''}</div>`;
  box.insertAdjacentHTML('afterbegin', panel);
  const sv = $('.modal footer .btn.primary'); if (sv) sv.title = miss.length ? 'Complete the mandatory items listed above' : '';
};
VForm.save = async function () {
  const miss = this.missing(); if (miss.length) { this.s._tried = true; this.refresh(); const first = miss[0], q = (() => { const k = first.key; let m; if ((m = k.match(/^l(\d+):(acc|dr)$/))) return $(`[data-l="${m[1]}:${m[2]}"]`); if ((m = k.match(/^i(\d+):(\w+)$/))) return $(`[data-i="${m[1]}:${m[2]}"]`); return $(`[data-f="${k}"]`); })(); if (q && q.focus) { q.focus(); q.scrollIntoView && q.scrollIntoView({ block: 'center' }); } UI.toast('Complete the ' + miss.length + ' mandatory item' + (miss.length > 1 ? 's' : '') + ' marked in red. The entry stays open.', 'error'); return false; }
  return _vfSave();
};
document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('[data-vf-focus]'); if (!b) return; const k = b.dataset.vfFocus; let m, q; if ((m = k.match(/^l(\d+):(acc|dr)$/))) q = $(`[data-l="${m[1]}:${m[2]}"]`); else if ((m = k.match(/^i(\d+):(\w+)$/))) q = $(`[data-i="${m[1]}:${m[2]}"]`); else q = $(`[data-f="${k}"]`); if (q) { q.focus(); q.scrollIntoView && q.scrollIntoView({ block: 'center' }); } });
/* extra mandatory-control checkboxes (unregistered party, TDS not applicable) are rendered into the form body */
const _vfBody = VForm.body.bind(VForm);
VForm.body = function () {
  let h = _vfBody(); const s = this.s, T = s.type; const extra = [];
  if (['Sales', 'Credit Note', 'Purchase', 'Debit Note'].includes(T)) extra.push(`<label class="row small" style="gap:6px"><input type="checkbox" data-f="b2c" ${s.b2c ? 'checked' : ''}> Treat the ${T === 'Sales' || T === 'Credit Note' ? 'customer' : 'vendor'} as unregistered (no GSTIN)</label>`);
  if (T === 'Payment') extra.push(`<label class="row small" style="gap:6px"><input type="checkbox" data-f="tdsAck" ${s.tdsAck ? 'checked' : ''}> TDS is not applicable on this payment</label>`);
  return extra.length ? h.replace('<div id="vf-sum"', `<div class="row" style="gap:18px;margin:10px 0">${extra.join('')}</div><div id="vf-sum"`) : h;
};
/* open the voucher form even when AI/imports give only partial data: nothing is lost, missing items are listed */

/* ---------- Searchable dropdowns ---------- */
const SS = {
  min: 5, open: null,
  enhance(sel) {
    if (sel.__ss || sel.multiple || sel.dataset.nosearch !== undefined || sel.size > 1 || sel.options.length < this.min) return; sel.__ss = true;
    const w = document.createElement('div'); w.className = 'ss'; const st = sel.getAttribute('style') || ''; if (/width\s*:\s*auto|max-width/.test(st)) w.setAttribute('style', st.replace(/height[^;]*;?/, ''));
    w.innerHTML = `<button type="button" class="ss-btn" aria-haspopup="listbox" aria-expanded="false"><span class="ss-label"></span><svg class="ss-chev" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button><div class="ss-pop" hidden><input type="search" class="ss-q" placeholder="Search…" aria-label="Search options" autocomplete="off"><ul class="ss-list" role="listbox"></ul></div>`;
    sel.after(w); sel.classList.add('ss-native'); sel.tabIndex = -1; sel.setAttribute('aria-hidden', 'true'); w.prepend(sel);
    const btn = $('.ss-btn', w), lab = $('.ss-label', w), pop = $('.ss-pop', w), q = $('.ss-q', w), ul = $('.ss-list', w); let items = [], cur = 0;
    const sync = () => { const o = sel.options[sel.selectedIndex]; lab.textContent = o ? o.text : ''; lab.classList.toggle('ss-ph', !o || !o.value); btn.disabled = sel.disabled; if (sel.id) { const l = document.querySelector(`label[for="${sel.id}"]`); if (l) btn.setAttribute('aria-label', l.textContent); } };
    sel.__sync = sync; sync();
    const build = () => { const f = q.value.toLowerCase().trim(); items = []; let html = ''; let grp = ''; [...sel.children].forEach(ch => { const opts = ch.tagName === 'OPTGROUP' ? [...ch.children].map(o => [o, ch.label]) : [[ch, '']]; opts.forEach(([o, g]) => { if (f && !(o.text + ' ' + g).toLowerCase().includes(f)) return; if (g && g !== grp) { html += `<li class="ss-grp" role="presentation">${esc(g)}</li>`; grp = g; } items.push(o); html += `<li role="option" data-i="${items.length - 1}" class="${o.value === sel.value ? 'sel' : ''}" aria-selected="${o.value === sel.value}">${esc(o.text)}</li>`; }); }); ul.innerHTML = html || '<li class="ss-none">No matches</li>'; cur = Math.max(0, items.findIndex(o => o.value === sel.value)); mark(); };
    const mark = () => { $$('li[role=option]', ul).forEach((li, i) => li.classList.toggle('cur', i === cur)); const c = $$('li[role=option]', ul)[cur]; if (c && c.scrollIntoView) c.scrollIntoView({ block: 'nearest' }); };
    const choose = i => { const o = items[i]; if (!o) return; sel.value = o.value; sync(); close(); sel.dispatchEvent(new Event('input', { bubbles: true })); sel.dispatchEvent(new Event('change', { bubbles: true })); btn.focus(); };
    const place = () => { const r = btn.getBoundingClientRect(), below = innerHeight - r.bottom, h = Math.min(340, Math.max(160, below > 220 ? below - 12 : r.top - 12)); pop.style.left = r.left + 'px'; pop.style.width = Math.max(r.width, 220) + 'px'; pop.style.maxHeight = h + 'px'; if (below > 220 || below > r.top) { pop.style.top = r.bottom + 4 + 'px'; pop.style.bottom = 'auto'; } else { pop.style.top = 'auto'; pop.style.bottom = innerHeight - r.top + 4 + 'px'; } ul.style.maxHeight = (h - 52) + 'px'; };
    const openP = () => { if (btn.disabled) return; if (SS.open && SS.open !== close) SS.open(); q.value = ''; build(); pop.hidden = false; btn.setAttribute('aria-expanded', 'true'); place(); q.focus(); SS.open = close; };
    function close() { pop.hidden = true; btn.setAttribute('aria-expanded', 'false'); if (SS.open === close) SS.open = null; }
    btn.addEventListener('click', () => pop.hidden ? openP() : close());
    btn.addEventListener('keydown', e => { if (['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(e.key) && pop.hidden) { e.preventDefault(); openP(); } });
    q.addEventListener('input', build); ul.addEventListener('mousedown', e => { const li = e.target.closest('li[role=option]'); if (li) { e.preventDefault(); choose(+li.dataset.i); } });
    q.addEventListener('keydown', e => { if (e.key === 'ArrowDown') { cur = Math.min(items.length - 1, cur + 1); mark(); e.preventDefault(); } else if (e.key === 'ArrowUp') { cur = Math.max(0, cur - 1); mark(); e.preventDefault(); } else if (e.key === 'Enter') { choose(cur); e.preventDefault(); e.stopPropagation(); } else if (e.key === 'Escape') { close(); btn.focus(); e.stopPropagation(); e.preventDefault(); } else if (e.key === 'Tab') close(); });
    new MutationObserver(sync).observe(sel, { childList: true, subtree: true, attributes: true, attributeFilter: ['disabled'] });
  },
  scan(root) { $$('select', root || document).forEach(s => this.enhance(s)); }
};
(() => { const d = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value'); Object.defineProperty(HTMLSelectElement.prototype, 'value', { get() { return d.get.call(this); }, set(v) { d.set.call(this, v); if (this.__sync) this.__sync(); }, configurable: true }); })();
(() => { let pend = false; const obs = new MutationObserver(() => { if (pend) return; pend = true; requestAnimationFrame(() => { pend = false; SS.scan(); }); }); obs.observe(document.body, { childList: true, subtree: true }); SS.scan(); })();
document.addEventListener('mousedown', e => { if (SS.open && !e.target.closest('.ss')) SS.open(); }, true);
window.addEventListener('scroll', e => { if (SS.open && !(e.target.closest && e.target.closest('.ss-pop'))) SS.open(); }, true);

/* ---------- Refresh and verify ---------- */
(() => { const w = Store.write.bind(Store); Store.write = async function (k, v) { await w(k, v); this.lastWriteAt = Date.now(); UI.updateStatus(); }; const us = UI.updateStatus.bind(UI); UI.updateStatus = function () { us(); const sb = $('#statusbar'); if (!sb || !Store.lastWriteAt) return; const d = sb.querySelector('.disc'); const html = `<span class="sb">Last saved ${new Date(Store.lastWriteAt).toLocaleTimeString('en-IN')}</span>`; if (d) d.insertAdjacentHTML('beforebegin', html); }; })();
Actions.refresh = async () => {
  const rows = [], co = App.company, keys = [['core', 'Workspace and users', App.core], ['books_' + co.id, 'Books of ' + co.name, App.books[co.id]], ['log', 'Audit trail', App.log]];
  for (const [k, , v] of keys) { clearTimeout(Store.timers[k]); delete Store.timers[k]; if (v) await Store.write(k, v); }
  for (const [k, label, v] of keys) { if (!v) { rows.push({ label, ok: true, mem: '—', st: '—', note: 'No data yet' }); continue; } const back = await Store.load(k, null), a = JSON.stringify(v), b = back == null ? '' : JSON.stringify(back), cnt = x => k.startsWith('books') ? (x.vouchers || []).length + ' vouchers, ' + (x.parties || []).length + ' parties' : k === 'log' ? x.length + ' entries' : (x.users || []).length + ' users, ' + (x.companies || []).length + ' companies'; rows.push({ label, ok: a === b, mem: cnt(v), st: back ? cnt(back) : 'nothing found', note: a === b ? 'Identical' : 'Differs. Export a backup now.' }); }
  const ok = rows.every(r => r.ok); Router.render();
  UI.modal({ title: 'Refresh and verify', body: `<div class="note ${ok ? 'good' : 'bad'}" style="margin-bottom:12px"><b>${ok ? 'Everything you entered is saved.' : 'Some data in memory is not what storage holds.'}</b> Data was written, read back from ${esc(Store.label.toLowerCase())} at ${new Date().toLocaleTimeString('en-IN')} and compared with what is on screen. The page has been refreshed from it.</div><div class="table-wrap"><table class="t"><thead><tr><th></th><th>Data</th><th>On screen</th><th>In storage</th><th>Result</th></tr></thead><tbody>${rows.map(r => `<tr><td><span class="chip ${r.ok ? 'good' : 'bad'}">${r.ok ? 'OK' : 'Check'}</span></td><td>${esc(r.label)}</td><td>${esc(r.mem)}</td><td>${esc(r.st)}</td><td class="small muted">${esc(r.note)}</td></tr>`).join('')}</tbody></table></div>`, actions: [{ label: 'Close', kind: 'primary' }] });
  Log.add('Refresh and verify run', ok ? 'All data matches storage' : 'Mismatch detected');
};
(() => { const base = Router.render.bind(Router); Router.render = function () { base(); try { const v = $('#view'); if (!v || $('[data-act="refresh"]', v)) return; const ha = v.querySelector('.head-actions'), btn = `<button class="btn sm" data-act="refresh" title="Save, read back and verify that everything entered is registered">${icon('refresh')}Refresh</button>`; if (ha) ha.insertAdjacentHTML('afterbegin', btn); else { const ph = v.querySelector('.page-head'); if (ph) ph.insertAdjacentHTML('beforeend', `<div class="head-actions">${btn}</div>`); } } catch (e) { console.error(e); } }; })();
