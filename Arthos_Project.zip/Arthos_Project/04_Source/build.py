"""Rebuild Arthos.AI from source.  Usage:  python3 build.py
Reads phase0.html, the p*.js parts, skins.css and libs/ in this folder.
Writes ../01_App/arthos.html (loads libraries from a CDN) and ../01_App/arthos-offline.html (libraries inlined)."""
import os, re
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(HERE, '..', '01_App')
rd = lambda f: open(os.path.join(HERE, f), encoding='utf-8').read()
LIBS = {  # CDN path -> local file in libs/
 'chart.js@4.4.1/dist/chart.umd.js': 'chart.umd.js', 'xlsx@0.18.5/dist/xlsx.full.min.js': 'xlsx.full.min.js', 'jszip@3.10.1/dist/jszip.min.js': 'jszip.min.js',
 'marked@4.3.0/marked.min.js': 'marked.min.js', 'dompurify@3.0.6/dist/purify.min.js': 'purify.min.js', 'pdf-lib@1.17.1/dist/pdf-lib.min.js': 'pdf-lib.min.js',
 'jspdf@2.5.1/dist/jspdf.umd.min.js': 'jspdf.umd.min.js', 'jspdf-autotable@3.8.2/dist/jspdf.plugin.autotable.min.js': 'jspdf.plugin.autotable.min.js', 'qrcode-generator@1.4.4/qrcode.js': 'qrcode.js'}
PARTS = ['p1_core.js', 'p2_books.js', 'p3_ops.js', 'p4_tax.js', 'p5a_assure.js', 'p5b_ai_docs.js', 'p6_import.js', 'p7_hardening.js', 'p8_welcome.js', 'p9_forms.js', 'p10_smart.js', 'p11a_fsdata.js', 'p11b_fsbuild.js', 'p11c_fsrender.js', 'p12_indas.js', 'p13_share.js', 'p14_cfo.js', 'p15_desks.js', 'p16_chart_theme.js']
h = rd('phase0.html')
h = h.replace('</style>', rd('assets/fonts.css') + '\n' + rd('components.css') + '\n' + rd('assets/skins.css') + '\n</style>', 1)
h = re.sub(r'<link rel="preconnect"[^>]*>\s*', '', h); h = re.sub(r'<link href="https://fonts\.googleapis\.com[^>]*>\s*', '', h)
extra = ''.join('<script src="https://cdn.jsdelivr.net/npm/%s"></script>\n' % k for k in LIBS if k.split('@')[0] in ('pdf-lib', 'jspdf', 'jspdf-autotable', 'qrcode-generator'))
anchor = '<script src="https://cdn.jsdelivr.net/npm/dompurify@3.0.6/dist/purify.min.js"></script>\n'
assert anchor in h; h = h.replace(anchor, anchor + extra, 1)
marker = "/* ================= Boot ================= */"; assert marker in h
h = h.replace(marker, rd('assets/skins.js') + '\n' + rd('assets/pdffonts.js') + '\n' + ''.join(rd(p) + '\n' for p in PARTS) + '\n' + marker, 1)
old = "  if (!Array.isArray(App.log)) App.log = [];\n  applyTheme(App.core.settings.theme);"; assert old in h
h = h.replace(old, "  if (!Array.isArray(App.log)) App.log = [];\n  await Books.loadAll(); cfgOverrides();\n  applyTheme();")
os.makedirs(OUT, exist_ok=True)
open(os.path.join(OUT, 'arthos.html'), 'w', encoding='utf-8').write(h)
def inline(m):
    js = open(os.path.join(HERE, 'libs', LIBS[m.group(1)]), encoding='utf-8').read()
    js = re.sub(r'//# sourceMappingURL=.*', '', js).replace('</script>', '<\\/script>')
    return '<script>/* ' + m.group(1) + ' (inlined) */\n' + js + '\n</script>'
o = re.sub(r'<script src="https://cdn\.jsdelivr\.net/npm/([^"]+)"></script>', inline, h)
EXTRA = lambda f: open(os.path.join(HERE, 'libs', f), encoding='utf-8').read().replace('</script>', '<\\/script>')
extra_inline = '<script>/* exceljs 4.4.0 (inlined) */\n' + EXTRA('exceljs.min.js') + '\n</script>\n<script>/* pdf.js 3.11.174 (inlined) */\n' + EXTRA('pdf.min.js') + '\n</script>\n<script type="text/plain" id="pdf-worker-src">' + EXTRA('pdf.worker.min.js') + '</script>\n'
o = o.replace('<script>\n\'use strict\';', extra_inline + '<script>\n\'use strict\';', 1)
assert 'id="pdf-worker-src"' in o
open(os.path.join(OUT, 'arthos-offline.html'), 'w', encoding='utf-8').write(o)
print('built arthos.html (%d KB) and arthos-offline.html (%d KB)' % (len(h) // 1024, len(o) // 1024))
