/* ===================== VOUCHERS, CONTROLS, REPORTS ===================== */
const nz = x => parseFloat(x) || 0;
const partyState = p => (p && /^\d{2}/.test(p.gstin || '') ? p.gstin.slice(0, 2) : (CONFIG.states.find(s => s[1] === p?.state) || ['24'])[0]);
const grid = (cols, rows, o = {}) => rows.length ? `<div class="table-wrap" ${o.max ? `style="max-height:${o.max}px;overflow:auto"` : ''}><table class="t"><thead><tr>${cols.map(c => `<th class="${c.c || ''}">${esc(c.h)}</th>`).join('')}</tr></thead><tbody>${rows.slice(0, App.ui.gridLim || 150).map(r => `<tr class="${o.rowCls ? o.rowCls(r) : ''}">${cols.map(c => `<td class="${c.c || ''}">${c.v(r)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>${rows.length > (App.ui.gridLim || 150) ? pagerHTML(rows.length) : ''}` : `<div class="empty"><b>${o.empty || 'Nothing here yet'}</b>${o.emptyText || ''}</div>`;
const Exp = { reg: {} };
const expBtns = (id, title, head, body) => { Exp.reg[id] = { title, head, body }; return `<button class="btn sm" data-act="exp" data-arg="${id}|xlsx">${icon('download')}Excel</button><button class="btn sm" data-act="exp" data-arg="${id}|pdf">PDF</button><button class="btn sm" data-act="exp" data-arg="${id}|csv">CSV</button>`; };
const plain = x => String(x ?? '').replace(/\u20B9\u00A0?/g, 'Rs. ');
const PDF = {
  ok() { return !!(window.jspdf && window.jspdf.jsPDF); },
  doc(landscape) { if (!this.ok()) throw new Error('The PDF library did not load. Check your connection and reload.'); return new window.jspdf.jsPDF({ orientation: landscape ? 'landscape' : 'portrait', unit: 'pt', format: 'a4' }); },
  table(title, head, body, name) {
    const doc = this.doc(head.length > 6); doc.setFontSize(14); doc.text(plain(title), 40, 40); doc.setFontSize(9); doc.text(plain(App.company.name + ' | FY ' + fyLabel(fyNow()) + ' | Generated ' + fmtDate(new Date())), 40, 56);
    doc.autoTable({ head: [head.map(plain)], body: body.map(r => r.map(plain)), startY: 68, styles: { fontSize: 8 }, headStyles: { fillColor: [19, 33, 60] } });
    doc.setFontSize(8); doc.text('Assists professionals; does not replace professional judgment.', 40, doc.internal.pageSize.getHeight() - 20); Files.download(name, doc.output('blob'));
  }
};
Actions.exp = arg => {
  const [id, f] = arg.split('|'), d = Exp.reg[id]; if (!d) return; const nm = d.title.replace(/\W+/g, '_');
  try {
    if (f === 'pdf') PDF.table(d.title, d.head, d.body, nm + '.pdf');
    else { const rows = d.body.map(r => Object.fromEntries(d.head.map((h, i) => [h, r[i]]))); if (f === 'csv') Files.download(nm + '.csv', Files.csv(rows), 'text/csv'); else Files.download(nm + '.xlsx', Files.xlsx({ [d.title.slice(0, 28)]: rows })); }
    Log.add('Report exported', d.title + ' (' + f + ')');
  } catch (e) { UI.toast(e.message, 'error'); }
};
const accOpts = (sel, f) => { const g = by(Books.cur().accounts.filter(a => !f || f(a)), a => a.group); return '<option value="">Select ledger…</option>' + Object.entries(g).map(([n, a]) => `<optgroup label="${esc(n)}">${a.map(x => `<option value="${x.id}" ${x.id === sel ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</optgroup>`).join(''); };
const partyOpts = (kind, sel) => '<option value="">Select…</option>' + Books.cur().parties.filter(p => p.kind === kind).map(p => `<option value="${p.id}" ${p.id === sel ? 'selected' : ''}>${esc(p.id + ' · ' + p.name)}</option>`).join('');
const vchChip = s => ({ posted: '<span class="chip good">Posted</span>', pending: '<span class="chip warn">Pending</span>', rejected: '<span class="chip bad">Rejected</span>' }[s] || s);
const noBooks = (what) => `<div class="empty"><b>No books yet for ${esc(App.company.name)}</b>Load a full year of sample transactions (with planted errors) to try ${what || 'every module'}, or start entering vouchers.<div style="margin-top:14px"><button class="btn primary" data-act="seed-books">${icon('flask')}Load sample year of books</button></div></div>`;
const hasBooks = () => Books.cur().vouchers.length > 0;
Actions['seed-books'] = async () => { if (hasBooks() && !(await UI.confirm('Replace books?', 'This replaces all vouchers, parties and masters for this company with the sample year.', 'Replace', true))) return; Books.reseed(); Log.add('Sample books loaded', App.company.name); UI.toast('Sample year loaded: ' + Books.cur().vouchers.length + ' vouchers.', 'good'); renderNav(); Router.render(); };

/* ---------- Controls (maker-checker, DoA, period lock) ---------- */
const Ctl = {
  c() { return Books.cur().controls; },
  limit(role) { if (role.id === 'admin') return Infinity; const d = this.c().doa; return d[role.id] != null ? d[role.id] : ((role.perms.r2r || []).includes('approve') ? 100000 : 0); },
  canApprove(v, user) { user = user || App.user; const role = App.core.roles.find(r => r.id === user.roleId); return !!role && (role.perms[VTYPES[v.type].mod] || []).includes('approve') && user.name !== v.maker && Books.amt(v) <= this.limit(role); },
  whyNot(v) { const role = App.role; if (!(role.perms[VTYPES[v.type].mod] || []).includes('approve')) return 'Your role has no approve permission for this module.'; if (App.user.name === v.maker) return 'Maker and checker must be different people.'; if (Books.amt(v) > this.limit(role)) return 'Amount exceeds your approval limit of ' + fmtINR(this.limit(role)) + '.'; return ''; },
  mcActive(maker) { return this.c().mcEnabled && App.core.users.some(u => u.active && u.id !== maker.id && (App.core.roles.find(r => r.id === u.roleId)?.perms.r2r || []).includes('approve')); },
  assess(v) {
    const c = this.c(), blocks = [], flags = [], amt = Books.amt(v), today = isoToday();
    if (c.lockDate && v.date <= c.lockDate) blocks.push('The period up to ' + fmtDate(c.lockDate) + ' is locked. Ask the Admin to unlock it, or post in an open period.');
    if (amt <= 0) blocks.push('Enter an amount.'); if (Math.abs(sum(v.lines, l => l.dr) - sum(v.lines, l => l.cr)) > 0.01) blocks.push('Debits and credits do not match.');
    if (v.date > iso(addD(today0(), 31))) blocks.push('Date is more than a month in the future.');
    const age = daysBetween(v.date, today); if (age > c.backdateDays) flags.push('Back-dated by ' + age + ' days');
    const dw = dparse(v.date).getDay(); if ((dw === 0 || dw === 6) && v.type !== 'Sales') flags.push('Weekend date'); const h = new Date().getHours(); if (h >= 21 || h < 6) flags.push('Entered after hours');
    if (v.ai) flags.push('AI-drafted'); const needs = this.mcActive(App.user) && (amt >= c.mcMin || (v.ai && c.aiReview));
    return { blocks, flags, needs, amt };
  }
};

/* ---------- Smart GST/TDS alerts (USP 11) ---------- */
const TaxAlerts = {
  tdsFor(p) { return CONFIG.tds.find(t => t.sec === (p?.tds)); },
  rate(sec, pan) { const t = CONFIG.tds.find(x => x.sec === sec); if (!t) return 0; if (!GST.validPAN(pan)) return 20; return t.rates[pan[3]] ?? t.rates.def; },
  prior(partyId, fy) { const { from, to } = fyRange(fy); return sum(Books.posted().filter(v => v.type === 'Purchase' && v.meta?.party === partyId && v.date >= from && v.date <= to), v => v.meta.taxable || 0); },
  check(d) {
    const A = [], add = (sev, code, msg) => A.push({ sev, code, msg }), p = d.party, co = App.company, g = CONFIG.gst;
    if (d.type === 'Purchase' || d.type === 'Debit Note') {
      if (p) {
        if (!p.active) add('bad', 'VENDOR', p.name + ' is blocked. Do not book or pay without approval to unblock.');
        const gv = p.gstin ? GST.validate(p.gstin) : null;
        if (!p.gstin) add('warn', 'RCM', 'Vendor has no GSTIN. Check whether reverse charge applies (notified services such as GTA, legal, security); otherwise no ITC is available.');
        else if (!gv.ok) add('bad', 'GSTIN', 'Vendor GSTIN is invalid (' + gv.reason + ') so ITC is at risk of denial.');
        if (d.taxable > 0 && (d.cgst + d.sgst > 0) && partyState(p) !== co.state) add('bad', 'POS', 'Vendor is in ' + stateName(partyState(p)) + ' but CGST/SGST was applied. Inter-state supplies carry IGST.');
        if (d.taxable > 0 && d.igst > 0 && partyState(p) === co.state) add('warn', 'POS', 'Vendor is in your state but IGST was applied. Check place of supply.');
        const sec = d.tdsSec || p.tds; const t = CONFIG.tds.find(x => x.sec === sec);
        if (t && sec !== 'None') {
          const cum = this.prior(p.id, fyOfDate(d.date)) + d.taxable, due = (t.single > 0 && d.taxable >= t.single) || cum >= t.annual, exp = r2(d.taxable * this.rate(sec, p.pan) / 100);
          if (due && sec !== '194Q' && d.tds <= 0) add('bad', 'TDS', 'TDS under section ' + sec + ' applies (' + t.name + '). Cumulative ' + fmtINR(cum) + ' crosses the threshold. Deduct about ' + fmtINR(exp) + ' at ' + this.rate(sec, p.pan) + '%.');
          else if (due && d.tds > 0 && Math.abs(d.tds - exp) > 2) add('warn', 'TDS', 'TDS deducted ' + fmtINR(d.tds) + ' differs from expected ' + fmtINR(exp) + ' at ' + this.rate(sec, p.pan) + '%.');
          if (!GST.validPAN(p.pan)) add('warn', '206AA', 'PAN is missing or invalid, so TDS is at 20% under section 206AA.');
        }
        if (p.msme === 'Micro' || p.msme === 'Small') add('info', 'MSME', p.msme + ' enterprise: pay within 45 days of acceptance (section 15 MSMED Act) or lose the deduction under section 43B(h) if unpaid at year end.');
      }
      if (d.gst > 0 && d.itc && d.expAccs.some(a => CONFIG.blockedAcc.includes(a))) add('bad', '17(5)', 'ITC on food, beverages and entertainment is blocked under section 17(5). Untick "ITC eligible" so GST is expensed.');
      d.items.forEach(it => { const h = CONFIG.hsn.find(x => x[0] === String(it.hsn).slice(0, 4)); if (h && h[2] !== nz(it.gst)) add('warn', 'RATE', 'HSN/SAC ' + h[0] + ' (' + h[1] + ') is normally ' + h[2] + '% but you entered ' + nz(it.gst) + '%.'); });
    }
    if (d.type === 'Sales' || d.type === 'Credit Note') {
      if (p) {
        const gv = p.gstin ? GST.validate(p.gstin) : null; if (p.gstin && !gv.ok) add('warn', 'GSTIN', 'Customer GSTIN is invalid (' + gv.reason + '). The e-invoice will be rejected.');
        if (p.gstin && gv.ok && gv.state !== p.state) add('warn', 'POS', 'Customer master says ' + p.state + ' but GSTIN is from ' + gv.state + '. Place of supply follows the GSTIN.');
        if (d.type === 'Sales') { const open = AR.ageing('C').rows.find(r => r.p.id === p.id)?.open || 0, lim = p.limit || 0; if (lim === 0) add('bad', 'LIMIT', 'Credit limit for this customer is zero. This sale needs an approved limit.'); else if (open + d.total > lim) add('bad', 'LIMIT', 'Outstanding ' + fmtINR(open) + ' plus this invoice exceeds the credit limit of ' + fmtINR(lim) + '.'); else if (open + d.total > lim * .85) add('warn', 'LIMIT', 'This invoice takes the customer past 85% of the credit limit.'); }
      }
      d.items.forEach(it => { const h = CONFIG.hsn.find(x => x[0] === String(it.hsn).slice(0, 4)); if (h && h[2] !== nz(it.gst)) add('warn', 'RATE', 'HSN ' + h[0] + ' is normally ' + h[2] + '% but you entered ' + nz(it.gst) + '%.'); });
    }
    if (d.type === 'Payment') {
      if (d.cash && d.amount > CONFIG.cashLimit) add('bad', '40A(3)', 'Cash payment above ' + fmtINR(CONFIG.cashLimit) + ' to one person in a day is disallowed under section 40A(3).');
      if (p) {
        if (!p.active) add('bad', 'VENDOR', p.name + ' is blocked.');
        const sec = d.tdsSec || '';
        if (p.kind === 'V' && p.tds && p.tds !== 'None' && !sec && d.tds <= 0 && d.amount >= 50000) add('warn', 'TDS', 'This vendor is under section ' + p.tds + '. Confirm TDS was deducted when the bill was booked.');
        const o = AR.ageing('V').rows.find(r => r.p.id === p.id); if (o && (p.msme === 'Micro' || p.msme === 'Small')) { const old = Math.max(0, ...o.bills.map(b => daysBetween(b.date, d.date))); if (old > 45) add('warn', 'MSME', 'Oldest bill from this ' + p.msme.toLowerCase() + ' enterprise is ' + old + ' days old. Interest at three times the bank rate applies beyond 45 days.'); }
        if (o && d.amount > o.open + 1) add('info', 'ADV', 'Payment exceeds the outstanding payable of ' + fmtINR(o.open) + '. The excess is an advance.');
      }
      if (d.counter === 'rent') { const cum = sum(Books.posted().filter(v => v.lines.some(l => l.acc === 'rent' && l.dr > 0) && fyOfDate(v.date) === fyOfDate(d.date)), v => sum(v.lines.filter(l => l.acc === 'rent'), l => l.dr)) + d.amount; if (cum >= 600000 && d.tds <= 0) add('bad', '194I', 'Rent paid this year reaches ' + fmtINR(cum) + ', above the ₹6,00,000 threshold. TDS under 194I applies (10%).'); }
    }
    if (d.type === 'Journal') { if (d.accs.includes('susp')) add('warn', 'SUSP', 'Posting to Suspense. Clear it before month end.'); if (d.accs.some(a => Books.acc(a)?.nat === 'I')) add('warn', 'REV', 'Manual journal to a revenue ledger. Attach supporting documents.'); if (d.amount >= 100000 && d.amount % 10000 === 0) add('info', 'ROUND', 'Round-sum journal. Auditors test these closely.'); }
    return A;
  },
  scan() {
    const out = [], co = App.company; const b = Books.cur();
    const ven = {}; b.parties.filter(p => p.kind === 'V').forEach(p => ven[p.id] = { p, taxable: 0, tds: 0, bills: [] });
    Books.posted().filter(v => v.type === 'Purchase' && ven[v.meta?.party]).forEach(v => { const o = ven[v.meta.party]; if (fyOfDate(v.date) === fyNow()) { o.taxable += v.meta.taxable || 0; o.tds += v.meta.tds || 0; o.bills.push(v); } });
    Object.values(ven).forEach(o => { const t = CONFIG.tds.find(x => x.sec === o.p.tds); if (!t || o.p.tds === 'None' || o.p.tds === '194Q' || !o.bills.length) return; const due = o.bills.some(v => t.single > 0 && v.meta.taxable >= t.single) || o.taxable >= t.annual; if (!due) return; const exp = r2(o.taxable * this.rate(o.p.tds, o.p.pan) / 100), sh = r2(exp - o.tds); if (sh > 100) { const first = o.bills[0].date, months = Math.max(1, Math.ceil(daysBetween(first, isoToday()) / 30)); out.push({ area: 'TDS', sev: 'bad', title: 'TDS short-deducted: ' + o.p.name, detail: `Section ${o.p.tds}: payments ${fmtINR(o.taxable)}, expected TDS ${fmtINR(exp)}, deducted ${fmtINR(o.tds)}. Shortfall ${fmtINR(sh)}; interest u/s 201(1A) at 1% per month is about ${fmtINR(sh * .01 * months)}.`, party: o.p.id }); } });
    const rent = sum(Books.posted().filter(v => v.lines.some(l => l.acc === 'rent' && l.dr > 0) && fyOfDate(v.date) === fyNow()), v => sum(v.lines.filter(l => l.acc === 'rent'), l => l.dr)); const rentTds = sum(Books.posted().filter(v => v.meta?.payee), v => v.meta.tds || 0);
    if (rent >= 600000 && rentTds === 0) out.push({ area: 'TDS', sev: 'bad', title: 'No TDS on rent', detail: `Rent paid ${fmtINR(rent)} this year; TDS u/s 194I at 10% would be ${fmtINR(rent * .1)}. None has been deducted.` });
    AR.ageing('V').rows.filter(r => r.p.msme === 'Micro' || r.p.msme === 'Small').forEach(r => { const od = r.bills.filter(x => daysBetween(x.date, isoToday()) > 45); if (od.length) out.push({ area: 'MSME', sev: 'warn', title: '43B(h): ' + r.p.name + ' (' + r.p.msme + ')', detail: `${od.length} bill(s) totalling ${fmtINR(sum(od, x => x.open))} unpaid beyond 45 days. If still unpaid on 31 March the amount is disallowed for the year, and interest accrues under the MSMED Act.`, party: r.p.id }); });
    const itc = this.itcReversals(); if (itc.rows.length) out.push({ area: 'GST', sev: 'warn', title: 'ITC reversal due on unpaid bills (Rule 37)', detail: `${itc.rows.length} bill(s) unpaid beyond ${CONFIG.gst.itcReverseDays} days. ITC to reverse ${fmtINR(itc.itc)} plus interest at ${CONFIG.gst.interestPct}%.` });
    Books.posted().filter(v => v.type === 'Payment' && v.lines.some(l => l.acc === 'cash' && l.cr > 0) && Books.amt(v) > CONFIG.cashLimit).forEach(v => out.push({ area: 'Income tax', sev: 'bad', title: 'Cash payment above limit: ' + v.no, detail: `${fmtINR(Books.amt(v))} paid in cash on ${fmtDate(v.date)}. Disallowed under section 40A(3).`, vid: v.id }));
    const near = Books.posted().filter(v => v.type === 'Payment' && v.lines.some(l => l.acc === 'cash' && l.cr > 0) && Books.amt(v) > CONFIG.cashLimit * .9 && Books.amt(v) <= CONFIG.cashLimit); if (near.length >= 3) out.push({ area: 'Income tax', sev: 'warn', title: near.length + ' cash payments just below ₹10,000', detail: 'A cluster just under the 40A(3) limit suggests splitting. Review supporting bills and payees.' });
    b.parties.filter(p => p.kind === 'V' && p.gstin && !GST.validate(p.gstin).ok).forEach(p => { const n = Books.posted().filter(v => v.type === 'Purchase' && v.meta?.party === p.id).length; if (n) out.push({ area: 'GST', sev: 'bad', title: 'ITC at risk: invalid GSTIN for ' + p.name, detail: `${n} bill(s) booked with ITC from a vendor whose GSTIN fails the checksum.`, party: p.id }); });
    return out;
  },
  itcReversals() {
    const rows = []; let itc = 0; AR.ageing('V').rows.forEach(r => r.bills.forEach(bl => { const age = daysBetween(bl.date, isoToday()); if (age > CONFIG.gst.itcReverseDays && bl.v.meta?.itc !== false) { const frac = bl.open / bl.amt, gst = ((bl.v.meta.cgst || 0) + (bl.v.meta.sgst || 0) + (bl.v.meta.igst || 0)) * frac; rows.push({ v: bl.v, p: r.p, age, open: bl.open, gst }); itc += gst; } })); return { rows, itc };
  }
};

/* ---------- Duplicate detection (USP 7) ---------- */
const Dup = {
  scan() {
    const out = [], vs = Books.cur().vouchers.filter(v => v.status !== 'rejected');
    const bills = vs.filter(v => v.type === 'Purchase' && v.meta?.party), pay = vs.filter(v => v.type === 'Payment' && v.meta?.party);
    const grp = (arr, kind) => Object.values(by(arr, v => v.meta.party)).forEach(g => { for (let i = 0; i < g.length; i++) for (let j = i + 1; j < g.length; j++) { const a = g[i], b = g[j]; let sc = 0, why = ''; const ta = Books.amt(a), tb = Books.amt(b), dd = Math.abs(daysBetween(a.date, b.date)); if (kind === 'Bill') { if (normInv(a.meta.billNo) && normInv(a.meta.billNo) === normInv(b.meta.billNo)) { sc = 95; why = 'Same vendor and same invoice number once punctuation is ignored ("' + a.meta.billNo + '" and "' + b.meta.billNo + '")' + (Math.abs(ta - tb) < 1 ? ', same amount.' : '.'); } else if (Math.abs(ta - tb) < 1 && dd <= 15) { sc = 70; why = 'Same vendor, same amount, ' + dd + ' days apart.'; } } else if (Math.abs(ta - tb) < 1 && dd <= 7) { sc = 88; why = 'Same payee, same amount, ' + dd + ' day(s) apart.'; } if (sc) out.push({ kind, sc, a, b, why, amt: ta }); } });
    grp(bills, 'Bill'); grp(pay, 'Payment'); return out.sort((x, y) => y.sc - x.sc);
  },
  check(d) {
    if (d.type !== 'Purchase' && d.type !== 'Payment') return []; const out = [];
    Books.cur().vouchers.filter(v => v.type === d.type && v.status !== 'rejected' && v.meta?.party === d.party && d.party).forEach(v => { const dd = Math.abs(daysBetween(v.date, d.date)), amt = Books.amt(v); let sc = 0, why = ''; if (d.type === 'Purchase' && d.billNo && normInv(v.meta.billNo) === normInv(d.billNo)) { sc = 95; why = 'Invoice ' + v.meta.billNo + ' from this vendor already exists as ' + v.no + '.'; } else if (Math.abs(amt - d.total) < 1 && dd <= (d.type === 'Payment' ? 7 : 15)) { sc = d.type === 'Payment' ? 88 : 70; why = 'Same vendor and amount as ' + v.no + ' (' + dd + ' days apart).'; } if (sc) out.push({ sc, why, v }); }); return out;
  }
};

/* ---------- Voucher form ---------- */
const VForm = {
  s: null, closeFn: null,
  open(type, pre = {}) {
    if (!App.can(VTYPES[type].mod, 'create')) { UI.toast('Your role cannot create ' + type + ' vouchers.', 'error'); return; }
    this.s = Object.assign({ type, date: isoToday(), narr: '', ref: '', party: '', acc: '', bankAcc: 'bank', amount: '', tdsSec: '', tds: '', tdsAuto: true, items: [{ desc: '', hsn: '', qty: 1, rate: '', gst: 18, ledger: 'purch' }], lines: [{ acc: '', dr: '', cr: '' }, { acc: '', dr: '', cr: '' }], billNo: '', itc: true, ai: false, override: false }, pre); this.show();
  },
  show() {
    if (this.closeFn) this.closeFn(); const s = this.s;
    this.closeFn = UI.modal({ title: 'New ' + s.type + ' voucher', wide: true, body: this.body(), actions: [{ label: 'Cancel' }, { label: 'Save', kind: 'primary', stay: true, onClick: async (el, close) => { if (await this.save()) close(); return false; } }], onOpen: el => { this.bind(el); this.refresh(); } });
  },
  body() {
    const s = this.s, T = s.type, isP = T === 'Purchase' || T === 'Debit Note', isS = T === 'Sales' || T === 'Credit Note';
    const head = `<div class="form-grid" style="margin-bottom:14px"><div class="field"><label for="vf-type">Voucher type</label><select id="vf-type" data-f="type">${Object.keys(VTYPES).filter(t => App.can(VTYPES[t].mod, 'create')).map(t => `<option ${t === T ? 'selected' : ''}>${t}</option>`).join('')}</select></div><div class="field"><label for="vf-date">Date</label><input id="vf-date" type="date" data-f="date" value="${s.date}"></div></div>`;
    let mid = '';
    if (T === 'Journal') mid = `<table class="vf-lines"><thead><tr><th>Ledger</th><th style="width:140px">Debit</th><th style="width:140px">Credit</th><th></th></tr></thead><tbody>${s.lines.map((l, i) => `<tr><td><select data-l="${i}:acc">${accOpts(l.acc)}</select></td><td><input type="number" step="0.01" min="0" data-l="${i}:dr" value="${esc(l.dr)}"></td><td><input type="number" step="0.01" min="0" data-l="${i}:cr" value="${esc(l.cr)}"></td><td><button class="icon-btn" data-vf="del" data-i="${i}" aria-label="Remove line">${icon('x')}</button></td></tr>`).join('')}</tbody></table><button class="btn sm" data-vf="add" style="margin-top:6px">${icon('plus')}Add line</button>`;
    else if (T === 'Payment' || T === 'Receipt' || T === 'Contra') {
      const pay = T === 'Payment', rec = T === 'Receipt';
      mid = `<div class="form-grid"><div class="field"><label>${pay ? 'Paid from' : rec ? 'Received in' : 'From'}</label><select data-f="bankAcc"><option value="bank" ${s.bankAcc === 'bank' ? 'selected' : ''}>Bank (HDFC)</option><option value="cash" ${s.bankAcc === 'cash' ? 'selected' : ''}>Cash in hand</option></select></div>
      <div class="field"><label>${pay ? 'Paid to' : rec ? 'Received from' : 'To'}</label><select data-f="acc">${accOpts(s.acc, a => T === 'Contra' ? (a.id === 'cash' || a.id === 'bank') : (pay ? a.nat !== 'I' : a.nat !== 'E') && a.id !== s.bankAcc)}</select></div>
      <div class="field"><label>Amount (₹)</label><input type="number" step="0.01" min="0" data-f="amount" value="${esc(s.amount)}"></div><div class="field"><label>Reference (cheque / UTR)</label><input type="text" data-f="ref" value="${esc(s.ref)}"></div>
      ${pay ? `<div class="field"><label>TDS section (if deducting)</label><select data-f="tdsSec"><option value="">None</option>${CONFIG.tds.map(t => `<option value="${t.sec}" ${s.tdsSec === t.sec ? 'selected' : ''}>${t.sec} · ${esc(t.name)}</option>`).join('')}</select></div><div class="field"><label>TDS amount (₹)</label><input type="number" step="0.01" data-f="tds" value="${esc(s.tds)}"><span class="hint">Auto-filled from the section; edit if needed.</span></div>` : ''}</div>`;
    } else if (isS || isP) {
      const items = s.items.map((it, i) => `<tr><td><input type="text" data-i="${i}:desc" value="${esc(it.desc)}" placeholder="Description"></td><td style="width:90px"><input type="text" data-i="${i}:hsn" value="${esc(it.hsn)}" placeholder="HSN/SAC"></td><td style="width:80px"><input type="number" step="0.01" data-i="${i}:qty" value="${esc(it.qty)}"></td><td style="width:110px"><input type="number" step="0.01" data-i="${i}:rate" value="${esc(it.rate)}"></td><td style="width:84px"><select data-i="${i}:gst">${CONFIG.gst.rates.map(r => `<option ${nz(it.gst) === r ? 'selected' : ''}>${r}</option>`).join('')}</select></td>${isP ? `<td style="width:170px"><select data-i="${i}:ledger">${accOpts(it.ledger, a => a.nat === 'E' || a.sch === 'nca_ppe' || a.id === 'prepaid')}</select></td>` : ''}<td><button class="icon-btn" data-vf="delitem" data-i="${i}" aria-label="Remove item">${icon('x')}</button></td></tr>`).join('');
      mid = `<div class="form-grid" style="margin-bottom:12px"><div class="field"><label>${isS ? 'Customer' : 'Vendor'}</label><select data-f="party">${partyOpts(isS ? 'C' : 'V', s.party)}</select></div>${isP ? `<div class="field"><label>Vendor bill number</label><input type="text" data-f="billNo" value="${esc(s.billNo)}"></div>` : `<div class="field"><label>Reference / PO number</label><input type="text" data-f="ref" value="${esc(s.ref)}"></div>`}</div>
      <table class="vf-lines"><thead><tr><th>Item</th><th>HSN/SAC</th><th>Qty</th><th>Rate (₹)</th><th>GST %</th>${isP ? '<th>Ledger</th>' : ''}<th></th></tr></thead><tbody>${items}</tbody></table><button class="btn sm" data-vf="additem" style="margin:6px 0 12px">${icon('plus')}Add item</button>
      ${isP ? `<div class="form-grid"><div class="field"><label>TDS section</label><select data-f="tdsSec"><option value="">None</option>${CONFIG.tds.map(t => `<option value="${t.sec}" ${s.tdsSec === t.sec ? 'selected' : ''}>${t.sec} · ${esc(t.name)}</option>`).join('')}</select></div><div class="field"><label>TDS amount (₹)</label><input type="number" step="0.01" data-f="tds" value="${esc(s.tds)}"></div><label class="row small full" style="gap:6px"><input type="checkbox" data-f="itc" ${s.itc ? 'checked' : ''}> Input tax credit eligible</label></div>` : ''}`;
    }
    return head + mid + `<div class="field" style="margin-top:12px"><label>Narration</label><input type="text" data-f="narr" value="${esc(s.narr)}" placeholder="What is this entry for?"></div><div id="vf-sum" aria-live="polite"></div>`;
  },
  bind(el) {
    const s = this.s, re = ['type', 'party', 'bankAcc', 'tdsSec', 'acc'];
    el.addEventListener('input', e => this.onIn(e, false)); el.addEventListener('change', e => this.onIn(e, true));
    el.addEventListener('click', e => { const b = e.target.closest('[data-vf]'); if (!b) return; const a = b.dataset.vf, i = +b.dataset.i; if (a === 'add') s.lines.push({ acc: '', dr: '', cr: '' }); if (a === 'del' && s.lines.length > 2) s.lines.splice(i, 1); if (a === 'additem') s.items.push({ desc: '', hsn: '', qty: 1, rate: '', gst: 18, ledger: s.items[0]?.ledger || 'purch' }); if (a === 'delitem' && s.items.length > 1) s.items.splice(i, 1); this.show(); });
  },
  onIn(e, isChange) {
    const s = this.s, t = e.target, f = t.dataset.f, l = t.dataset.l, it = t.dataset.i; if (!f && !l && !it) return;
    if (f) { s[f] = t.type === 'checkbox' ? t.checked : t.value; if (f === 'tds') s.tdsAuto = false; if (f === 'type' && isChange) { const keep = { date: s.date, narr: s.narr }; this.open(t.value, keep); return; } if (f === 'party' && isChange) { const p = Books.party(s.party); if (p && p.tds && p.tds !== 'None' && (s.type === 'Purchase' || s.type === 'Debit Note')) { s.tdsSec = p.tds; s.tdsAuto = true; } if (p && s.type === 'Purchase') { const sec = CONFIG.tds.find(x => x.sec === p.tds); s.items.forEach(x => { if (sec) x.ledger = sec.acc; }); } this.show(); return; } if ((f === 'tdsSec') && isChange) { s.tdsAuto = true; this.show(); return; } }
    if (l) { const [i, k] = l.split(':'); s.lines[+i][k] = t.value; } if (it) { const [i, k] = it.split(':'); s.items[+i][k] = t.value; if (k === 'hsn') { const h = CONFIG.hsn.find(x => x[0] === t.value.slice(0, 4)); if (h && isChange) { s.items[+i].gst = h[2]; this.show(); return; } } }
    this.refresh();
  },
  compute() {
    const s = this.s, T = s.type, co = App.company, isP = T === 'Purchase' || T === 'Debit Note', isS = T === 'Sales' || T === 'Credit Note', r = { lines: [], meta: {}, d: { type: T, date: s.date, party: null, taxable: 0, cgst: 0, sgst: 0, igst: 0, gst: 0, total: 0, tds: 0, tdsSec: s.tdsSec, itc: s.itc, expAccs: [], amount: 0, items: [], billNo: s.billNo, accs: [], counter: s.acc, cash: s.bankAcc === 'cash' } };
    const L = (a, dr, cr) => { dr = r2(dr); cr = r2(cr); if ((dr || cr) && a) r.lines.push({ acc: a, dr, cr }); };
    if (T === 'Journal') { s.lines.forEach(l => { if (l.acc) { L(l.acc, nz(l.dr), nz(l.cr)); r.d.accs.push(l.acc); } }); r.d.amount = sum(r.lines, l => l.dr); if (r.lines.length < 2) r.err = 'Add at least two lines.'; return r; }
    if (T === 'Payment' || T === 'Receipt' || T === 'Contra') {
      const a = nz(s.amount); r.d.amount = a; if (!s.acc) { r.err = 'Choose the ledger.'; return r; } if (s.acc === s.bankAcc) { r.err = 'From and to cannot be the same.'; return r; }
      r.d.party = Books.party(s.acc);
      if (T === 'Payment') { let tds = 0; if (s.tdsSec) { const p = r.d.party; tds = s.tdsAuto || s.tds === '' ? r2(a * TaxAlerts.rate(s.tdsSec, p?.pan || 'AAAPA0000A') / 100) : nz(s.tds); s.tds = s.tdsAuto || s.tds === '' ? String(tds) : s.tds; } r.d.tds = tds; L(s.acc, a, 0); L(s.bankAcc, 0, a - tds); L('tds_p', 0, tds); r.meta = { party: r.d.party ? s.acc : undefined, tds, tdsSec: s.tdsSec || '' }; }
      else if (T === 'Receipt') { L(s.bankAcc, a, 0); L(s.acc, 0, a); r.meta = { party: r.d.party ? s.acc : undefined }; } else { L(s.acc, a, 0); L(s.bankAcc, 0, a); }
      return r;
    }
    const p = Books.party(s.party); r.d.party = p; if (!p) { r.err = 'Choose the ' + (isS ? 'customer' : 'vendor') + '.'; return r; }
    const intra = partyState(p) === co.state, rows = s.items.filter(i => nz(i.qty) * nz(i.rate) > 0); if (!rows.length) { r.err = 'Add at least one item with quantity and rate.'; return r; }
    const sign = T === 'Credit Note' || T === 'Debit Note' ? -1 : 1; let tax = 0, taxable = 0; const exp = {};
    rows.forEach(i => { const am = r2(nz(i.qty) * nz(i.rate)), g = r2(am * nz(i.gst) / 100); taxable += am; tax += g; r.d.items.push({ desc: i.desc, hsn: i.hsn, qty: nz(i.qty), rate: nz(i.rate), gst: nz(i.gst), amount: am, ledger: i.ledger }); const led = i.ledger || 'purch'; r.d.expAccs.push(led); if (isP) { exp[led] = (exp[led] || 0) + am + (s.itc ? 0 : g); } });
    taxable = r2(taxable); tax = r2(tax); const c = intra ? r2(tax / 2) : 0, sg = intra ? r2(tax - c) : 0, ig = intra ? 0 : tax; Object.assign(r.d, { taxable, cgst: c, sgst: sg, igst: ig, gst: tax, total: r2(taxable + tax) }); r.d.amount = r.d.total;
    if (isS) { const o = sign > 0 ? [[p.id, r.d.total, 0], ['sales', 0, taxable], ['go_c', 0, c], ['go_s', 0, sg], ['go_i', 0, ig]] : [[p.id, 0, r.d.total], ['sales', taxable, 0], ['go_c', c, 0], ['go_s', sg, 0], ['go_i', ig, 0]]; o.forEach(x => L(...x)); r.meta = { party: p.id, taxable, cgst: c, sgst: sg, igst: ig, rate: nz(rows[0].gst), total: r.d.total, pos: partyState(p), due: iso(addD(dparse(s.date), p.terms || 30)), items: r.d.items, ref: s.ref }; }
    else { let tds = 0; if (s.tdsSec) tds = s.tdsAuto || s.tds === '' ? r2(taxable * TaxAlerts.rate(s.tdsSec, p.pan) / 100) : nz(s.tds); if (s.tdsSec && (s.tdsAuto || s.tds === '')) s.tds = String(tds); r.d.tds = tds; const net = r2(r.d.total - tds);
      Object.entries(exp).forEach(([a, v]) => sign > 0 ? L(a, v, 0) : L(a, 0, v)); if (s.itc) { if (sign > 0) { L('gi_c', c, 0); L('gi_s', sg, 0); L('gi_i', ig, 0); } else { L('gi_c', 0, c); L('gi_s', 0, sg); L('gi_i', 0, ig); } }
      if (sign > 0) { L(p.id, 0, net); L('tds_p', 0, tds); } else { L(p.id, net, 0); L('tds_p', tds, 0); }
      r.meta = { party: p.id, billNo: s.billNo, taxable, cgst: c, sgst: sg, igst: ig, tds, tdsSec: tds ? s.tdsSec : '', itc: s.itc, rate: nz(rows[0].gst), total: r.d.total, pos: partyState(p), items: r.d.items }; }
    return r;
  },
  refresh() {
    const box = $('#vf-sum'); if (!box) return; const r = this.compute(), s = this.s;
    const v = { type: s.type, date: s.date, lines: r.lines, ai: s.ai }, as = Ctl.assess(v), alerts = r.err ? [] : TaxAlerts.check(r.d), dups = r.err ? [] : Dup.check({ ...r.d, party: s.party || s.acc, total: r.d.total || r.d.amount, billNo: s.billNo });
    s._dup = dups; const strong = dups.some(d => d.sc >= 90);
    const tot = r.lines.length ? `<table class="vf-lines" style="margin-top:12px"><thead><tr><th>Posting preview</th><th class="amt" style="text-align:right">Debit</th><th style="text-align:right">Credit</th></tr></thead><tbody>${r.lines.map(l => `<tr><td>${esc(Books.accName(l.acc))}</td><td style="text-align:right">${amtCell(l.dr)}</td><td style="text-align:right">${amtCell(l.cr)}</td></tr>`).join('')}<tr><td><b>Total</b></td><td style="text-align:right"><b>${fmt2(sum(r.lines, l => l.dr))}</b></td><td style="text-align:right"><b>${fmt2(sum(r.lines, l => l.cr))}</b></td></tr></tbody></table>` : '';
    const msgs = [...(r.err ? [`<div class="a warn">${esc(r.err)}</div>`] : []), ...(r.err ? [] : as.blocks).map(b => `<div class="a bad"><b>Blocked:</b> ${esc(b)}</div>`), ...alerts.map(a => `<div class="a ${a.sev}"><b>${esc(a.code)}:</b> ${esc(a.msg)}</div>`), ...dups.map(d => `<div class="a ${d.sc >= 90 ? 'bad' : 'warn'}"><b>Possible duplicate (${d.sc}%):</b> ${esc(d.why)}</div>`), ...as.flags.map(f => `<div class="a">${esc(f)}</div>`)];
    box.innerHTML = tot + (msgs.length ? `<div class="alertbox">${msgs.join('')}</div>` : '') + (strong ? `<label class="row small" style="gap:6px;margin-top:8px"><input type="checkbox" data-f="override" ${s.override ? 'checked' : ''}> I have checked and this is not a duplicate</label>` : '') + `<div class="note ${as.needs ? 'warn' : ''}" style="margin-top:10px">${as.needs ? `This voucher goes to the approval inbox (${s.ai ? 'AI-drafted entries are always reviewed' : 'amount is at or above ' + fmtINR(Ctl.c().mcMin)}). It will not touch the books until a second person approves.` : 'This will post straight to the books' + (Ctl.c().mcEnabled && !Ctl.mcActive(App.user) ? ' (no second approver is available)' : '') + '.'}</div>`;
    const ti = $('[data-f="tds"]'); if (ti && s.tdsAuto && document.activeElement !== ti) ti.value = s.tds;
    const btn = $('.modal footer [data-mi="1"]'); if (btn) btn.textContent = as.needs ? 'Submit for approval' : 'Post voucher';
  },
  async save() {
    const s = this.s, r = this.compute(); if (r.err) { UI.toast(r.err, 'error'); return false; }
    const v = { id: uid('v'), no: '', type: s.type, date: s.date, narr: s.narr || (s.type + ' voucher'), lines: r.lines, status: 'posted', maker: App.user.name, makerId: App.user.id, checker: null, ai: !!s.ai, createdAt: new Date().toISOString(), meta: r.meta, ref: s.ref || '' }, as = Ctl.assess(v);
    if (as.blocks.length) { UI.toast(as.blocks[0], 'error'); return false; }
    if ((s._dup || []).some(d => d.sc >= 90) && !s.override) { UI.toast('A near-certain duplicate exists. Tick the confirmation box if you are sure.', 'error'); return false; }
    if (s.aiMeta) v.meta.aiNote = s.aiMeta; v.flags = as.flags; v.status = as.needs ? 'pending' : 'posted'; const b = Books.cur(); v.no = Books.nextNo(b, v.type, fyOfDate(v.date)); if (v.type === 'Sales') v.meta.invNo = v.no; if (v.status === 'posted') v.autoPosted = true;
    b.vouchers.push(v); Books.save(); await Log.add(v.status === 'pending' ? 'Voucher submitted for approval' : 'Voucher posted', `${v.no} ${fmtINR(as.amt)} ${v.narr}`.slice(0, 200), { ai: v.ai }); UI.toast(v.status === 'pending' ? v.no + ' sent for approval.' : v.no + ' posted.', 'good'); renderNav(); Router.render(); return true;
  }
};
document.addEventListener('keydown', e => { if (!App.session.userId || App.route !== 'vouchers' || $('#modal-root').innerHTML) return; const k = Object.entries(VTYPES).find(([, x]) => x.key === e.key); if (k) { e.preventDefault(); VForm.open(k[0]); } });
Actions['v-new'] = t => VForm.open(t);

/* ---------- Approvals ---------- */
const Approve = {
  async approve(id) { const v = Books.vch(id); if (!v || v.status !== 'pending') return; const why = Ctl.whyNot(v); if (why) { UI.toast(why, 'error'); return; } const c = Ctl.c(); if (c.lockDate && v.date <= c.lockDate) { UI.toast('That period is locked.', 'error'); return; } v.status = 'posted'; v.checker = App.user.name; v.checkedAt = new Date().toISOString(); Books.save(); await Log.add('Voucher approved', `${v.no} ${fmtINR(Books.amt(v))} (maker ${v.maker})`, { ai: v.ai }); UI.toast(v.no + ' approved and posted.', 'good'); renderNav(); Router.render(); },
  reject(id) { const v = Books.vch(id); if (!v) return; UI.modal({ title: 'Reject ' + v.no, body: `<div class="field"><label for="rj">Reason (required)</label><textarea id="rj" rows="3"></textarea></div>`, actions: [{ label: 'Cancel' }, { label: 'Reject', kind: 'danger', onClick: async el => { const r = $('#rj', el).value.trim(); if (r.length < 5) { UI.toast('Give a reason of at least 5 characters.', 'error'); return false; } v.status = 'rejected'; v.checker = App.user.name; v.meta.rejectReason = r; Books.save(); await Log.add('Voucher rejected', `${v.no}: ${r}`, { ai: v.ai }); renderNav(); Router.render(); } }] }); },
  async withdraw(id) { const v = Books.vch(id); if (!v || v.makerId !== App.user.id || v.status !== 'pending') return; const b = Books.cur(); b.vouchers = b.vouchers.filter(x => x.id !== id); Books.save(); await Log.add('Pending voucher withdrawn', v.no); renderNav(); Router.render(); }
};
Actions['v-approve'] = id => Approve.approve(id); Actions['v-reject'] = id => Approve.reject(id); Actions['v-withdraw'] = id => Approve.withdraw(id);
Actions['v-view'] = id => viewVoucher(id);
Actions['v-reverse'] = async id => { const v = Books.vch(id); if (!v || !(await UI.confirm('Reverse ' + v.no + '?', 'Posted vouchers are never edited. A reversing journal with swapped debits and credits will be created (and approved if required).', 'Create reversal'))) return; const j = { id: uid('v'), no: '', type: 'Journal', date: isoToday(), narr: 'Reversal of ' + v.no, lines: v.lines.map(l => ({ acc: l.acc, dr: l.cr, cr: l.dr })), status: 'posted', maker: App.user.name, makerId: App.user.id, checker: null, ai: false, createdAt: new Date().toISOString(), meta: { reversalOf: v.id }, ref: '' }, as = Ctl.assess(j); if (as.blocks.length) { UI.toast(as.blocks[0], 'error'); return; } j.status = as.needs ? 'pending' : 'posted'; j.no = Books.nextNo(Books.cur(), 'Journal', fyOfDate(j.date)); Books.cur().vouchers.push(j); v.reversed = j.id; Books.save(); await Log.add('Voucher reversed', v.no + ' by ' + j.no); renderNav(); Router.render(); UI.toast('Reversal ' + j.no + (j.status === 'pending' ? ' sent for approval.' : ' posted.'), 'good'); };
function viewVoucher(id) {
  const v = Books.vch(id); if (!v) return; const m = v.meta || {}, p = m.party ? Books.party(m.party) : null, canA = v.status === 'pending' && Ctl.canApprove(v);
  const acts = [{ label: 'Close' }]; if (v.status === 'pending') { if (v.makerId === App.user.id) acts.unshift({ label: 'Withdraw', kind: 'danger', onClick: () => Approve.withdraw(id) }); acts.push({ label: 'Reject', kind: 'danger', onClick: () => { setTimeout(() => Approve.reject(id), 30); } }, { label: 'Approve', kind: 'primary', disabled: !canA, onClick: () => Approve.approve(id) }); }
  if (v.status === 'posted' && !v.reversed && !m.reversalOf && App.can(VTYPES[v.type].mod, 'create')) acts.unshift({ label: 'Reverse', icon: 'rev', onClick: () => setTimeout(() => Actions['v-reverse'](id), 30) });
  if (v.type === 'Sales' && v.status === 'posted') acts.unshift({ label: 'Invoice', icon: 'print', onClick: () => setTimeout(() => Invoice.open(id), 30) });
  UI.modal({ title: v.no + ' · ' + v.type, wide: true, actions: acts, body: `<div class="row" style="margin-bottom:10px">${vchChip(v.status)}${v.ai ? '<span class="tag-ai">AI-drafted</span>' : ''}${v.reversed ? '<span class="chip">Reversed</span>' : ''}<span class="muted small">${fmtDate(v.date)} · prepared by ${esc(v.maker)}${v.checker ? ' · checked by ' + esc(v.checker) : v.autoPosted ? ' · posted below approval limit' : ''}</span></div><p style="margin-bottom:10px">${esc(v.narr)}</p>${p ? `<p class="small muted" style="margin-bottom:10px">${esc(p.name)} · GSTIN ${esc(p.gstin || '—')}${m.billNo ? ' · Bill ' + esc(m.billNo) : ''}${m.tds ? ' · TDS ' + fmtINR(m.tds) + ' (' + esc(m.tdsSec) + ')' : ''}</p>` : ''}
    ${grid([{ h: 'Ledger', v: l => esc(Books.accName(l.acc)) }, { h: 'Debit', c: 'amt', v: l => amtCell(l.dr) }, { h: 'Credit', c: 'amt', v: l => amtCell(l.cr) }], v.lines)}
    ${(v.flags || []).length ? `<div class="alertbox">${v.flags.map(f => `<div class="a warn">${esc(f)}</div>`).join('')}</div>` : ''}${m.rejectReason ? `<div class="note bad" style="margin-top:10px"><b>Rejected:</b> ${esc(m.rejectReason)}</div>` : ''}${v.status === 'pending' && !canA ? `<div class="note warn" style="margin-top:10px">${esc(Ctl.whyNot(v) || '')}</div>` : ''}<p class="muted small" style="margin-top:10px">Entered ${fmtDateTime(v.createdAt)}${m.aiNote ? ' · ' + esc(m.aiNote) : ''}</p>` });
}

/* ---------- Views: vouchers, approvals, ledgers ---------- */
Views.vouchers = () => {
  const b = Books.cur(), u = App.ui; u.vType = u.vType || 'All'; u.vStat = u.vStat || 'All'; u.vQ = u.vQ || '';
  const rows = b.vouchers.filter(v => (u.vType === 'All' || v.type === u.vType) && (u.vStat === 'All' || v.status === u.vStat.toLowerCase()) && (!u.vQ || (v.no + v.narr + (Books.party(v.meta?.party)?.name || '') + Books.amt(v)).toLowerCase().includes(u.vQ.toLowerCase()))).sort((x, y) => y.date.localeCompare(x.date) || y.createdAt.localeCompare(x.createdAt));
  const types = Object.keys(VTYPES).filter(t => App.can(VTYPES[t].mod, 'create'));
  return `<div class="page-head"><div><h1>Vouchers & journal entries</h1><p class="sub">Every entry is double-entry, checked against GST and TDS rules as you type, and routed through maker-checker. Shortcuts: <kbd>F4</kbd> Contra <kbd>F5</kbd> Payment <kbd>F6</kbd> Receipt <kbd>F7</kbd> Journal <kbd>F8</kbd> Sales <kbd>F9</kbd> Purchase.</p></div><div class="head-actions">${expBtns('vouchers', 'Voucher register', ['No', 'Date', 'Type', 'Narration', 'Amount', 'Status', 'Maker', 'Checker'], rows.map(v => [v.no, v.date, v.type, v.narr, Books.amt(v), v.status, v.maker, v.checker || '']))}</div></div>
  <div class="row" style="margin-bottom:14px">${types.map(t => `<button class="btn ${t === 'Journal' ? 'primary' : ''}" data-act="v-new" data-arg="${t}">${icon('plus')}${t}${VTYPES[t].key ? ` <kbd>${VTYPES[t].key}</kbd>` : ''}</button>`).join('')}</div>
  ${hasBooks() ? `<div class="filters"><select data-change="v-type" aria-label="Type"><option>All</option>${Object.keys(VTYPES).map(t => `<option ${u.vType === t ? 'selected' : ''}>${t}</option>`).join('')}</select><select data-change="v-stat" aria-label="Status">${['All', 'Posted', 'Pending', 'Rejected'].map(t => `<option ${u.vStat === t ? 'selected' : ''}>${t}</option>`).join('')}</select><input type="search" placeholder="Search number, narration, party, amount" data-change="v-q" value="${esc(u.vQ)}" style="min-width:260px"><span class="muted small">${rows.length} of ${b.vouchers.length}</span></div>
  ${grid([{ h: 'Voucher', v: v => `<button class="link" data-act="v-view" data-arg="${v.id}">${esc(v.no)}</button>` }, { h: 'Date', v: v => fmtDate(v.date) }, { h: 'Type', v: v => esc(v.type) }, { h: 'Narration', v: v => esc(v.narr).slice(0, 70) + (v.ai ? ' <span class="tag-ai">AI</span>' : '') }, { h: 'Amount', c: 'amt', v: v => fmt2(Books.amt(v)) }, { h: 'Status', v: v => vchChip(v.status) }, { h: 'Maker / checker', v: v => `<span class="small">${esc(v.maker)}${v.checker ? ' → ' + esc(v.checker) : ''}</span>` }], rows.slice(0, 200))}${rows.length > 200 ? '<p class="muted small" style="margin-top:8px">Showing the latest 200. Export for the full register.</p>' : ''}` : noBooks('vouchers')}`;
};
Changes['v-type'] = el => { App.ui.vType = el.value; Router.render(); }; Changes['v-stat'] = el => { App.ui.vStat = el.value; Router.render(); };
Changes['v-q'] = el => { App.ui.vQ = el.value; Router.render(); const i = $('[data-change="v-q"]'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); };

Views.approvals = () => {
  const b = Books.cur(), pend = b.vouchers.filter(v => v.status === 'pending').sort((x, y) => x.createdAt.localeCompare(y.createdAt)), rej = b.vouchers.filter(v => v.status === 'rejected').slice(-5).reverse(), c = Ctl.c();
  return `<div class="page-head"><div><h1>Approval inbox</h1><p class="sub">AI proposes, humans approve, the audit trail proves it. Maker and checker must be different people, and the amount must be within the approver's limit (${fmtINR(c.doa.approver || 0)} for Finance manager; Admin unlimited).</p></div></div>
  <div class="grid-3"><div class="card"><div class="muted small">Waiting for approval</div><div class="big">${pend.length}</div></div><div class="card"><div class="muted small">Value pending</div><div class="big">${fmtINRShort(sum(pend, v => Books.amt(v)))}</div></div><div class="card"><div class="muted small">AI-drafted in queue</div><div class="big">${pend.filter(v => v.ai).length}</div></div></div>
  ${pend.length ? grid([{ h: 'Voucher', v: v => `<button class="link" data-act="v-view" data-arg="${v.id}">${esc(v.no)}</button>` }, { h: 'Date', v: v => fmtDate(v.date) }, { h: 'Details', v: v => esc(v.narr).slice(0, 64) + (v.ai ? ' <span class="tag-ai">AI</span>' : '') }, { h: 'Amount', c: 'amt', v: v => fmt2(Books.amt(v)) }, { h: 'Maker', v: v => esc(v.maker) }, { h: 'Checks', v: v => { const al = TaxAlerts.check({ type: v.type, date: v.date, party: Books.party(v.meta?.party), taxable: v.meta?.taxable || 0, cgst: v.meta?.cgst || 0, sgst: v.meta?.sgst || 0, igst: v.meta?.igst || 0, gst: (v.meta?.cgst || 0) + (v.meta?.sgst || 0) + (v.meta?.igst || 0), total: v.meta?.total || 0, tds: v.meta?.tds || 0, tdsSec: v.meta?.tdsSec, itc: v.meta?.itc !== false, expAccs: [], amount: Books.amt(v), items: v.meta?.items || [], accs: v.lines.map(l => l.acc), counter: '', cash: v.lines.some(l => l.acc === 'cash') }); return al.length ? `<span class="chip ${al.some(a => a.sev === 'bad') ? 'bad' : 'warn'}">${al.length} alert${al.length > 1 ? 's' : ''}</span>` : '<span class="chip good">Clear</span>'; } }, { h: '', c: 'amt', v: v => `<div class="row" style="justify-content:flex-end;flex-wrap:nowrap"><button class="btn sm" data-act="v-view" data-arg="${v.id}">Review</button>${Ctl.canApprove(v) ? `<button class="btn sm primary" data-act="v-approve" data-arg="${v.id}">Approve</button><button class=\"btn sm danger\" data-act=\"v-reject\" data-arg=\"${v.id}\">Reject</button>` : ''}</div>` }], pend, {}) : '<div class="empty"><b>Inbox is clear</b>Nothing is waiting for approval.</div>'}
  ${rej.length ? `<h2 style="margin:22px 0 10px">Recently rejected</h2>${grid([{ h: 'Voucher', v: v => esc(v.no) }, { h: 'Narration', v: v => esc(v.narr) }, { h: 'Amount', c: 'amt', v: v => fmt2(Books.amt(v)) }, { h: 'Reason', v: v => esc(v.meta?.rejectReason || '') }], rej)}` : ''}`;
};

Views.ledgers = () => {
  const u = App.ui, tab = u.ledTab || 'ledger', fy = fyNow(), { from, to } = fyRange(fy), b = Books.cur();
  const tabs = `<div class="tabs"><button class="tab ${tab === 'ledger' ? 'active' : ''}" data-act="led-tab" data-arg="ledger">Ledger</button><button class="tab ${tab === 'day' ? 'active' : ''}" data-act="led-tab" data-arg="day">Day book</button></div>`;
  if (!hasBooks()) return `<div class="page-head"><div><h1>Ledgers & day book</h1></div></div>${noBooks('ledgers')}`;
  if (tab === 'day') {
    const rows = b.vouchers.filter(v => v.status === 'posted' && v.date >= from && v.date <= to).sort((x, y) => y.date.localeCompare(x.date) || y.no.localeCompare(x.no));
    return `<div class="page-head"><div><h1>Day book</h1><p class="sub">All posted vouchers for FY ${fyLabel(fy)}, newest first.</p></div><div class="head-actions">${expBtns('daybook', 'Day book', ['Date', 'Voucher', 'Type', 'Narration', 'Amount'], rows.map(v => [v.date, v.no, v.type, v.narr, Books.amt(v)]))}</div></div>${tabs}${grid([{ h: 'Date', v: v => fmtDate(v.date) }, { h: 'Voucher', v: v => `<button class="link" data-act="v-view" data-arg="${v.id}">${esc(v.no)}</button>` }, { h: 'Type', v: v => esc(v.type) }, { h: 'Narration', v: v => esc(v.narr) }, { h: 'Amount', c: 'amt', v: v => fmt2(Books.amt(v)) }], rows.slice(0, 300))}`;
  }
  const accId = u.ledAcc && Books.acc(u.ledAcc) ? u.ledAcc : 'bank', L = Rep.ledger(accId, from, to);
  return `<div class="page-head"><div><h1>Ledger</h1><p class="sub">Account-wise statement for FY ${fyLabel(fy)}. Click a voucher number to drill into the entry.</p></div><div class="head-actions">${expBtns('ledger', 'Ledger - ' + L.a.name, ['Date', 'Voucher', 'Particulars', 'Debit', 'Credit', 'Balance'], L.rows.map(r => [r.v.date, r.v.no, r.opp, r.dr || '', r.cr || '', r.bal]))}</div></div>${tabs}
  <div class="filters"><label class="sr" for="led-acc">Account</label><select id="led-acc" data-change="led-acc" style="min-width:300px">${accOpts(accId)}</select><span class="chip">Opening ${fmt2(Math.abs(L.open))} ${L.open >= 0 ? 'Dr' : 'Cr'}</span><span class="chip good">Closing ${fmt2(Math.abs(L.close))} ${L.close >= 0 ? 'Dr' : 'Cr'}</span></div>
  ${grid([{ h: 'Date', v: r => fmtDate(r.v.date) }, { h: 'Voucher', v: r => `<button class="link" data-act="v-view" data-arg="${r.v.id}">${esc(r.v.no)}</button>` }, { h: 'Particulars', v: r => esc(r.opp) }, { h: 'Debit', c: 'amt', v: r => amtCell(r.dr) }, { h: 'Credit', c: 'amt', v: r => amtCell(r.cr) }, { h: 'Balance', c: 'amt', v: r => fmt2(Math.abs(r.bal)) + (r.bal >= 0 ? ' Dr' : ' Cr') }], L.rows, { empty: 'No entries in this year' })}
  <div class="tot-row"><span>Total debit <b>${fmt2(L.tdr)}</b></span><span>Total credit <b>${fmt2(L.tcr)}</b></span></div>`;
};
Actions['led-tab'] = t => { App.ui.ledTab = t; Router.render(); }; Changes['led-acc'] = el => { App.ui.ledAcc = el.value || 'bank'; Router.render(); };
Actions['open-ledger'] = id => { App.ui.ledAcc = id; App.ui.ledTab = 'ledger'; Router.go('ledgers'); };

/* ---------- Financial statements ---------- */
const stRow = (cls, label, v, note) => `<tr class="${cls}"><td>${label}${note ? ` <span class="note-ref">${note}</span>` : ''}</td><td class="amt">${v == null ? '' : (v < 0 ? '(' + fmt2(-v) + ')' : fmt2(v))}</td></tr>`;
Views.reports = () => {
  const u = App.ui, tab = u.repTab || 'tb', fy = fyNow(), { from, to } = fyRange(fy), today = isoToday(), asOn = to > today ? today : to;
  const tabs = [['tb', 'Trial balance'], ['pl', 'Profit & loss'], ['bs', 'Balance sheet'], ['cf', 'Cash flow'], ['ratios', 'Ratios']];
  const head = `<div class="page-head"><div><h1>Financial statements</h1><p class="sub">Schedule III format for FY ${fyLabel(fy)} (up to ${fmtDate(asOn)}). Built live from posted vouchers, so a new entry shows here at once.</p></div><div class="head-actions"><button class="btn" data-act="yearend">${icon('lock')}Year-end close</button></div></div><div class="tabs">${tabs.map(([k, l]) => `<button class="tab ${tab === k ? 'active' : ''}" data-act="rep-tab" data-arg="${k}">${l}</button>`).join('')}</div>`;
  if (!hasBooks()) return head + noBooks('reports');
  if (tab === 'tb') {
    const t = Rep.trial(fy, asOn).sort((a, b) => a.acc.group.localeCompare(b.acc.group) || a.acc.name.localeCompare(b.acc.name)); const td = x => x.close > 0 ? x.close : 0, tc = x => x.close < 0 ? -x.close : 0, dr = sum(t, td), cr = sum(t, tc);
    return head + `<div class="row" style="margin-bottom:12px"><span class="chip ${Math.abs(dr - cr) < 0.01 ? 'good' : 'bad'}">${Math.abs(dr - cr) < 0.01 ? 'Trial balance agrees' : 'Difference ' + fmt2(dr - cr)}</span><span class="spacer"></span>${expBtns('tb', 'Trial balance', ['Group', 'Ledger', 'Opening', 'Period Dr', 'Period Cr', 'Closing Dr', 'Closing Cr'], t.map(x => [x.acc.group, x.acc.name, x.open, x.dr, x.cr, td(x), tc(x)]))}</div>
    ${grid([{ h: 'Ledger', v: x => x.acc.virtual ? esc(x.acc.name) : `<button class="link" data-act="open-ledger" data-arg="${x.acc.id}">${esc(x.acc.name)}</button>` }, { h: 'Group', v: x => `<span class="muted small">${esc(x.acc.group)}</span>` }, { h: 'Opening', c: 'amt', v: x => amtCell(x.open) + (Math.abs(x.open) > .004 ? (x.open > 0 ? ' Dr' : ' Cr') : '') }, { h: 'Debit', c: 'amt', v: x => amtCell(x.dr) }, { h: 'Credit', c: 'amt', v: x => amtCell(x.cr) }, { h: 'Closing Dr', c: 'amt', v: x => amtCell(td(x)) }, { h: 'Closing Cr', c: 'amt', v: x => amtCell(tc(x)) }], t)}<div class="tot-row"><span>Total debit <b>${fmt2(dr)}</b></span><span>Total credit <b>${fmt2(cr)}</b></span></div>`;
  }
  if (tab === 'pl') {
    const p = Rep.pl(from, to > today ? today : to), sub = k => (p.det[k] || []).sort((a, b) => b.v - a.v).map(d => `<tr class="sub"><td>${esc(d.acc.name)}</td><td class="amt">${fmt2(d.v)}</td></tr>`).join('');
    const rows = [['Revenue from operations', p.rev_ops, 'rev_ops', 'I'], ['Other income', p.rev_oth, 'rev_oth', 'II']]; const body = [];
    body.push(stRow('grp', 'I. Revenue from operations', p.rev_ops, '(Note 1)')); body.push(sub('rev_ops')); body.push(stRow('', 'II. Other income', p.rev_oth, '(Note 2)')); body.push(sub('rev_oth')); body.push(stRow('tot', 'III. Total income', p.income)); body.push(stRow('grp', 'IV. Expenses', null));
    [['exp_cogs', 'Cost of materials consumed / purchases'], ['exp_inv', 'Changes in inventories'], ['exp_emp', 'Employee benefit expense'], ['exp_fin', 'Finance costs'], ['exp_dep', 'Depreciation and amortisation'], ['exp_oth', 'Other expenses']].forEach(([k, n]) => { body.push(stRow('', n, p[k])); body.push(sub(k)); });
    body.push(stRow('tot', 'Total expenses', p.expense), stRow('grand', 'V. Profit before tax (III − IV)', p.pbt), stRow('', 'VI. Tax expense (current tax)', p.exp_tax), stRow('grand', 'VII. Profit for the period', p.pat));
    const flat = []; flat.push(['Revenue from operations', p.rev_ops], ['Other income', p.rev_oth], ['Total income', p.income], ['Cost of materials', p.exp_cogs], ['Changes in inventories', p.exp_inv], ['Employee benefit expense', p.exp_emp], ['Finance costs', p.exp_fin], ['Depreciation', p.exp_dep], ['Other expenses', p.exp_oth], ['Total expenses', p.expense], ['Profit before tax', p.pbt], ['Tax expense', p.exp_tax], ['Profit for the period', p.pat]);
    const notional = r2(Math.max(0, p.pbt) * CONFIG.corpTax / 100);
    return head + `<div class="row" style="margin-bottom:12px"><span class="chip info">Statement of Profit and Loss, Schedule III Division I</span><span class="spacer"></span>${expBtns('pl', 'Profit and loss FY ' + fyLabel(fy), ['Particulars', 'Amount'], flat)}</div><div class="table-wrap"><table class="stmt"><tbody>${body.join('')}</tbody></table></div>${p.exp_tax === 0 && p.pbt > 0 ? `<div class="note warn" style="margin-top:12px">No income tax provision is booked. At ${CONFIG.corpTax}% (section 115BAA rate) the provision would be about ${fmtINR(notional)}. The Month-end close assistant can draft the journal.</div>` : ''}`;
  }
  if (tab === 'bs') {
    const bs = Rep.bs(fy, asOn), fmtv = App.ui.bsFmt || 'v';
    const side = (arr, tot, label) => arr.map(g => `<tr class="grp"><td colspan="2">${esc(g.g)}</td></tr>` + g.items.map(i => `<tr class="sub"><td>${esc(i.n)}${i.k === 'eq_res' ? ` <span class="note-ref">(incl. current profit ${fmt2(i.cur)})</span>` : ''}</td><td class="amt">${i.v < 0 ? '(' + fmt2(-i.v) + ')' : fmt2(i.v)}</td></tr>`).join('')).join('');
    const flat = []; ['L', 'A'].forEach(s => bs[s].forEach(g => g.items.forEach(i => flat.push([s === 'L' ? 'Equity and liabilities' : 'Assets', g.g, i.n, i.v]))));
    const toggle = `<div class="seg"><button class="${fmtv === 'v' ? 'on' : ''}" data-act="bs-fmt" data-arg="v">Schedule III (vertical)</button><button class="${fmtv === 'h' ? 'on' : ''}" data-act="bs-fmt" data-arg="h">Horizontal (proprietor)</button></div>`;
    const view = fmtv === 'v' ? `<div class="table-wrap"><table class="stmt"><tbody><tr class="grp"><td colspan="2">EQUITY AND LIABILITIES</td></tr>${side(bs.L)}${stRow('grand', 'TOTAL', bs.totL)}<tr class="grp"><td colspan="2">ASSETS</td></tr>${side(bs.A)}${stRow('grand', 'TOTAL', bs.totA)}</tbody></table></div>`
      : `<div class="two-col"><div class="table-wrap"><table class="stmt"><thead><tr class="grp"><td>Liabilities</td><td class="amt">₹</td></tr></thead><tbody>${side(bs.L)}${stRow('grand', 'Total', bs.totL)}</tbody></table></div><div class="table-wrap"><table class="stmt"><thead><tr class="grp"><td>Assets</td><td class="amt">₹</td></tr></thead><tbody>${side(bs.A)}${stRow('grand', 'Total', bs.totA)}</tbody></table></div></div>`;
    return head + `<div class="row" style="margin-bottom:12px">${toggle}<span class="chip ${Math.abs(bs.diff) < 0.01 ? 'good' : 'bad'}">${Math.abs(bs.diff) < 0.01 ? 'Balance sheet balances' : 'Out of balance by ' + fmt2(bs.diff)}</span><span class="muted small">As on ${fmtDate(asOn)}</span><span class="spacer"></span>${expBtns('bs', 'Balance sheet as on ' + asOn, ['Side', 'Group', 'Item', 'Amount'], flat)}</div>${view}`;
  }
  if (tab === 'cf') {
    const c = Rep.cf(fy), row = (l, v, cls = 'sub') => stRow(cls, l, v);
    const body = [stRow('grp', 'A. Cash flow from operating activities', null), row('Profit before tax', c.pl.pbt), row('Add: depreciation', c.pl.exp_dep), row('Add: finance costs', c.pl.exp_fin), row('Less: interest income', -c.pl.rev_oth), stRow('tot', 'Operating profit before working capital changes', c.opPre), ...c.wc.map(w => row('(Increase)/decrease: ' + w[0], w[1])), row('Income taxes paid', -c.taxPaid), stRow('grand', 'Net cash from operating activities (A)', c.cfo),
      stRow('grp', 'B. Cash flow from investing activities', null), row('Purchase of property, plant and equipment', c.capex), row('Other non-current assets', c.other), row('Interest received', c.intRec), stRow('grand', 'Net cash from investing activities (B)', c.cfi),
      stRow('grp', 'C. Cash flow from financing activities', null), row('Proceeds / (repayment) of borrowings', c.borrow), row('Share capital and other equity movements', c.capital), row('Finance costs paid', -c.finCost), stRow('grand', 'Net cash from financing activities (C)', c.cff),
      stRow('tot', 'Net increase / (decrease) in cash (A+B+C)', c.net), row('Cash and cash equivalents at start', c.open), stRow('grand', 'Cash and cash equivalents at end', c.close)];
    const flat = [['Operating profit before WC', c.opPre], ['Net cash from operating', c.cfo], ['Net cash from investing', c.cfi], ['Net cash from financing', c.cff], ['Net change', c.net], ['Opening cash', c.open], ['Closing cash', c.close]];
    return head + `<div class="row" style="margin-bottom:12px"><span class="chip info">Indirect method, AS 3 / Ind AS 7</span><span class="chip ${Math.abs(c.diff) < 0.01 ? 'good' : 'bad'}">${Math.abs(c.diff) < 0.01 ? 'Reconciles to balance sheet cash' : 'Difference ' + fmt2(c.diff)}</span><span class="spacer"></span>${expBtns('cf', 'Cash flow statement FY ' + fyLabel(fy), ['Particulars', 'Amount'], flat)}</div><div class="table-wrap"><table class="stmt"><tbody>${body.join('')}</tbody></table></div>`;
  }
  const R = Rep.ratios(fy), fmtr = r => r.v == null ? '—' : r.fmt === '₹' ? fmtINRShort(r.v) : r.v.toFixed(r.fmt === 'x' ? 2 : 1) + (r.fmt === '%' ? '%' : r.fmt === 'days' ? ' days' : 'x');
  return head + `<div class="row" style="margin-bottom:12px"><span class="muted small">${R.filter(r => r.flag === 'bad').length} red flag(s). Benchmarks are indicative for Indian manufacturing SMEs.</span><span class="spacer"></span>${expBtns('ratios', 'Ratios', ['Group', 'Ratio', 'Value', 'Benchmark', 'Flag'], R.map(r => [r.grp, r.name, fmtr(r), r.bench, r.flag]))}</div>${grid([{ h: 'Group', v: r => esc(r.grp) }, { h: 'Ratio', v: r => esc(r.name) }, { h: 'Value', c: 'amt', v: r => `<b>${fmtr(r)}</b>` }, { h: 'Benchmark', v: r => esc(r.bench) }, { h: 'Signal', v: r => r.flag === 'ok' ? '<span class="chip good">Healthy</span>' : r.flag === 'bad' ? '<span class="chip bad">Review</span>' : '<span class="chip">n/a</span>' }], R)}`;
};
Actions['rep-tab'] = t => { App.ui.repTab = t; Router.render(); }; Actions['bs-fmt'] = t => { App.ui.bsFmt = t; Router.render(); };
Actions.yearend = () => {
  const fy = fyNow(), { from, to } = fyRange(fy), p = Rep.pl(from, to), pend = Books.cur().vouchers.filter(v => v.status === 'pending' && v.date >= from && v.date <= to).length, notional = r2(Math.max(0, p.pbt) * CONFIG.corpTax / 100);
  UI.modal({ title: 'Year-end close, FY ' + fyLabel(fy), body: `<ul class="plain"><li>${pend ? `<b style="color:var(--red)">${pend} pending voucher(s)</b> in this year. Approve or reject them first.` : 'No pending vouchers.'}</li><li>Profit before tax ${fmtINR(p.pbt)}; tax booked ${fmtINR(p.exp_tax)}.</li><li>${p.exp_tax === 0 ? `Tax provision of about ${fmtINR(notional)} at ${CONFIG.corpTax}% can be drafted as a journal.` : 'Tax provision already booked.'}</li><li>Profit transfers to Reserves and Surplus automatically: the next year opens with it in the balance sheet.</li><li>Locking the year stops back-dated entries (Admin can unlock in Controls).</li></ul>`, actions: [{ label: 'Cancel' }, { label: 'Draft tax provision', disabled: p.exp_tax !== 0 || notional <= 0, onClick: () => { setTimeout(() => VForm.open('Journal', { date: to, narr: 'Provision for income tax, FY ' + fyLabel(fy), lines: [{ acc: 'taxexp', dr: String(notional), cr: '' }, { acc: 'taxprov', dr: '', cr: String(notional) }] }), 30); } }, { label: 'Lock the year', kind: 'primary', disabled: !App.can('controls', 'edit'), onClick: async () => { Ctl.c().lockDate = to; Books.save(); await Log.add('Period locked', 'Up to ' + to); UI.toast('Locked up to ' + fmtDate(to), 'good'); Router.render(); } }] });
};
