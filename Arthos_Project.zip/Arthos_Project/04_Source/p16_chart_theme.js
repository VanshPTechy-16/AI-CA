/* ===================== CHART THEME + SELF-HEAL =====================
   Root cause of blank charts: Motion.apply replaced Chart.defaults.animation with a bare object, so colour
   animations lost their type. The first hover or theme update threw "this._fn is not a function" inside
   Chart.js's shared animation loop, which stopped the loop for EVERY chart: all charts drawn afterwards stayed
   blank. Fixed in Motion.apply (keeps Chart.js defaults) and guarded here so the loop can never die again.
   This module also redraws charts whenever the theme, style or device light/dark changes, and self-heals any
   chart that ends up empty, zero-sized or detached. */
const ChartTheme = (() => {
  const live = () => (window.Chart && Chart.instances ? Object.values(Chart.instances) : []);
  const css = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
  const sig = () => { const r = document.documentElement; return [r.dataset.skin, r.dataset.theme, css('--accent'), css('--ink-2'), css('--muted'), css('--line'), css('--amber'), css('--blue')].join('|'); };
  let drawnSig = '', lastRebuild = 0, timers = [], raf = 0;

  /* Guard: an animation with no interpolator jumps to its end value instead of crashing the shared loop. */
  if (window.Chart && Chart.Animation && Chart.Animation.prototype && !Chart.Animation.prototype.$arthosSafe) {
    const P = Chart.Animation.prototype, tick = P.tick; P.$arthosSafe = true;
    P.tick = function (date) { if (typeof this._fn !== 'function') this._fn = (from, to, f) => (f >= 1 ? to : from); try { return tick.call(this, date); } catch (e) { try { this._active = false; this._target[this._prop] = this._to; } catch (x) { /* ignore */ } console.error('chart animation', e); } };
  }

  const setDefaults = () => { if (!window.Chart) return; try { Chart.defaults.color = css('--ink-2') || Chart.defaults.color; Chart.defaults.borderColor = css('--line') || Chart.defaults.borderColor; } catch (e) { /* ignore */ } };
  const isBlank = c => { const cv = c.canvas; if (!cv.width || !cv.height) return true; try { const d = cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data; for (let i = 3; i < d.length; i += 40) if (d[i]) return false; return true; } catch (e) { return false; } };
  const canRender = () => typeof Router !== 'undefined' && App.session && App.session.userId && document.getElementById('view');

  const heal = () => {
    live().forEach(c => {
      try {
        const cv = c.canvas; if (!cv || !cv.isConnected) { c.destroy(); return; }
        const box = cv.parentElement; if (!box || !box.clientWidth || !box.clientHeight) return;
        if (!cv.width || !cv.height || Math.abs(cv.clientWidth - box.clientWidth) > 2) c.resize();
        if (isBlank(c)) { c.stop(); c.resize(); c.update('none'); if (isBlank(c)) c.render(); }
      } catch (e) { console.error('chart heal', e); }
    });
    const view = document.getElementById('view'); if (!view || !window.Chart) return;
    const bad = [...view.querySelectorAll('.chart-box canvas')].some(cv => { if (!cv.clientWidth || !cv.clientHeight) return false; const c = Chart.getChart(cv); return !c || isBlank(c); });
    if ((bad || drawnSig !== sig()) && Date.now() - lastRebuild > 3000 && canRender()) { lastRebuild = Date.now(); Router.render(); }
  };
  const schedule = () => { timers.forEach(clearTimeout); timers = [80, 500, 1200, 2500].map(ms => setTimeout(heal, ms)); };
  /* Theme changed: if the charts on screen were drawn with other colours, redraw the screen once. */
  const onTheme = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => { setDefaults(); if (canRender() && drawnSig !== sig() && document.querySelector('#view canvas')) Router.render(); else schedule(); }); };
  const rendered = () => { drawnSig = sig(); schedule(); };

  if (window.Chart && typeof Chart.register === 'function') Chart.register({ id: 'arthosTheme', afterInit(c) { const cv = c.canvas; if (!cv || cv.$arthosHooked) return; cv.$arthosHooked = true; cv.addEventListener('contextlost', e => e.preventDefault()); cv.addEventListener('contextrestored', () => { try { c.update('none'); } catch (e) { /* gone */ } }); } });
  return { heal, schedule, onTheme, rendered, setDefaults, sig };
})();
/* Never let page-transition or skin-fade CSS hide a chart canvas. */
document.head.insertAdjacentHTML('beforeend', '<style id="chart-theme-css">.chart-box canvas{animation:none!important;transition:none!important;opacity:1!important}</style>');
/* Every render: drop charts whose canvas was removed, use current theme colours, then check the new charts. */
(() => { const base = Router.render.bind(Router); Router.render = function () {
  (window.Chart && Chart.instances ? Object.values(Chart.instances) : []).forEach(c => { if (!c.canvas || !c.canvas.isConnected) { try { c.destroy(); } catch (e) { /* gone */ } } });
  ChartTheme.setDefaults(); base(); ChartTheme.rendered();
}; })();
/* Theme / style changes from anywhere (buttons, palette, settings, restore). */
(() => { const at = applyTheme; applyTheme = function () { const r = at.apply(this, arguments); ChartTheme.onTheme(); return r; }; })();
new MutationObserver(() => ChartTheme.onTheme()).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme', 'data-skin'] });
/* Device light/dark switch while on "Match device". */
if (window.matchMedia) { const mq = matchMedia('(prefers-color-scheme: dark)'), on = () => { const t = App.core && App.core.settings && App.core.settings.theme; if (!t || t === 'system') applyTheme(); else ChartTheme.onTheme(); }; mq.addEventListener ? mq.addEventListener('change', on) : mq.addListener && mq.addListener(on); }
/* Back to the tab, back/forward cache, window resize. */
document.addEventListener('visibilitychange', () => { if (!document.hidden) ChartTheme.schedule(); });
window.addEventListener('pageshow', () => ChartTheme.schedule());
(() => { let t = 0; window.addEventListener('resize', () => { clearTimeout(t); t = setTimeout(() => ChartTheme.schedule(), 200); }); })();

