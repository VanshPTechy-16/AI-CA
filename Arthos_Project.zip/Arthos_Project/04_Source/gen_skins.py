"""Generates the ten Arthos.AI skins (assets/skins.css and assets/skins.js).
Every text/background pair is checked against WCAG AA (4.5:1) and the text colour is adjusted until it passes,
so no skin can ship with unreadable text. Run:  python3 gen_skins.py"""
import colorsys, os, json
HERE = os.path.dirname(os.path.abspath(__file__))

def hx(h):
    h = h.lstrip('#'); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
def tohex(c): return '#%02X%02X%02X' % tuple(max(0, min(255, round(v))) for v in c)
def over(fg, a, bg): return tuple(fg[i] * a + bg[i] * (1 - a) for i in range(3))
def lum(c):
    def f(v):
        v /= 255; return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2])
def cr(a, b):
    l1, l2 = lum(a), lum(b); return (max(l1, l2) + 0.05) / (min(l1, l2) + 0.05)
def mincr(fg, bgs): return min(cr(fg, b) for b in bgs)
def ensure(fg, bgs, target=4.7):
    """Move fg lightness away from the backgrounds until every pair reaches the target ratio."""
    if mincr(fg, bgs) >= target: return fg
    avg = sum(lum(b) for b in bgs) / len(bgs); r, g, b = [v / 255 for v in fg]; h, l, s = colorsys.rgb_to_hls(r, g, b)
    step = -0.004 if avg > 0.4 else 0.004
    for _ in range(260):
        l = max(0, min(1, l + step)); c = tuple(v * 255 for v in colorsys.hls_to_rgb(h, l, s))
        if mincr(c, bgs) >= target: return c
    return (0, 0, 0) if avg > 0.4 else (255, 255, 255)
def best_on(bg, cands=((255, 255, 255), (0, 0, 0)), pref=None):
    allc = ([pref] if pref else []) + list(cands); good = [c for c in allc if cr(c, bg) >= 4.7]
    return good[0] if good else max(allc, key=lambda c: cr(c, bg))
def soft(color, surface, a): return over(color, a, surface)

# ---------------------------------------------------------------- palettes
# keys: bg surface s2 ink ink2 muted line ls accent good red amber blue sb si ss sh sa sm  (surface/s2/line/sh/sa may carry alpha as (hex, alpha))
P = {}
P['ledger/light'] = dict(bg='#F2F4F3', surface='#FFFFFF', s2='#F7F9F8', ink='#13213C', ink2='#3F4C66', muted='#68748A', line='#DCE2DF', ls='#C3CCC8', accent='#1D7553', good='#1D7553', red='#B42318', amber='#94600F', blue='#2A5CAA', sb='#13213C', si='#C9D3E4', ss='#FFFFFF', sh='#1C2D4F', sa='#24395F', sm='#8796B3')
P['ledger/dark'] = dict(bg='#0D1421', surface='#141D2D', s2='#192437', ink='#E5EBF4', ink2='#B4BFD1', muted='#8693A9', line='#25314A', ls='#334262', accent='#3DB487', good='#3DB487', red='#F07A6E', amber='#E3AA4E', blue='#7FA8EE', sb='#0A101B', si='#AFBBD0', ss='#FFFFFF', sh='#141E31', sa='#1B2942', sm='#6E7C96')
P['boardroom/light'] = dict(bg='#EEF2F8', surface='#FFFFFF', s2='#F5F8FC', ink='#0E1A33', ink2='#38465F', muted='#66748B', line='#D7DFEB', ls='#BAC7DA', accent='#1B5FC1', good='#17784F', red='#B3261E', amber='#8F5B00', blue='#1B5FC1', sb='#FFFFFF', si='#39475F', ss='#0E1A33', sh='#EEF3FA', sa='#E3EDFB', sm='#66748B')
P['boardroom/dark'] = dict(bg='#0B1322', surface='#121C30', s2='#162239', ink='#E4EAF5', ink2='#B3BFD3', muted='#8794AB', line='#23304A', ls='#33445F', accent='#5B9BFF', good='#4CC38A', red='#F07A6E', amber='#E3AA4E', blue='#7FA8EE', sb='#0E1729', si='#AAB7CE', ss='#FFFFFF', sh='#16233B', sa='#1B2D4D', sm='#6F7F9A')
P['midnight'] = dict(bg='#070B12', surface='#0E1520', s2='#131C2A', ink='#DCE5F2', ink2='#AAB8CC', muted='#76869D', line='#1D2938', ls='#2B3B50', accent='#F2A93B', good='#4ADE80', red='#FF6B5E', amber='#F2A93B', blue='#6CB6FF', sb='#05080D', si='#8FA0B8', ss='#F2A93B', sh='#0C131D', sa='#141E2C', sm='#586880')
P['gulabi'] = dict(bg='#FDF1F4', surface='#FFFFFF', s2='#FFF7F9', ink='#3A1428', ink2='#6A3A52', muted='#8F6A7C', line='#F0D5DD', ls='#E2B6C4', accent='#B3295B', good='#1F7A52', red='#B3261E', amber='#8E5A00', blue='#5B4BA8', sb='#3A1428', si='#E9CCD8', ss='#FFFFFF', sh='#4C1D36', sa='#5E2644', sm='#B58BA0')
P['aurora'] = dict(bg='#412C7C', bgbase='#0B0A24', surface=('#FFFFFF', .07), s2=('#FFFFFF', .05), ink='#EEEBFF', ink2='#C6C0EE', muted='#9A94C6', line=('#FFFFFF', .12), ls=('#FFFFFF', .24), accent='#67E8D0', good='#6EE7B7', red='#FF8A9B', amber='#FFD27A', blue='#A5B4FF', sb=('#0C0A28', .55), si='#C6C0EE', ss='#FFFFFF', sh=('#FFFFFF', .07), sa=('#8B5CF6', .30), sm='#8C86B8')
P['ocean'] = dict(bg='#EEF6F8', surface='#FFFFFF', s2='#F4FAFB', ink='#0B2530', ink2='#33525E', muted='#5C7883', line='#D3E4E9', ls='#B3CDD5', accent='#0E7490', good='#0F766E', red='#B91C1C', amber='#92400E', blue='#1D4ED8', sb='#0B3A4A', si='#BFE0E8', ss='#FFFFFF', sh='#124B5E', sa='#17617A', sm='#8FBAC6')
P['forest'] = dict(bg='#0B1410', surface='#111D17', s2='#16251D', ink='#E6F2EA', ink2='#B5CCBE', muted='#86A294', line='#1F3328', ls='#2D4A3A', accent='#6EE7A0', good='#6EE7A0', red='#FF8B7E', amber='#F5C25B', blue='#8CC4F5', sb='#08100C', si='#A9C2B3', ss='#FFFFFF', sh='#101C15', sa='#17291F', sm='#6F8B7B')
P['paper'] = dict(bg='#F7F7F5', surface='#FFFFFF', s2='#FAFAF8', ink='#1A1A1A', ink2='#4A4A4A', muted='#6E6E6E', line='#E3E3DF', ls='#CFCFC9', accent='#1A1A1A', good='#1B6B3F', red='#B3261E', amber='#8A5A00', blue='#1E4FA0', sb='#F0F0EC', si='#3A3A3A', ss='#000000', sh='#E8E8E3', sa='#DDDDD6', sm='#6B6B6B')
P['marigold'] = dict(bg='#FBF4EC', surface='#FFFFFF', s2='#FFFAF5', ink='#2B1B12', ink2='#5C4636', muted='#7D6454', line='#EEDFD0', ls='#DDC7B0', accent='#C2410C', good='#15803D', red='#B91C1C', amber='#92400E', blue='#3730A3', sb='#2E1065', si='#DDD6FE', ss='#FFFFFF', sh='#3B1A7E', sa='#4C1D95', sm='#B4A5E8')
P['contrast'] = dict(bg='#FFFFFF', surface='#FFFFFF', s2='#F2F2F2', ink='#000000', ink2='#1A1A1A', muted='#404040', line='#8A8A8A', ls='#000000', accent='#0033CC', good='#006B2E', red='#B00020', amber='#7A4B00', blue='#0033CC', sb='#000000', si='#FFFFFF', ss='#FFFFFF', sh='#262626', sa='#0033CC', sm='#D0D0D0')

META = [  # id, name, tag, mode, blurb, radius(s,m,l), font, shadow
    ('ledger', 'Ledger', 'Professional', 'auto', 'Navy ink and ledger green. The default for audit rooms.', (6, 10, 16), 'Inter', '0 1px 2px rgba(19,33,60,.05),0 6px 20px rgba(19,33,60,.07)'),
    ('boardroom', 'Boardroom', 'Corporate', 'auto', 'Clean blue with a light sidebar. Looks like a listed-company MIS pack.', (3, 5, 8), 'Inter', '0 1px 2px rgba(14,26,51,.07)'),
    ('midnight', 'Midnight Terminal', 'Data-dense', 'dark', 'Monospace, amber on black. For long reconciliation sessions.', (2, 3, 6), "'JetBrains Mono','Inter',ui-monospace,Menlo,monospace", 'none'),
    ('gulabi', 'Gulabi', 'Aesthetic', 'light', 'Jaipur rose, plum and gold with serif headings.', (9, 15, 24), 'Inter', '0 2px 4px rgba(58,20,40,.06),0 12px 30px rgba(179,41,91,.10)'),
    ('aurora', 'Aurora Glass', 'Aesthetic', 'dark', 'Gradient mesh and frosted glass panels.', (11, 18, 26), 'Inter', '0 10px 36px rgba(0,0,0,.38)'),
    ('ocean', 'Ocean', 'Fresh', 'light', 'Teal and cool white with a deep-sea sidebar.', (8, 12, 18), 'Inter', '0 1px 2px rgba(11,37,48,.06),0 8px 24px rgba(14,116,144,.10)'),
    ('forest', 'Forest', 'Calm dark', 'dark', 'Deep green with mint highlights. Easy on the eyes at night.', (6, 10, 16), 'Inter', '0 8px 28px rgba(0,0,0,.4)'),
    ('paper', 'Paper', 'Minimal', 'light', 'Black on white with serif headings. Reads like a printed report.', (2, 4, 6), 'Inter', 'none'),
    ('marigold', 'Marigold', 'Warm', 'light', 'Orange accents on warm white with an indigo sidebar.', (8, 12, 18), 'Inter', '0 2px 4px rgba(46,16,101,.06),0 10px 26px rgba(194,65,12,.10)'),
    ('contrast', 'High Contrast', 'Accessible', 'light', 'Pure black and white with heavy borders. WCAG AAA text.', (3, 4, 6), 'Inter', 'none'),
]

def build(key, dark):
    p = P[key]; base = hx(p.get('bgbase', p['bg'])); bgw = hx(p['bg'])  # bgw: worst-case page background for the solver
    def col(v, over_bg=None):
        if isinstance(v, tuple): return over(hx(v[0]), v[1], over_bg or bgw)
        return hx(v)
    surface = col(p['surface']); s2 = col(p['s2'], surface if isinstance(p['s2'], tuple) else None)
    if isinstance(p['s2'], tuple): s2 = over(hx(p['s2'][0]), p['s2'][1], bgw)
    sb = col(p['sb']); sh = col(p['sh'], sb); sa = col(p['sa'], sb)
    mixa = .20 if dark else .13
    glass = isinstance(p['surface'], tuple)
    if glass: mixa = .16
    stack = over((255, 255, 255), .22, bgw) if glass else surface
    out = {}
    out['bg'] = p['bg'] if not isinstance(p['bg'], tuple) else p['bg']
    pageBgs = [bgw, surface, s2, stack]
    ink = ensure(hx(p['ink']), pageBgs + [surface], 7.0); ink2 = ensure(hx(p['ink2']), pageBgs, 5.9); muted = ensure(hx(p['muted']), pageBgs, 5.3)
    # accent: text on surfaces AND button fill with readable ink
    accent = hx(p['accent']); ai = best_on(accent)
    for _ in range(3):
        asoft = soft(accent, surface, mixa)
        accent = ensure(accent, [surface, bgw, s2, asoft, stack], 5.0)
        ai = best_on(accent)
        if cr(ai, accent) >= 4.7: break
    asoft = soft(accent, surface, mixa)
    hover = tuple(accent[i] * (1.12 if dark else 0.84) + (255 * .0 if dark else 0) for i in range(3)) if not dark else tuple(min(255, accent[i] * 1.12 + 10) for i in range(3))
    res = {}
    for name in ('good', 'red', 'amber', 'blue'):
        c = hx(p[name])
        for _ in range(4):
            s = soft(c, surface, mixa); c = ensure(c, [surface, bgw, s2, s, stack], 5.7 if glass else 5.3)
        res[name] = (c, soft(c, surface, mixa))
    si = ensure(hx(p['si']), [sb, sh], 5.0); ss = ensure(hx(p['ss']), [sb, sh, sa], 7.0); sm = ensure(hx(p['sm']), [sb, sh, sa], 4.7)
    onred = best_on(res['red'][0]); ongood = best_on(res['good'][0])
    v = {'--bg': p.get('bgbase', p['bg']), '--surface': fmt(p['surface'], surface), '--surface-2': fmt(p['s2'], s2) if not isinstance(p['s2'], tuple) else rgba(p['s2']),
         '--ink': tohex(ink), '--ink-2': tohex(ink2), '--muted': tohex(muted), '--line': rgba(p['line']) if isinstance(p['line'], tuple) else p['line'], '--line-strong': rgba(p['ls']) if isinstance(p['ls'], tuple) else p['ls'],
         '--accent': tohex(accent), '--accent-hover': tohex(hover), '--accent-ink': tohex(ai), '--accent-soft': (tr(accent, mixa) if glass else tohex(asoft)),
         '--good': tohex(res['good'][0]), '--good-soft': (tr(res['good'][0], mixa) if glass else tohex(res['good'][1])), '--red': tohex(res['red'][0]), '--red-soft': (tr(res['red'][0], mixa) if glass else tohex(res['red'][1])), '--amber': tohex(res['amber'][0]), '--amber-soft': (tr(res['amber'][0], mixa) if glass else tohex(res['amber'][1])), '--blue': tohex(res['blue'][0]), '--blue-soft': (tr(res['blue'][0], mixa) if glass else tohex(res['blue'][1])),
         '--side-bg': rgba(p['sb']) if isinstance(p['sb'], tuple) else p['sb'], '--side-ink': tohex(si), '--side-strong': tohex(ss), '--side-hover': rgba(p['sh']) if isinstance(p['sh'], tuple) else p['sh'], '--side-active': rgba(p['sa']) if isinstance(p['sa'], tuple) else p['sa'], '--side-muted': tohex(sm),
         '--on-red': tohex(onred), '--on-good': tohex(ongood), '--on-amber': tohex(best_on(res['amber'][0]))}
    rep = {'ink': mincr(ink, pageBgs), 'muted': mincr(muted, pageBgs), 'accent-text': mincr(accent, [surface, bgw, s2, asoft]), 'accent-ink': cr(ai, accent), 'side-muted': mincr(sm, [sb, sh, sa]), 'side-ink': mincr(si, [sb, sh]), 'red': mincr(res['red'][0], [surface, res['red'][1]])}
    return v, rep, accent
def tr(c, a): return 'rgba(%d,%d,%d,%s)' % (round(c[0]), round(c[1]), round(c[2]), a)
def rgba(t): r, g, b = hx(t[0]); return 'rgba(%d,%d,%d,%s)' % (r, g, b, t[1])
def fmt(v, eff): return rgba(v) if isinstance(v, tuple) else v

EXTRA = {
 'midnight': "h1{font-size:21px;text-transform:uppercase;letter-spacing:.04em}body{font-size:13px;letter-spacing:-.01em}table.t th{text-transform:uppercase;font-size:11px;letter-spacing:.06em}",
 'gulabi': "h1{font-weight:600;font-size:28px}h1,h2,.brand-name{font-family:'Playfair Display',Georgia,serif}.card,.scores{border-color:transparent;box-shadow:var(--shadow)}.btn{border-radius:999px}.score .num{font-family:'Playfair Display',Georgia,serif;border-bottom-color:#E3B04B}.nav-item.active{box-shadow:inset 3px 0 0 #E3B04B}.logo{background:linear-gradient(135deg,#F0C560,#C98A1B);color:#3A1428}body{background-image:radial-gradient(700px 300px at 90% -5%,rgba(227,176,75,.18),transparent)}",
 'aurora': "body{background:radial-gradient(900px 520px at 8% -8%,rgba(139,92,246,.42),transparent 70%),radial-gradient(800px 520px at 100% 0,rgba(20,184,166,.30),transparent 70%),radial-gradient(700px 500px at 50% 110%,rgba(236,72,153,.18),transparent 70%),#0B0A24;background-attachment:fixed}.card,.scores,.table-wrap,.topbar,.statusbar,.sidebar,.kpi{-webkit-backdrop-filter:blur(18px) saturate(150%);backdrop-filter:blur(18px) saturate(150%)}.card,.scores,.table-wrap{box-shadow:var(--shadow)}.modal,.palette,.menu,.copilot{background:#17133F;border:1px solid var(--line-strong)}.toast{background:#EEEBFF;color:#17133F}input[type=text],input[type=password],input[type=email],input[type=number],input[type=search],input[type=date],select,textarea{background:rgba(255,255,255,.06)}select option{background:#17133F;color:#EEEBFF}.logo{background:linear-gradient(135deg,#67E8D0,#8B5CF6);color:#03080C}.btn.primary{background:linear-gradient(135deg,#67E8D0,#7DD3FC);border-color:transparent;color:#04201B}.score .num{background:linear-gradient(135deg,#fff,var(--accent));-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;border-bottom:0}.auth-side{background:rgba(12,10,40,.6)}",
 'ocean': ".card{border-radius:var(--radius)}h1{letter-spacing:-.015em}.logo{border-radius:12px}",
 'forest': ".logo{border-radius:8px}",
 'paper': "h1,h2,.brand-name{font-family:'Playfair Display',Georgia,serif;font-weight:700}.sidebar{border-right:1px solid var(--line)}.nav-item.active{box-shadow:inset 3px 0 0 var(--ink);font-weight:600}.card,.scores{box-shadow:none}",
 'marigold': ".logo{border-radius:50%}.nav-item.active{box-shadow:inset 3px 0 0 #FB923C}",
 'contrast': "body{font-size:15px}.card,.scores,.table-wrap,input,select,textarea,.btn{border-width:2px}:focus-visible{outline:3px solid var(--accent);outline-offset:3px}.nav-item.active{outline:2px solid var(--side-strong);outline-offset:-2px}",
 'boardroom': ".sidebar{border-right:1px solid var(--line)}.nav-item.active{font-weight:600}body{font-size:15px}",
 'ledger': "",
}
css = ['/* generated by gen_skins.py: do not edit by hand */']; js = []; report = {}
for (sid, name, tag, mode, blurb, rad, font, shadow) in META:
    keys = [(sid + '/light', False), (sid + '/dark', True)] if mode == 'auto' else [(sid, mode == 'dark')]
    for key, dark in keys:
        v, rep, accent = build(key, dark); report[key] = rep
        sel = ':root[data-skin="%s"]' % sid + ('[data-theme="%s"]' % ('dark' if dark else 'light') if mode == 'auto' else '')
        body = ';'.join('%s:%s' % kv for kv in v.items()) + ';--radius-s:%dpx;--radius:%dpx;--radius-l:%dpx;--shadow:%s;--font:%s;--font-head:%s;color-scheme:%s' % (rad[0], rad[1], rad[2], shadow, font if font != 'Inter' else "'Inter',system-ui,-apple-system,'Segoe UI',Roboto,'Noto Sans','Noto Sans Devanagari','Noto Sans Gujarati',sans-serif", 'var(--font)', 'dark' if dark else 'light')
        css.append(sel + '{' + body + '}')
        if mode == 'auto' and not dark: css.append(':root[data-skin="%s"]{}' % sid)
        if key == (sid + '/light' if mode == 'auto' else sid): lightacc = accent
    # per-skin extra rules, each prefixed with the skin selector
    for rule in [x for x in EXTRA.get(sid, '').split('}') if x.strip()]:
        sel_, _, decl = rule.partition('{'); sels = ','.join(':root[data-skin="%s"] %s' % (sid, s.strip()) if not s.strip().startswith('body') else ':root[data-skin="%s"] %s' % (sid, s.strip()) for s in sel_.split(','))
        css.append(sels + '{' + decl + '}')
    sw = [P[keys[0][0]]['sb'] if not isinstance(P[keys[0][0]]['sb'], tuple) else '#2B1B6B', tohex(lightacc), P[keys[0][0]]['bg'] if sid != 'aurora' else '#0B0A24']
    js.append({'id': sid, 'name': name, 'tag': tag, 'mode': mode, 'sw': sw, 'blurb': blurb})
open(os.path.join(HERE, 'assets', 'skins.css'), 'w').write('\n'.join(css) + '\n')
open(os.path.join(HERE, 'assets', 'skins.js'), 'w').write('const SKINS = ' + json.dumps(js, indent=1, ensure_ascii=False) + ';\n')
worst = {k: min(r.values()) for k, r in report.items()}
print('skins generated:', len(js), '| css KB:', os.path.getsize(os.path.join(HERE, 'assets', 'skins.css')) // 1024)
for k, r in report.items(): print('  %-16s ink %.1f  muted %.1f  accent-text %.1f  accent-ink %.1f  side-muted %.1f  side-ink %.1f  red %.1f' % (k, r['ink'], r['muted'], r['accent-text'], r['accent-ink'], r['side-muted'], r['side-ink'], r['red']))
print('lowest ratio across all pairs and skins: %.2f' % min(worst.values()))
