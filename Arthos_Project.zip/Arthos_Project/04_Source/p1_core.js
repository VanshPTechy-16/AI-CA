/* ===================== v1.0 CORE ===================== */
const r2 = n => Math.round((+n || 0) * 100) / 100;
const addD = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const dparse = s => new Date(s + 'T00:00:00');
const dayBefore = s => iso(addD(dparse(s), -1));
const daysBetween = (a, b) => Math.round((dparse(b) - dparse(a)) / DAY);
const isoToday = () => iso(today0());
const fmt2 = n => Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const amtCell = n => Math.abs(n) > 0.004 ? fmt2(Math.abs(n)) : '';
const fyOfDate = s => { const d = dparse(s); return d.getMonth() >= 3 ? d.getFullYear() : d.getFullYear() - 1; };
const fyRange = fy => ({ from: fy + '-04-01', to: (fy + 1) + '-03-31' });
const monthKey = s => s.slice(0, 7);
const monthLabel = k => new Date(k + '-01T00:00:00').toLocaleDateString('en-IN', { month: 'short', year: '2-digit' });
const daysInMonth = ym => new Date(+ym.slice(0, 4), +ym.slice(5, 7), 0).getDate();
const normInv = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '').replace(/^0+/, '');
const tokens = s => String(s || '').toUpperCase().split(/[^A-Z0-9]+/).filter(t => t.length > 2 && !/^(NEFT|IMPS|RTGS|UPI|CHQ|DR|CR|LTD|PVT|LLP|AND|THE|INV|REF|HDFC\d*|SBIN\d*|ICIC\d*|UTIB\d*|KKBK\d*)$/.test(t) && !/^\d{6,}$/.test(t));
const sum = (a, f) => a.reduce((s, x, i) => s + (f ? f(x, i) : x), 0);
const by = (a, f) => a.reduce((m, x) => { (m[f(x)] = m[f(x)] || []).push(x); return m; }, {});
const clone = o => JSON.parse(JSON.stringify(o));

Object.assign(ICONS, {
  palette: 'M12 3a9 9 0 1 0 0 18c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.4-.5-.8-.5-1.3 0-1.1.9-2 2-2h2.3A3.7 3.7 0 0 0 21 10.7C21 6.4 17 3 12 3zM7.5 11h.01M10 7.5h.01M14 7.5h.01',
  print: 'M6 9V3h12v6M6 18H4v-7h16v7h-2M7 14h10v7H7z', edit: 'M4 20h4L19 9l-4-4L4 16zM14 6l4 4', pen: 'M3 21l3-1 13-13-2-2L4 18zM14 6l4 4',
  chart: 'M4 20V4M4 20h16M8 16v-5M12 16V8M16 16v-3', wand: 'M15 4l1 2 2 1-2 1-1 2-1-2-2-1 2-1zM3 21l11-11M18 14l.7 1.3L20 16l-1.3.7L18 18l-.7-1.3L16 16l1.3-.7z', calc: 'M5 3h14v18H5zM8 7h8M8 12h2M12 12h2M16 12h.01M8 16h2M12 16h2M16 16h.01', rev: 'M4 7h13l-3-3M20 17H7l3 3'
});

/* ---------- Config additions ---------- */
Object.assign(CONFIG, {
  app: { name: 'Arthos.AI', version: '1.0.0', phase: 'Final' },
  gst: { rates: [0, 5, 18, 40], interestPct: 18, lateFee: 50, lateFeeNil: 20, lateFeeCap: 10000, itcReverseDays: 180 },
  cashLimit: 10000,
  tds: [
    { sec: '194C', name: 'Contractors / job work', rates: { P: 1, H: 1, def: 2 }, single: 30000, annual: 100000, acc: 'jobwork' },
    { sec: '194J', name: 'Professional / technical fees', rates: { def: 10 }, single: 50000, annual: 50000, acc: 'prof' },
    { sec: '194H', name: 'Commission / brokerage', rates: { def: 2 }, single: 20000, annual: 20000, acc: 'comm' },
    { sec: '194I', name: 'Rent (land, building, furniture)', rates: { def: 10 }, single: 0, annual: 600000, acc: 'rent' },
    { sec: '194Q', name: 'Purchase of goods above ₹50 lakh', rates: { def: 0.1 }, single: 0, annual: 5000000, acc: 'purch' },
    { sec: '194A', name: 'Interest (other than securities)', rates: { def: 10 }, single: 0, annual: 10000, acc: 'intexp' }
  ],
  tdsNote: 'Rates and thresholds as per my knowledge of FY 2025-26 (Finance Act 2025). Confirm for the current year; Live Law Watch can propose updates.',
  hsn: [['3901', 'Polymers of ethylene', 18], ['3902', 'Polymers of propylene', 18], ['3904', 'Polymers of vinyl chloride', 18], ['3923', 'Plastic packaging articles', 18], ['3206', 'Colour masterbatch', 18], ['7208', 'Flat-rolled steel', 18], ['8481', 'Valves and taps', 18], ['8537', 'Control panels', 18], ['9983', 'Other professional, technical services', 18], ['9987', 'Maintenance and repair services', 18], ['9973', 'Leasing or rental services', 18], ['9965', 'Goods transport services (GTA)', 5], ['9982', 'Legal and accounting services', 18], ['9985', 'Support services', 18], ['9954', 'Construction services', 18], ['9963', 'Accommodation, food and beverage services', 5], ['0713', 'Dried pulses', 0], ['1006', 'Rice', 0], ['2402', 'Cigarettes, tobacco products', 40], ['8703', 'Motor cars', 40]],
  blockedAcc: ['meals'],
  pf: { ceiling: 15000, ee: 12, er: 12, admin: 1 },
  esi: { ceiling: 21000, ee: 0.75, er: 3.25 },
  pt: {
    '24': { name: 'Gujarat', slabs: [[5999, 0], [8999, 80], [11999, 150], [Infinity, 200]] },
    '27': { name: 'Maharashtra', slabs: [[7500, 0], [10000, 175], [Infinity, 200]], feb: 300 },
    '29': { name: 'Karnataka', slabs: [[24999, 0], [Infinity, 200]] },
    '19': { name: 'West Bengal', slabs: [[10000, 0], [15000, 110], [25000, 130], [40000, 150], [Infinity, 200]] }
  },
  fa: { life: { pm: 15, fn: 10, it: 3, ve: 8, oe: 5, bl: 60 }, it: { pm: 0.15, fn: 0.10, it: 0.40, ve: 0.15, oe: 0.15, bl: 0.10 }, names: { pm: 'Plant & machinery', fn: 'Furniture & fittings', it: 'Computers', ve: 'Vehicles', oe: 'Office equipment', bl: 'Buildings' }, residual: 0.05, acc: { pm: 'ppe_pm', fn: 'ppe_fn', it: 'ppe_it' } },
  corpTax: 25.17,
  itSlabs: { new: [[400000, 0], [800000, .05], [1200000, .10], [1600000, .15], [2000000, .20], [2400000, .25], [Infinity, .30]], old: [[250000, 0], [500000, .05], [1000000, .20], [Infinity, .30]] },
  itNote: 'Slabs per Finance Act 2025 as known to me (new regime: rebate to ₹12 lakh income, standard deduction ₹75,000). Verify for the current tax year.',
  actMap: [['TDS provisions (192–194 series)', 'Section 393 (tables)'], ['Deduction for life insurance etc. (80C)', 'Section 123'], ['Concessional corporate tax (115BAA)', 'Section 200'], ['Default personal regime (115BAC)', 'Section 202'], ['Presumptive business income (44AD)', 'Section 58'], ['Tax audit (44AB)', 'Section 63'], ['Rebate for resident individuals (87A)', 'Section 156']],
  actMapNote: 'Indicative only. The Income-tax Act, 2025 replaces the 1961 Act from 1 April 2026 (use "tax year" instead of previous/assessment year). Always confirm against the CBDT correlation table before citing.'
});

/* ---------- Skins ---------- */
/* SKINS is generated by gen_skins.py (assets/skins.js) and inserted before this part */
function applyTheme() {
  const s = App.core?.settings || {}, skin = SKINS.find(x => x.id === s.skin) || SKINS[0], r = document.documentElement;
  let dark = skin.mode === 'dark' ? true : skin.mode === 'light' ? false : (s.theme === 'dark' || (s.theme !== 'light' && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches));
  r.dataset.skin = skin.id; r.dataset.theme = dark ? 'dark' : 'light';
}
const isDarkNow = () => document.documentElement.dataset.theme === 'dark';
Actions.theme = () => {
  const skin = SKINS.find(x => x.id === App.core.settings.skin) || SKINS[0];
  if (skin.mode !== 'auto') { UI.toast(skin.name + ' has a fixed look. Pick Ledger or Boardroom for light and dark.', 'info'); return; }
  App.core.settings.theme = isDarkNow() ? 'light' : 'dark'; applyTheme(); App.saveCore(); Router.render();
};
Actions['skin-set'] = id => { App.core.settings.skin = id; applyTheme(); App.saveCore(); Log.add('Appearance changed', 'Style: ' + id); if (App.route === 'settings' || App.route === 'dashboard') Router.render(); UI.toast('Style: ' + SKINS.find(s => s.id === id).name, 'good'); };
Actions['skin-next'] = () => { const i = SKINS.findIndex(x => x.id === (App.core.settings.skin || 'ledger')); Actions['skin-set'](SKINS[(i + 1) % SKINS.length].id); };

/* ---------- Chart of accounts ---------- */
const COA = [
  ['cash', 'Cash in Hand', 'Cash & bank', 'A', 'ca_cash'], ['bank', 'HDFC Bank – Current A/c', 'Cash & bank', 'A', 'ca_cash'],
  ['ppe_pm', 'Plant & Machinery (cost)', 'Fixed assets', 'A', 'nca_ppe'], ['ppe_fn', 'Furniture & Fixtures (cost)', 'Fixed assets', 'A', 'nca_ppe'], ['ppe_it', 'Computers (cost)', 'Fixed assets', 'A', 'nca_ppe'], ['accdep', 'Accumulated Depreciation', 'Fixed assets', 'A', 'nca_ppe'],
  ['deposit', 'Security Deposits', 'Deposits', 'A', 'nca_oth'], ['stock', 'Inventory (Stock-in-trade)', 'Inventory', 'A', 'ca_inv'], ['adv', 'Advances to Suppliers', 'Loans & advances', 'A', 'ca_loans'],
  ['gi_c', 'GST Input – CGST', 'Duties & taxes', 'A', 'ca_oth'], ['gi_s', 'GST Input – SGST', 'Duties & taxes', 'A', 'ca_oth'], ['gi_i', 'GST Input – IGST', 'Duties & taxes', 'A', 'ca_oth'],
  ['tds_r', 'TDS Receivable', 'Duties & taxes', 'A', 'ca_oth'], ['prepaid', 'Prepaid Expenses', 'Other current assets', 'A', 'ca_oth'], ['susp', 'Suspense A/c', 'Suspense', 'A', 'ca_oth'],
  ['cap', 'Share Capital', 'Capital', 'L', 'eq_cap'], ['res', 'Reserves & Surplus (opening)', 'Reserves', 'L', 'eq_res'],
  ['tl', 'Term Loan – SBI', 'Secured loans', 'L', 'ncl_borrow'], ['cc', 'Cash Credit – SBI', 'Secured loans', 'L', 'cl_borrow'],
  ['go_c', 'GST Output – CGST', 'Duties & taxes', 'L', 'cl_oth'], ['go_s', 'GST Output – SGST', 'Duties & taxes', 'L', 'cl_oth'], ['go_i', 'GST Output – IGST', 'Duties & taxes', 'L', 'cl_oth'],
  ['tds_p', 'TDS Payable', 'Duties & taxes', 'L', 'cl_oth'], ['pf_p', 'PF, ESI & PT Payable', 'Statutory dues', 'L', 'cl_oth'], ['sal_p', 'Salary Payable', 'Statutory dues', 'L', 'cl_oth'], ['exp_p', 'Outstanding Expenses', 'Provisions', 'L', 'cl_oth'],
  ['taxprov', 'Provision for Income Tax', 'Provisions', 'L', 'cl_prov'],
  ['sales', 'Sales – Domestic', 'Sales', 'I', 'rev_ops'], ['int_inc', 'Interest Income', 'Other income', 'I', 'rev_oth'],
  ['purch', 'Purchases – Raw Material', 'Direct expenses', 'E', 'exp_cogs'], ['chg_inv', 'Change in Inventories', 'Direct expenses', 'E', 'exp_inv'], ['jobwork', 'Job Work Charges', 'Direct expenses', 'E', 'exp_oth'], ['freight', 'Freight & Carriage', 'Indirect expenses', 'E', 'exp_oth'],
  ['sal', 'Salaries & Wages', 'Employee cost', 'E', 'exp_emp'], ['pf_e', 'Employer PF/ESI Contribution', 'Employee cost', 'E', 'exp_emp'],
  ['rent', 'Rent', 'Indirect expenses', 'E', 'exp_oth'], ['power', 'Power & Fuel', 'Indirect expenses', 'E', 'exp_oth'], ['prof', 'Professional Fees', 'Indirect expenses', 'E', 'exp_oth'], ['comm', 'Commission & Brokerage', 'Indirect expenses', 'E', 'exp_oth'],
  ['repair', 'Repairs & Maintenance', 'Indirect expenses', 'E', 'exp_oth'], ['office', 'Office Expenses', 'Indirect expenses', 'E', 'exp_oth'], ['travel', 'Travel & Conveyance', 'Indirect expenses', 'E', 'exp_oth'],
  ['meals', 'Meals & Entertainment', 'Indirect expenses', 'E', 'exp_oth'], ['ins', 'Insurance', 'Indirect expenses', 'E', 'exp_oth'], ['bankchg', 'Bank Charges', 'Indirect expenses', 'E', 'exp_oth'],
  ['intexp', 'Interest on Loans', 'Finance costs', 'E', 'exp_fin'], ['dep', 'Depreciation', 'Depreciation', 'E', 'exp_dep'], ['taxexp', 'Income Tax Expense', 'Tax', 'E', 'exp_tax']
];
const BS_STRUCT = {
  L: [['Shareholders’ funds', [['eq_cap', 'Share capital'], ['eq_res', 'Reserves and surplus']]], ['Non-current liabilities', [['ncl_borrow', 'Long-term borrowings'], ['ncl_prov', 'Long-term provisions']]], ['Current liabilities', [['cl_borrow', 'Short-term borrowings'], ['cl_pay', 'Trade payables'], ['cl_oth', 'Other current liabilities'], ['cl_prov', 'Short-term provisions']]]],
  A: [['Non-current assets', [['nca_ppe', 'Property, plant and equipment'], ['nca_oth', 'Other non-current assets']]], ['Current assets', [['ca_inv', 'Inventories'], ['ca_rec', 'Trade receivables'], ['ca_cash', 'Cash and cash equivalents'], ['ca_loans', 'Short-term loans and advances'], ['ca_oth', 'Other current assets']]]]
};
const VTYPES = { Journal: { pre: 'JV', mod: 'r2r', key: 'F7' }, Payment: { pre: 'PV', mod: 'r2r', key: 'F5' }, Receipt: { pre: 'RV', mod: 'r2r', key: 'F6' }, Contra: { pre: 'CV', mod: 'r2r', key: 'F4' }, Sales: { pre: 'SI', mod: 'o2c', key: 'F8' }, Purchase: { pre: 'PB', mod: 'p2p', key: 'F9' }, 'Credit Note': { pre: 'CN', mod: 'o2c' }, 'Debit Note': { pre: 'DN', mod: 'p2p' } };
const defaultControls = () => ({ mcEnabled: true, mcMin: 50000, aiReview: true, doa: { approver: 500000 }, splitLimit: 50000, lockDate: '', backdateDays: 7, cashLimit: 10000 });

/* ---------- Books store ---------- */
App.books = {};
const Books = {
  blank(co) {
    return { v: 1, seeded: false, accounts: COA.map(a => ({ id: a[0], name: a[1], group: a[2], nat: a[3], sch: a[4], op: 0, sys: true })), parties: [], vouchers: [], seq: {}, controls: defaultControls(),
      assets: [], employees: [], att: {}, items: [], moves: [], counts: {}, pos: [], quotes: [], corp: { caro: {}, rpt: [], lodr: {} }, bankStmt: null, bankDone: {}, tests: {}, defic: [], closes: {}, planted: [], gstr2b: null };
  },
  cur() { const id = App.company.id; return App.books[id] || (App.books[id] = this.blank(App.company)); },
  save() { Store.save('books_' + App.company.id, this.cur()); },
  async loadAll() { App.books = {}; for (const co of App.core.companies) { const b = await Store.load('books_' + co.id, null); if (b && b.v) App.books[co.id] = b; } },
  acc(id) { return this.cur().accounts.find(a => a.id === id); },
  accName(id) { return this.acc(id)?.name || id; },
  party(id) { return this.cur().parties.find(p => p.id === id); },
  nextNo(b, type, fy) { const k = type + fy; b.seq[k] = (b.seq[k] || 0) + 1; return VTYPES[type].pre + '/' + fyLabel(fy) + '/' + String(b.seq[k]).padStart(4, '0'); },
  vch(id) { return this.cur().vouchers.find(v => v.id === id); },
  amt(v) { return r2(sum(v.lines, l => l.dr || 0)); },
  posted() { return this.cur().vouchers.filter(v => v.status === 'posted'); },
  reseed() { const co = App.company, s = Lab.get(co).seed; App.books[co.id] = clone(s.books); this.save(); },
  bankBalance(to) { const m = Rep.agg('0000-01-01', to || '9999-12-31'); const f = id => { const a = this.acc(id), x = m[id] || { dr: 0, cr: 0 }; return (a.op || 0) + x.dr - x.cr; }; return { bank: f('bank'), cash: f('cash') }; }
};

/* ---------- Reports ---------- */
const Rep = {
  agg(from, to, accFilter) {
    const m = {};
    for (const v of Books.cur().vouchers) { if (v.status !== 'posted' || v.date < from || v.date > to) continue; for (const l of v.lines) { const x = m[l.acc] || (m[l.acc] = { dr: 0, cr: 0 }); x.dr += l.dr || 0; x.cr += l.cr || 0; } }
    return m;
  },
  trial(fy, asOn) {
    const b = Books.cur(), { from, to } = fyRange(fy); asOn = asOn || to;
    const pre = this.agg('0000-01-01', dayBefore(from)), per = this.agg(from, asOn); let ret = 0; const rows = [];
    b.accounts.forEach(a => {
      const p = pre[a.id] || { dr: 0, cr: 0 }, q = per[a.id] || { dr: 0, cr: 0 }, pl = a.nat === 'I' || a.nat === 'E';
      const open = pl ? 0 : (a.op || 0) + p.dr - p.cr; if (pl) ret += p.dr - p.cr;
      rows.push({ acc: a, open, dr: q.dr, cr: q.cr, close: open + q.dr - q.cr });
    });
    if (Math.abs(ret) > 0.004) rows.push({ acc: { id: '_ret', name: 'Profit & Loss A/c (brought forward)', group: 'Reserves', nat: 'L', sch: 'eq_res', virtual: true }, open: ret, dr: 0, cr: 0, close: ret });
    return rows.filter(r => Math.abs(r.open) > 0.004 || r.dr || r.cr);
  },
  pl(from, to) {
    const per = this.agg(from, to), b = Books.cur(), o = { rev_ops: 0, rev_oth: 0, exp_cogs: 0, exp_inv: 0, exp_emp: 0, exp_fin: 0, exp_dep: 0, exp_oth: 0, exp_tax: 0 }, det = {};
    b.accounts.forEach(a => {
      if (a.nat !== 'I' && a.nat !== 'E') return; const x = per[a.id]; if (!x) return;
      const v = a.nat === 'I' ? x.cr - x.dr : x.dr - x.cr; o[a.sch] += v; (det[a.sch] = det[a.sch] || []).push({ acc: a, v });
    });
    o.income = o.rev_ops + o.rev_oth; o.expense = o.exp_cogs + o.exp_inv + o.exp_emp + o.exp_fin + o.exp_dep + o.exp_oth; o.pbt = o.income - o.expense; o.pat = o.pbt - o.exp_tax; o.det = det;
    o.gross = o.rev_ops - o.exp_cogs - o.exp_inv; return o;
  },
  bucketsAt(date) {
    const m = this.agg('0000-01-01', date), bk = {}; let pl = 0;
    Books.cur().accounts.forEach(a => { const x = m[a.id] || { dr: 0, cr: 0 }; if (a.nat === 'I' || a.nat === 'E') { pl += x.dr - x.cr; return; } bk[a.sch] = (bk[a.sch] || 0) + (a.op || 0) + x.dr - x.cr; });
    bk._pl = pl; return bk;
  },
  bs(fy, asOn) {
    const { from, to } = fyRange(fy); asOn = asOn || to;
    const bk = this.bucketsAt(asOn), cur = this.pl(from, asOn), prior = this.bucketsAt(dayBefore(from))._pl;
    const val = k => k.startsWith('eq_') || k.startsWith('ncl_') || k.startsWith('cl_') ? -(bk[k] || 0) : (bk[k] || 0);
    const retained = -prior;                  // profit of earlier years (credit)
    const out = { L: [], A: [], asOn, retained, current: cur.pat };
    const get = k => { let v = val(k); if (k === 'eq_res') v = -(bk.eq_res || 0) + retained; return v; };
    ['L', 'A'].forEach(side => BS_STRUCT[side].forEach(([g, items]) => out[side].push({ g, items: items.map(([k, n]) => ({ k, n, v: get(k) })) })));
    const eq = out.L[0].items.find(i => i.k === 'eq_res'); eq.cur = cur.pat; eq.v += cur.pat;
    out.totL = sum(out.L, g => sum(g.items, i => i.v)); out.totA = sum(out.A, g => sum(g.items, i => i.v)); out.diff = r2(out.totA - out.totL);
    return out;
  },
  cf(fy) {
    const { from, to } = fyRange(fy), o = this.bucketsAt(dayBefore(from)), c = this.bucketsAt(to), d = k => (c[k] || 0) - (o[k] || 0), pl = this.pl(from, to);
    const wc = [['Trade receivables', -d('ca_rec')], ['Inventories', -d('ca_inv')], ['Loans, advances and other current assets', -d('ca_loans') - d('ca_oth')], ['Trade payables', -d('cl_pay')], ['Other current liabilities', -d('cl_oth')]];
    const taxPaid = pl.exp_tax + d('cl_prov');
    const opPre = pl.pbt + pl.exp_dep + pl.exp_fin - pl.rev_oth, cfo = opPre + sum(wc, x => x[1]) - taxPaid;
    const capex = -(d('nca_ppe') + pl.exp_dep), cfi = capex - d('nca_oth') + pl.rev_oth;
    const borrow = -(d('ncl_borrow') + d('cl_borrow')), capital = -(d('eq_cap') + d('eq_res')), cff = borrow + capital - pl.exp_fin;
    const open = o.ca_cash || 0, close = c.ca_cash || 0, net = cfo + cfi + cff;
    return { pl, wc, taxPaid, opPre, cfo, capex, other: -d('nca_oth'), intRec: pl.rev_oth, cfi, borrow, capital, finCost: pl.exp_fin, cff, net, open, close, diff: r2(open + net - close) };
  },
  monthly(fy) {
    const { from, to } = fyRange(fy), out = {}, t = isoToday();
    for (const v of Books.cur().vouchers) { if (v.status !== 'posted' || v.date < from || v.date > to) continue; const k = monthKey(v.date); const o = out[k] || (out[k] = { k, rev: 0, exp: 0 }); for (const l of v.lines) { const a = Books.acc(l.acc); if (!a) continue; if (a.nat === 'I') o.rev += (l.cr || 0) - (l.dr || 0); else if (a.nat === 'E' && a.sch !== 'exp_tax') o.exp += (l.dr || 0) - (l.cr || 0); } }
    return Object.values(out).sort((a, b) => a.k.localeCompare(b.k)).map(o => ({ ...o, label: monthLabel(o.k), profit: o.rev - o.exp }));
  },
  ledger(accId, from, to) {
    const a = Books.acc(accId); if (!a) return null; const pl = a.nat === 'I' || a.nat === 'E';
    const pre = this.agg('0000-01-01', dayBefore(from))[accId] || { dr: 0, cr: 0 };
    let bal = pl ? 0 : (a.op || 0) + pre.dr - pre.cr; const open = bal, rows = []; let tdr = 0, tcr = 0;
    const vs = Books.posted().filter(v => v.date >= from && v.date <= to && v.lines.some(l => l.acc === accId)).sort((x, y) => x.date.localeCompare(y.date) || x.createdAt.localeCompare(y.createdAt));
    vs.forEach(v => v.lines.filter(l => l.acc === accId).forEach(l => { bal += (l.dr || 0) - (l.cr || 0); tdr += l.dr || 0; tcr += l.cr || 0; const opp = v.lines.filter(x => x.acc !== accId).map(x => Books.accName(x.acc)); rows.push({ v, dr: l.dr || 0, cr: l.cr || 0, bal, opp: opp.length > 1 ? opp[0] + ' +' + (opp.length - 1) : opp[0] || '' }); }));
    return { a, open, rows, tdr, tcr, close: bal };
  },
  ratios(fy) {
    const { from, to } = fyRange(fy), bk = this.bucketsAt(to), pl = this.pl(from, to), g = k => bk[k] || 0, L = k => -(bk[k] || 0);
    const ca = g('ca_inv') + g('ca_rec') + g('ca_cash') + g('ca_loans') + g('ca_oth'), cl = L('cl_borrow') + L('cl_pay') + L('cl_oth') + L('cl_prov'), eq = L('eq_cap') + L('eq_res') - bk._pl, debt = L('ncl_borrow') + L('cl_borrow');
    const months = Math.max(1, Math.min(12, (dparse(isoToday()) - dparse(from)) / DAY / 30.4)), ann = k => pl[k] / months * 12, revA = ann('rev_ops'), cogsA = (pl.exp_cogs + pl.exp_inv) / months * 12;
    const ebit = pl.pbt + pl.exp_fin, ebitda = ebit + pl.exp_dep, ta = ca + g('nca_ppe') + g('nca_oth');
    const dz = (a, b) => b ? a / b : null, R = [];
    const add = (grp, name, v, fmt, bench, good) => R.push({ grp, name, v, fmt, bench, flag: v == null ? 'na' : good(v) ? 'ok' : 'bad' });
    add('Liquidity', 'Current ratio', dz(ca, cl), 'x', '1.2 to 2.0', v => v >= 1.2); add('Liquidity', 'Quick ratio', dz(ca - g('ca_inv'), cl), 'x', '≥ 1.0', v => v >= 1);
    add('Liquidity', 'Cash ratio', dz(g('ca_cash'), cl), 'x', '≥ 0.2', v => v >= .2); add('Liquidity', 'Working capital', ca - cl, '₹', 'Positive', v => v > 0);
    add('Leverage', 'Debt to equity', dz(debt, eq), 'x', '≤ 1.5', v => v <= 1.5); add('Leverage', 'Interest cover (EBIT / interest)', dz(ebit, pl.exp_fin), 'x', '≥ 3', v => v >= 3);
    add('Leverage', 'Total liabilities to equity', dz(cl + L('ncl_borrow') + L('ncl_prov'), eq), 'x', '≤ 2.5', v => v <= 2.5); add('Leverage', 'Equity ratio', dz(eq, ta) == null ? null : eq / ta * 100, '%', '≥ 30%', v => v >= 30);
    add('Profitability', 'Gross margin', dz(pl.gross, pl.rev_ops) == null ? null : pl.gross / pl.rev_ops * 100, '%', '≥ 20%', v => v >= 20); add('Profitability', 'EBITDA margin', dz(ebitda, pl.rev_ops) == null ? null : ebitda / pl.rev_ops * 100, '%', '≥ 10%', v => v >= 10);
    add('Profitability', 'Net margin', dz(pl.pat, pl.rev_ops) == null ? null : pl.pat / pl.rev_ops * 100, '%', '≥ 5%', v => v >= 5); add('Profitability', 'Return on equity (annualised)', dz(ann('pat'), eq) == null ? null : ann('pat') / eq * 100, '%', '≥ 12%', v => v >= 12);
    add('Profitability', 'Return on capital employed (annualised)', dz(ebit / months * 12, eq + debt) == null ? null : ebit / months * 12 / (eq + debt) * 100, '%', '≥ 12%', v => v >= 12);
    add('Efficiency', 'Receivable days (DSO)', dz(g('ca_rec'), revA) == null ? null : g('ca_rec') / revA * 365, 'days', '≤ 60', v => v <= 60); add('Efficiency', 'Payable days (DPO)', dz(L('cl_pay'), cogsA) == null ? null : L('cl_pay') / cogsA * 365, 'days', '≤ 60', v => v <= 60);
    add('Efficiency', 'Inventory days', dz(g('ca_inv'), cogsA) == null ? null : g('ca_inv') / cogsA * 365, 'days', '≤ 60', v => v <= 60); add('Efficiency', 'Asset turnover', dz(revA, ta), 'x', '≥ 1.0', v => v >= 1);
    add('Efficiency', 'Fixed asset turnover', dz(revA, g('nca_ppe')), 'x', '≥ 2.0', v => v >= 2); add('Efficiency', 'Employee cost to revenue', dz(pl.exp_emp, pl.rev_ops) == null ? null : pl.exp_emp / pl.rev_ops * 100, '%', '≤ 25%', v => v <= 25);
    add('Efficiency', 'Cash conversion cycle', (dz(g('ca_rec'), revA) == null || dz(g('ca_inv'), cogsA) == null) ? null : g('ca_rec') / revA * 365 + g('ca_inv') / cogsA * 365 - L('cl_pay') / (cogsA || 1) * 365, 'days', '≤ 90', v => v <= 90);
    add('Efficiency', 'Other expenses to revenue', dz(pl.exp_oth, pl.rev_ops) == null ? null : pl.exp_oth / pl.rev_ops * 100, '%', '≤ 20%', v => v <= 20);
    return R;
  },
  summary(fy) {
    const { from, to } = fyRange(fy), pl = this.pl(from, to), mo = this.monthly(fy), bb = Books.bankBalance(), ag = AR.ageing('C'), pg = AR.ageing('V');
    const last = mo[mo.length - 1], prev = mo[mo.length - 2];
    let drivers = []; if (last && prev) { const a = this.agg(last.k + '-01', last.k + '-31'), p = this.agg(prev.k + '-01', prev.k + '-31'); Books.cur().accounts.filter(x => x.nat === 'I' || x.nat === 'E').forEach(x => { const f = m => { const y = m[x.id] || { dr: 0, cr: 0 }; return x.nat === 'I' ? y.cr - y.dr : y.dr - y.cr; }; const dlt = f(a) - f(p); if (Math.abs(dlt) > 1) drivers.push({ acc: x.id, name: x.name, nat: x.nat, change: Math.round(dlt) }); }); drivers.sort((x, y) => Math.abs(y.change) - Math.abs(x.change)); drivers = drivers.slice(0, 6); }
    const exp = Object.entries(pl.det).filter(([k]) => k.startsWith('exp_') && k !== 'exp_tax').flatMap(([, v]) => v).sort((x, y) => y.v - x.v).slice(0, 6).map(x => ({ acc: x.acc.id, name: x.acc.name, amount: Math.round(x.v) }));
    return { fy: fyLabel(fy), ytd: { revenue: Math.round(pl.rev_ops), otherIncome: Math.round(pl.rev_oth), expenses: Math.round(pl.expense), profitBeforeTax: Math.round(pl.pbt) }, months: mo.map(m => ({ m: m.label, rev: Math.round(m.rev), exp: Math.round(m.exp), profit: Math.round(m.profit) })), cash: { bank: Math.round(bb.bank), cashInHand: Math.round(bb.cash) }, receivables: { total: Math.round(ag.total), overdue: Math.round(ag.overdue), top: ag.rows.slice(0, 5).map(r => ({ id: r.p.id, name: r.p.name, open: Math.round(r.open), overdue: Math.round(r.overdue) })) }, payables: { total: Math.round(pg.total), overdue: Math.round(pg.overdue), top: pg.rows.slice(0, 4).map(r => ({ id: r.p.id, name: r.p.name, open: Math.round(r.open) })) }, lastMonthChangeDrivers: drivers, topExpenses: exp, pendingApprovals: Books.cur().vouchers.filter(v => v.status === 'pending').length };
  }
};
const fyNow = () => App.session.fy || fyStartOf();

/* ---------- Ageing (FIFO) ---------- */
const AR = {
  bills(kind, asOn) {
    const b = Books.cur(), isC = kind === 'C', out = {};
    const ps = b.parties.filter(p => p.kind === kind); ps.forEach(p => out[p.id] = { p, bills: [], settle: [] });
    b.vouchers.filter(v => v.status === 'posted').sort((x, y) => x.date.localeCompare(y.date) || x.createdAt.localeCompare(y.createdAt)).forEach(v => v.lines.forEach(l => {
      const o = out[l.acc]; if (!o || v.date > asOn) return;
      const bill = isC ? (l.dr > 0 && v.type === 'Sales') : (l.cr > 0 && v.type === 'Purchase');
      if (bill) { const amt = isC ? l.dr : l.cr; const terms = o.p.terms || 30; o.bills.push({ v, date: v.date, due: v.meta?.due || iso(addD(dparse(v.date), terms)), amt, open: amt, paidOn: null }); }
      else { const amt = isC ? (l.cr || 0) - (l.dr || 0) : (l.dr || 0) - (l.cr || 0); if (Math.abs(amt) > 0.004) o.settle.push({ date: v.date, amt }); }
    }));
    return out;
  },
  ageing(kind, asOn) {
    asOn = asOn || isoToday(); const all = this.bills(kind, asOn), rows = []; let total = 0, overdue = 0; const bk = ['notdue', 'd30', 'd60', 'd90', 'd180', 'd180p'];
    Object.values(all).forEach(o => {
      let wDays = 0, wAmt = 0;
      o.settle.forEach(s => { let rem = s.amt; if (rem <= 0) { return; } for (const bl of o.bills) { if (rem <= 0.004) break; if (bl.open <= 0.004) continue; const t = Math.min(rem, bl.open); bl.open -= t; rem -= t; wDays += t * daysBetween(bl.date, s.date); wAmt += t; if (bl.open <= 0.004) bl.paidOn = s.date; } });
      const open = sum(o.bills, x => x.open); if (open <= 0.5) return;
      const b = {}; bk.forEach(k => b[k] = 0); let od = 0, oldest = 0;
      o.bills.forEach(bl => { if (bl.open <= 0.004) return; const dd = daysBetween(bl.due, asOn); const k = dd <= 0 ? 'notdue' : dd <= 30 ? 'd30' : dd <= 60 ? 'd60' : dd <= 90 ? 'd90' : dd <= 180 ? 'd180' : 'd180p'; b[k] += bl.open; if (dd > 0) od += bl.open; oldest = Math.max(oldest, daysBetween(bl.date, asOn)); bl.od = dd; });
      rows.push({ p: o.p, open, overdue: od, b, bills: o.bills.filter(x => x.open > 0.004), avgPay: wAmt ? wDays / wAmt : null, oldest }); total += open; overdue += od;
    });
    rows.sort((x, y) => y.open - x.open); return { rows, total, overdue, bk };
  },
  risk() {
    const ag = this.ageing('C'), tot = ag.total || 1;
    return ag.rows.map(r => {
      const lim = r.p.limit || 0, util = lim ? r.open / lim : (r.open > 0 ? 2 : 0), terms = r.p.terms || 30, delay = r.avgPay == null ? 0 : Math.max(0, r.avgPay - terms);
      const s1 = r.overdue / r.open * 35, s2 = (r.b.d90 + r.b.d180 + r.b.d180p) / r.open * 25, s3 = Math.min(1, util) * 15 + (util > 1 ? 0 : 0), s4 = Math.min(60, delay) / 60 * 15, s5 = Math.min(1, r.open / tot * 3) * 10;
      const score = Math.round(Math.min(100, s1 + s2 + s3 + s4 + s5)), level = score < 25 ? 'Low' : score < 50 ? 'Medium' : score < 75 ? 'High' : 'Critical';
      const action = level === 'Critical' ? 'Stop supplies, escalate to director, issue legal notice' : level === 'High' ? 'Call the customer this week and fix a payment date' : level === 'Medium' ? 'Send a written reminder and follow up in 7 days' : 'Routine reminder on due date';
      return { ...r, score, level, util, delay, action, lim };
    }).sort((a, b) => b.score - a.score);
  }
};

/* ---------- Income tax, payroll, assets ---------- */
const IncomeTax = {
  slabTax(inc, regime) { let prev = 0, t = 0; for (const [lim, rate] of CONFIG.itSlabs[regime]) { if (inc > prev) t += (Math.min(inc, lim) - prev) * rate; prev = lim; } return t; },
  compute(o) {
    const regime = o.regime || 'new', gross = o.gross || 0; let ded = 0, taxable;
    if (regime === 'new') { ded = (o.std === false ? 0 : 75000) + Math.min(o.nps || 0, gross * .14); taxable = Math.max(0, gross - ded); }
    else { const c80 = Math.min(o.c80 || 0, 150000), d80 = Math.min(o.d80 || 0, 100000), npsx = Math.min(o.nps || 0, 50000), hl = Math.min(o.homeLoan || 0, 200000); ded = (o.std === false ? 0 : 50000) + c80 + d80 + npsx + hl + (o.hra || 0) + (o.other || 0); taxable = Math.max(0, gross - ded); }
    let tax = this.slabTax(taxable, regime), rebate = 0;
    if (regime === 'new') { if (taxable <= 1200000) { rebate = tax; } else if (tax > taxable - 1200000) { rebate = tax - (taxable - 1200000); } }
    else if (taxable <= 500000) rebate = Math.min(tax, 12500);
    tax -= rebate; let sur = 0; const sr = taxable > 20000000 ? (regime === 'new' ? .25 : (taxable > 50000000 ? .37 : .25)) : taxable > 10000000 ? .15 : taxable > 5000000 ? .10 : 0; sur = tax * sr;
    const cess = (tax + sur) * .04, total = Math.round(tax + sur + cess);
    return { regime, gross, ded, taxable, slabTax: this.slabTax(taxable, regime), rebate, surcharge: sur, cess, total };
  }
};
const Payroll = {
  grossFor(e, ym) { return e.revFrom && ym >= e.revFrom ? e.revGross : e.gross; },
  pt(sc, g, mo) { const t = CONFIG.pt[sc]; if (!t) return 0; let a = 0; for (const [u, x] of t.slabs) { if (g <= u) { a = x; break; } } if (t.feb && mo === 2 && a > 0) a = t.feb; return a; },
  calc(e, ym, days, stateCode) {
    const dim = daysInMonth(ym), d = days == null ? dim : days, g0 = this.grossFor(e, ym), g = r2(g0 * d / dim);
    const basic = r2(g * (e.basicPct || 50) / 100), hra = r2(g * .2), other = r2(g - basic - hra), pfw = e.pfActual ? basic : Math.min(basic, CONFIG.pf.ceiling);
    const ee = r2(pfw * CONFIG.pf.ee / 100), er = r2(pfw * CONFIG.pf.er / 100), adm = r2(pfw * CONFIG.pf.admin / 100);
    const yr = +ym.slice(0, 4), mo = +ym.slice(5, 7), ps = mo >= 4 && mo <= 9 ? yr + '-04' : (mo >= 10 ? yr + '-10' : (yr - 1) + '-10'), esiEl = this.grossFor(e, ps) <= CONFIG.esi.ceiling;
    const esiEE = esiEl ? Math.ceil(g * CONFIG.esi.ee / 100) : 0, esiER = esiEl ? Math.ceil(g * CONFIG.esi.er / 100) : 0, pt = this.pt(stateCode, g, mo);
    const tds = r2(IncomeTax.compute({ gross: g0 * 12, regime: e.regime || 'new' }).total / 12), net = r2(g - ee - esiEE - pt - tds);
    return { e, ym, days: d, dim, g, basic, hra, other, pfw, ee, er, adm, esiEL: esiEl, esiEE, esiER, pt, tds, net, ctc: r2(g + er + adm + esiER) };
  },
  run(ym, bk, st) {
    const b = bk || Books.cur(), sc = st || App.company.state, mEnd = ym + '-' + String(daysInMonth(ym)).padStart(2, '0');
    const rows = b.employees.filter(e => e.doj <= mEnd && !e.left).map(e => this.calc(e, ym, b.att?.[ym]?.[e.id], sc));
    const t = k => r2(sum(rows, r => r[k])); return { ym, rows, gross: t('g'), ee: t('ee'), er: t('er'), adm: t('adm'), esiEE: t('esiEE'), esiER: t('esiER'), pt: t('pt'), tds: t('tds'), net: t('net') };
  }
};
const FA = {
  annual(a) { return a.cost * (1 - CONFIG.fa.residual) / CONFIG.fa.life[a.cls]; },
  dep(a, from, to) { const s = a.use > from ? a.use : from, e = a.sold && a.sold < to ? a.sold : to; const d = daysBetween(s, e) + 1; return d > 0 ? r2(this.annual(a) * d / 365) : 0; },
  accum(a, upTo) { const d = daysBetween(a.use, upTo) + 1; return d > 0 ? Math.min(r2(a.cost * (1 - CONFIG.fa.residual)), r2(this.annual(a) * d / 365)) : 0; },
  itBlocks(fy) {
    const { from, to } = fyRange(fy), assets = Books.cur().assets, out = [];
    Object.keys(CONFIG.fa.it).forEach(cls => {
      const A = assets.filter(a => a.cls === cls); if (!A.length) return; const rate = CONFIG.fa.it[cls];
      const old = A.filter(a => a.use < from), neu = A.filter(a => a.use >= from && a.use <= to);
      const opening = sum(old, a => a.cost * Math.pow(1 - rate, Math.max(0, fyOfDate(from) - fyOfDate(a.use) - 1) + 0) * (1 - rate) ** 0);
      const open = sum(old, a => { const yrs = fy - fyOfDate(a.use); return a.cost * Math.pow(1 - rate, Math.max(0, yrs)); });
      const full = sum(neu.filter(a => daysBetween(a.use, to) + 1 >= 180), a => a.cost), half = sum(neu.filter(a => daysBetween(a.use, to) + 1 < 180), a => a.cost);
      const dep = r2(rate * open + rate * full + rate / 2 * half); out.push({ cls, name: CONFIG.fa.names[cls], rate, open: r2(open), add: r2(full + half), full, half, dep, close: r2(open + full + half - dep) });
    }); return out;
  }
};

/* ---------- Seed data generator (one full year, planted issues) ---------- */
const Seed = {
  build(co, V, C) {
    const R = rng('books-' + co.id), scale = profileOf(co).scale, fy = co.fyStart || fyStartOf(), T = today0(), fyEnd = new Date(fy + 1, 2, 31), end = T < fyEnd ? T : fyEnd, endS = iso(end);
    const b = Books.blank(co); b.seeded = true;
    const pick = a => a[Math.floor(R() * a.length)], rnd = (a, z) => a + R() * (z - a), P = t => b.planted.push(t), coState = co.state;
    const force = { 1: '194J', 2: '194C', 4: '194C', 7: '194J' }; Object.entries(force).forEach(([i, s]) => { V.rows[i]['TDS Section'] = s; });
    V.rows.forEach(r => b.parties.push({ id: r['Vendor Code'], kind: 'V', name: r['Vendor Name'], gstin: r['GSTIN'], pan: r['PAN'], state: r['State'], constitution: r['Constitution'], msme: r['MSME Status'], udyam: r['Udyam No'], bank: r['Bank Name'], ifsc: r['IFSC'], acct: r['Bank Account'], terms: +r['Payment Terms (days)'], tds: r['TDS Section'], email: r['Email'], phone: r['Phone'], active: true }));
    C.rows.forEach(r => b.parties.push({ id: r['Customer Code'], kind: 'C', name: r['Customer Name'], gstin: r['GSTIN'], pan: r['PAN'], state: r['State'], limit: +r['Credit Limit'], terms: +r['Credit Days'], email: r['Email'], active: true }));
    b.parties.forEach(p => b.accounts.push({ id: p.id, name: p.name, group: p.kind === 'V' ? 'Sundry Creditors' : 'Sundry Debtors', nat: p.kind === 'V' ? 'L' : 'A', sch: p.kind === 'V' ? 'cl_pay' : 'ca_rec', op: 0, party: true }));
    const party = id => b.parties.find(p => p.id === id); party('V028').active = false;
    const stCode = p => (/^\d{2}/.test(p.gstin || '') ? p.gstin.slice(0, 2) : (CONFIG.states.find(s => s[1] === p.state) || ['24'])[0]);
    const split = (t, rate, intra) => intra ? { c: r2(t * rate / 200), s: r2(t * rate / 200), i: 0 } : { c: 0, s: 0, i: r2(t * rate / 100) };
    const nm = p => p.name.toUpperCase().replace(/[^A-Z0-9 ]/g, '').slice(0, 22);
    // people, assets, stock
    const wts = [2.2, 1.6, 1.3, 1.1, 0.9, 0.8], target = scale * 0.15; const names = NAMES.people;
    b.employees = wts.map((w, i) => ({ id: 'E' + String(i + 1).padStart(3, '0'), name: names[i], desig: ['Plant head', 'Sales manager', 'Accounts manager', 'Production supervisor', 'Quality chemist', 'Stores executive'][i], doj: (fy - 3 + (i % 3)) + '-0' + (1 + i) + '-10', gross: Math.max(25000, Math.round(target * w / 7.9 / 100) * 100), basicPct: 50, pan: 'ABCPX' + (1000 + i * 37) + 'K', uan: '1012' + (30000000 + i * 7919), regime: i % 2 ? 'old' : 'new' }));
    b.employees.push({ id: 'E007', name: 'Harpreet Kaur', desig: 'Machine operator', doj: (fy - 1) + '-07-01', gross: 18500, basicPct: 50, pan: 'ABCPK2233L', uan: '101298765432', regime: 'new' });
    b.employees.push({ id: 'E008', name: 'Arjun Nair', desig: 'Helper', doj: (fy - 1) + '-11-15', gross: 20500, basicPct: 50, revFrom: fy + '-07', revGross: 22800, pan: 'ABCPN9911M', uan: '101255555111', regime: 'new' });
    const rt = x => Math.round(x / 1000) * 1000;
    b.assets = [{ id: 'FA001', name: 'CNC Moulding Machine', cls: 'pm', cost: rt(scale * 1.2), use: (fy - 3) + '-06-15', loc: 'Plant 1' }, { id: 'FA002', name: 'Extruder Line', cls: 'pm', cost: rt(scale * .3), use: (fy - 1) + '-10-01', loc: 'Plant 1' }, { id: 'FA003', name: 'Office Furniture', cls: 'fn', cost: rt(scale * .06), use: (fy - 2) + '-04-10', loc: 'Head office' }, { id: 'FA004', name: 'Laptops & Desktops', cls: 'it', cost: rt(scale * .05), use: (fy - 1) + '-08-20', loc: 'Head office' }];
    const add1 = { id: 'FA005', name: 'Cooling Tower (new)', cls: 'pm', cost: rt(scale * .25), use: fy + '-06-24', loc: 'Plant 1' }, add2 = { id: 'FA006', name: 'Server & Network', cls: 'it', cost: rt(scale * .03), use: fy + '-09-28', loc: 'Head office' };
    if (add1.use <= endS) b.assets.push(add1); if (add2.use <= endS) b.assets.push(add2);
    b.items = [['RM01', 'HDPE granules', '3901', 'kg', 5000, 40000, 92], ['RM02', 'PP copolymer', '3902', 'kg', 4000, 30000, 98], ['RM03', 'Masterbatch (blue)', '3206', 'kg', 800, 6000, 210], ['RM04', 'Packaging film', '3923', 'kg', 1000, 9000, 150], ['FG01', 'Moulded crates (FG)', '3923', 'nos', 500, 3000, 310]].map(x => ({ id: x[0], name: x[1], hsn: x[2], unit: x[3], reorder: x[4], opQty: x[5], opRate: x[6], expiry: x[0] === 'RM03' ? (fy) + '-05-31' : '' }));
    b.moves = []; const mvMonths = []; for (let m = new Date(fy, 3, 1); m <= end; m = new Date(m.getFullYear(), m.getMonth() + 1, 1)) mvMonths.push(new Date(m));
    b.items.forEach((it, ii) => mvMonths.forEach((m, mi) => { const r1 = it.opRate * (1 + (mi * .012) + (R() - .5) * .06); b.moves.push({ date: iso(new Date(m.getFullYear(), m.getMonth(), 6)), item: it.id, type: 'IN', qty: Math.round(it.opQty * rnd(.35, .5)), rate: r2(r1) }); b.moves.push({ date: iso(new Date(m.getFullYear(), m.getMonth(), 20)), item: it.id, type: 'OUT', qty: Math.round(it.opQty * rnd(.38, .52)), rate: 0 }); }));
    b.counts = {}; const stockVal = () => 0;
    // opening balances
    const setOp = (id, v) => { b.accounts.find(a => a.id === id).op = r2(v); };
    const costOpen = c => sum(b.assets.filter(a => a.cls === c && a.use < fy + '-04-01'), a => a.cost);
    setOp('bank', rt(scale * 1.3)); setOp('ppe_pm', costOpen('pm')); setOp('ppe_fn', costOpen('fn')); setOp('ppe_it', costOpen('it'));
    setOp('accdep', -sum(b.assets.filter(a => a.use < fy + '-04-01'), a => FA.accum(a, (fy) + '-03-31')));
    setOp('stock', sum(b.items, i => i.opQty * i.opRate)); setOp('deposit', rt(scale * .05)); setOp('tl', -rt(scale * 1.0)); setOp('cap', -rt(scale * 1.5));
    setOp('res', -sum(b.accounts, a => a.op || 0));
    const list = []; let hrSeed = 0;
    const stamp = (d, hr, mi) => { const x = new Date(d); x.setHours(hr == null ? 10 + Math.floor(R() * 8) : hr, mi == null ? Math.floor(R() * 60) : mi, Math.floor(R() * 60)); return x.toISOString(); };
    const mk = (type, date, lines, narr, o = {}) => { if (!o.wk) { const dw = date.getDay(); if (dw === 6) date = addD(date, -1); else if (dw === 0) date = addD(date, -2); } const v = { id: uid('v'), no: '', type, date: iso(date), narr, lines: lines.map(l => ({ acc: l[0], dr: r2(l[1] || 0), cr: r2(l[2] || 0) })).filter(l => l.dr || l.cr), status: o.status || 'posted', maker: o.maker || 'Amit Patel', checker: o.status === 'pending' || o.status === 'rejected' ? (o.status === 'rejected' ? 'Neha Mehta' : null) : (o.checker === undefined ? 'Neha Mehta' : o.checker), ai: !!o.ai, createdAt: o.created || stamp(date, o.hour, o.min), meta: o.meta || {}, ref: o.ref || '', _bn: o.bn || null, _bd: o.bd == null ? 0 : o.bd }; if (v.checker) v.checkedAt = v.createdAt; list.push(v); return v; };
    const months = []; for (let m = new Date(fy, 3, 1); m <= end; m = new Date(m.getFullYear(), m.getMonth() + 1, 1)) months.push(new Date(m));
    const ld = m => new Date(m.getFullYear(), m.getMonth() + 1, 0).getDate(), D = (m, d) => new Date(m.getFullYear(), m.getMonth(), Math.min(d, ld(m)));
    const mi = n => Math.min(n, months.length - 1), ref = () => String(Math.floor(1e11 + R() * 9e11));
    const sec = p => p.tds, secAcc = { '194C': 'jobwork', '194J': 'prof', '194H': 'comm', '194I': 'rent', '194Q': 'purch', None: 'purch' }, tdsThr = { '194C': 30000, '194J': 50000, '194H': 20000, '194I': 50000 };
    const tdsRate = (s, pan) => { if (s === 'None' || s === '194Q' || !s) return 0; if (!GST.validPAN(pan)) return 20; const t = CONFIG.tds.find(x => x.sec === s); return t ? (t.rates[pan[3]] ?? t.rates.def) : 0; };
    const skipTds = new Set(['V002', 'V003']);
    const invs = [], bills = []; let hsnNo = 0;
    const slow = ['C005', 'C012'], custs = b.parties.filter(p => p.kind === 'C'), vpool = b.parties.filter(p => p.kind === 'V' && !['V028', 'V007', 'V019', 'V026'].includes(p.id));
    const mkSale = (c, date, gross, o = {}) => {
      const taxable = r2(gross / 1.18), intra = stCode(c) === coState, g = split(taxable, 18, intra), total = r2(taxable + g.c + g.s + g.i), qty = Math.max(1, Math.round(taxable / rnd(90, 140)));
      const lines = [[c.id, total, 0], ['sales', 0, taxable]]; if (g.c) { lines.push(['go_c', 0, g.c], ['go_s', 0, g.s]); } if (g.i) lines.push(['go_i', 0, g.i]);
      const v = mk('Sales', date, lines, 'Sale of goods to ' + c.name, { maker: o.maker, checker: o.checker, hour: o.hour, meta: { party: c.id, taxable, cgst: g.c, sgst: g.s, igst: g.i, rate: 18, total, pos: stCode(c), due: iso(addD(date, c.terms || 30)), items: [{ desc: pick(['HDPE granules', 'PP copolymer', 'Moulded crates', 'Masterbatch', 'Packaging film']), hsn: '3901', qty, rate: r2(taxable / qty), gst: 18 }] } });
      invs.push({ v, c, date, total }); return v;
    };
    months.forEach((m, k) => {
      for (let i = 0; i < 6; i++) { let c = pick(custs); if (i === 0 && R() < .55) c = party(pick(slow)); const date = D(m, 1 + Math.floor(R() * 26)); if (date > end) continue; mkSale(c, date, scale * rnd(.11, .24)); }
      for (let i = 0; i < 7; i++) {
        const v = pick(vpool), date = D(m, 1 + Math.floor(R() * 27)); if (date > end) continue; this.purchase(b, mk, v, date, scale * rnd(.075, .125), { stCode, split, secAcc, tdsThr, tdsRate, skipTds, coState, pick, rnd, R, bills });
      }
    });
    // planted purchases
    const pm = months[mi(2)];
    if (pm) { const dv = party('V011'), amt = scale * .05; const b1 = this.purchase(b, mk, dv, D(pm, 8), amt, { stCode, split, secAcc, tdsThr, tdsRate, skipTds, coState, pick, rnd, R, bills, billNo: 'INV-2231', exact: true }); const b2 = this.purchase(b, mk, dv, D(pm, 10), amt, { stCode, split, secAcc, tdsThr, tdsRate, skipTds, coState, pick, rnd, R, bills, billNo: 'INV 2231', exact: true }); P('Duplicate bill and payment: V011 invoice INV-2231 entered twice (as "INV 2231") and paid twice.'); }
    const sm = months[mi(4)]; if (sm) { for (let i = 0; i < 4; i++) this.purchase(b, mk, party('V015'), D(sm, 6 + i), 49200 + i * 230, { stCode, split, secAcc, tdsThr, tdsRate, skipTds: new Set(['V015']), coState, pick, rnd, R, bills, exact: true, noPay: i < 3 }); P('Split purchases: four bills of about ₹49,000 from V015 within 4 days, just under the ₹50,000 approval limit.'); }
    if (add1.use <= endS) { const ad = this.purchase(b, mk, party('V006'), new Date(add1.use + 'T00:00:00'), add1.cost * 1.18, { stCode, split, secAcc, tdsThr, tdsRate, skipTds, coState, pick, rnd, R, bills, capital: 'ppe_pm', exact: true, narr: 'Purchase of ' + add1.name }); }
    if (add2.use <= endS) this.purchase(b, mk, party('V009'), new Date(add2.use + 'T00:00:00'), add2.cost * 1.18, { stCode, split, secAcc, tdsThr, tdsRate, skipTds, coState, pick, rnd, R, bills, capital: 'ppe_it', exact: true, narr: 'Purchase of ' + add2.name });
    // receipts
    invs.forEach(iv => {
      const slowC = slow.includes(iv.c.id), terms = iv.c.terms || 30;
      if (iv.c.id === 'C012' && iv.date < new Date(fy, 6, 1)) return; // old dues never paid
      if (R() > (slowC ? .5 : .9)) return;
      const delay = slowC ? Math.round(rnd(70, 125)) : Math.round(terms + rnd(-6, 16)), pd = addD(iv.date, delay); if (pd > end) return;
      mk('Receipt', pd, [['bank', iv.total, 0], [iv.c.id, 0, iv.total]], 'Receipt from ' + iv.c.name + ' against ' + iv.v.no, { bd: Math.round(R()), bn: 'NEFT CR-' + pick(['HDFC0000', 'SBIN0001', 'ICIC0002', 'UTIB0003']) + '-' + nm(iv.c) + '-' + iv.c.id, meta: { party: iv.c.id } });
    });
    // payments to vendors
    bills.forEach(bl => {
      if (bl.noPay || bl.v.meta.noPay) return; if (R() > .82 && !bl.force) return; const p = party(bl.v.meta.party), msmeLate = (p.msme === 'Micro' || p.msme === 'Small') && R() < .6;
      const delay = (p.terms || 30) + Math.round(rnd(0, 10)) + (msmeLate ? 12 : 0), pd = addD(dparse(bl.v.date), delay); if (pd > end) return;
      const amt = bl.net; mk('Payment', pd, [[p.id, amt, 0], ['bank', 0, amt]], 'Payment to ' + p.name + ' against bill ' + (bl.v.meta.billNo || bl.v.no), { bd: Math.round(R() * 2), bn: 'NEFT DR-' + p.ifsc + '-' + nm(p) + '-' + (bl.v.meta.billNo && /2231/.test(bl.v.meta.billNo) ? 'INV ' + bl.v.meta.billNo.replace(/\D/g, '') : p.id), meta: { party: p.id } });
    });
    // recurring
    let cashBal = 0; const salRuns = {}, prevOf = m => new Date(m.getFullYear(), m.getMonth() - 1, 1);
    const inMonth = (m, f) => list.filter(v => v.status === 'posted' && v.date.slice(0, 7) === iso(m).slice(0, 7) && f(v));
    months.forEach((m, k) => {
      const mon = m.toLocaleDateString('en-IN', { month: 'short' }).toUpperCase(), ym = iso(m).slice(0, 7);
      const rentAmt = rt(scale * .03); if (D(m, 5) <= end) mk('Payment', D(m, 5), [['rent', rentAmt, 0], ['bank', 0, rentAmt]], 'Rent for ' + mon + ' paid to Shreeji Estates', { bn: 'IMPS-RENT-SHREEJI ESTATES-' + mon, bd: 0, meta: { payee: 'Shreeji Estates' } });
      if (D(m, 12) <= end) { const a = r2(scale * .01 * rnd(.8, 1.2)); mk('Payment', D(m, 12), [['power', a, 0], ['bank', 0, a]], 'Electricity bill for ' + mon, { bn: 'BILLPAY DR-TORRENT POWER LTD', bd: 0 }); }
      if (D(m, 3) <= end) { mk('Contra', D(m, 3), [['cash', 40000, 0], ['bank', 0, 40000]], 'Cash withdrawn for petty expenses', { bn: 'CASH WDL-SELF-CHQ 0002' + (30 + k), bd: 0 }); cashBal += 40000; }
      for (let c = 0; c < 3; c++) { const d = D(m, 8 + c * 6), a = Math.round(rnd(1200, 6500)); if (d <= end && cashBal > a + 5000) { mk('Payment', d, [[pick(['office', 'travel', 'repair']), a, 0], ['cash', 0, a]], 'Petty cash expense', { maker: 'Amit Patel' }); cashBal -= a; } }
      if (D(m, ld(m)) <= end) { mk('Payment', D(m, ld(m)), [['bankchg', 59, 0], ['bank', 0, 59]], 'Bank charges for ' + mon, { bn: 'CHGS-NEFT/IMPS ' + mon, bd: 0 }); }
      const intp = r2((scale - 0) * .00875 * 1), prin = rt(scale * .008); if (D(m, 25) <= end) mk('Payment', D(m, 25), [['tl', prin, 0], ['intexp', intp, 0], ['bank', 0, prin + intp]], 'Term loan EMI for ' + mon, { bn: 'EMI DEBIT LOAN A/C 5100' + (900 + k), bd: 0 });
      if (k > 0) {
        const pm = prevOf(m), tdsP = r2(sum(list.filter(v => v.status === 'posted' && v.date.slice(0, 7) === iso(pm).slice(0, 7)), v => sum(v.lines.filter(l => l.acc === 'tds_p'), l => l.cr)));
        if (tdsP > 0 && D(m, 7) <= end) mk('Payment', D(m, 7), [['tds_p', tdsP, 0], ['bank', 0, tdsP]], 'TDS deposited for ' + iso(pm).slice(0, 7), { bn: 'TDS CHALLAN 281-ITNS-' + ref().slice(0, 8), bd: 0, checker: 'Neha Mehta' });
        const pfP = r2(sum(list.filter(v => v.status === 'posted' && v.date.slice(0, 7) === iso(pm).slice(0, 7)), v => sum(v.lines.filter(l => l.acc === 'pf_p'), l => l.cr)));
        if (pfP > 0 && D(m, 15) <= end) mk('Payment', D(m, 15), [['pf_p', pfP, 0], ['bank', 0, pfP]], 'PF, ESI and PT deposited for ' + iso(pm).slice(0, 7), { bn: 'EPFO ECR PAYMENT-TRRN' + ref().slice(0, 8), bd: 0 });
        const o = {}, i = {}; ['c', 's', 'i'].forEach(h => { o[h] = r2(sum(list.filter(v => v.status === 'posted' && v.date.slice(0, 7) === iso(pm).slice(0, 7)), v => sum(v.lines.filter(l => l.acc === 'go_' + h), l => l.cr - l.dr))); i[h] = r2(sum(list.filter(v => v.status === 'posted' && v.date.slice(0, 7) === iso(pm).slice(0, 7)), v => sum(v.lines.filter(l => l.acc === 'gi_' + h), l => l.dr - l.cr))); });
        const lines = []; let cash = 0; ['c', 's', 'i'].forEach(h => { if (o[h] > 0) { const set = Math.min(o[h], Math.max(0, i[h])); lines.push(['go_' + h, o[h], 0]); if (set > 0) lines.push(['gi_' + h, 0, set]); cash += o[h] - set; } });
        if (cash > 0 && D(m, 20) <= end) { lines.push(['bank', 0, r2(cash)]); mk('Payment', D(m, 20), lines, 'GST paid for ' + iso(pm).slice(0, 7) + ' (GSTR-3B)', { bn: 'GST CHALLAN CPIN ' + ref().slice(0, 10), bd: 0, meta: { gst: true } }); }
      }
      const pr = Payroll.run(ym, b, co.state);
      if (D(m, ld(m)) <= end && pr.rows.length) { const L = [['sal', pr.gross, 0], ['pf_e', pr.er + pr.adm + pr.esiER, 0], ['sal_p', 0, pr.net], ['pf_p', 0, r2(pr.ee + pr.er + pr.adm + pr.esiEE + pr.esiER + pr.pt)], ['tds_p', 0, pr.tds]]; const tot = r2(sum(L, l => l[1]) - sum(L, l => l[2])); if (Math.abs(tot) > 0) L[3][2] = r2(L[3][2] + tot); mk('Journal', D(m, ld(m)), L, 'Payroll for ' + ym, { maker: 'Sanjay Rao', meta: { payroll: ym } }); mk('Payment', D(m, ld(m)), [['sal_p', pr.net, 0], ['bank', 0, pr.net]], 'Salary paid for ' + ym, { bn: 'SALARY BULK NEFT-' + ym.replace('-', ''), bd: 0, maker: 'Sanjay Rao', meta: { payroll: ym } }); }
      if (k <= months.length - 3 && D(m, ld(m)) <= end) { const total = r2(sum(b.assets, a => FA.dep(a, iso(m), iso(D(m, ld(m)))))); if (total > 0) mk('Journal', D(m, ld(m)), [['dep', total, 0], ['accdep', 0, total]], 'Depreciation for ' + ym + ' (Schedule II, SLM)', { maker: 'Amit Patel', meta: { dep: ym } }); }
    });
    // planted bank/books items
    const qm = months[mi(1)], q3 = months[mi(3)], q4 = months[mi(4)], q5 = months[mi(5)];
    const bounceAmt = rt(scale * .07), bounceC = party('C004'); let bounceRec;
    if (qm) bounceRec = mk('Receipt', D(qm, 14), [['bank', bounceAmt, 0], ['C004', 0, bounceAmt]], 'Cheque 004512 received from ' + bounceC.name, { bn: 'CLG-CHQ DEP-' + nm(bounceC) + '-CHQ 004512', bd: 0, meta: { party: 'C004' } });
    if (q3) { mk('Payment', D(q3, 19), [['susp', 38500, 0], ['bank', 0, 38500]], 'Payment pending identification (booked to suspense)', { bn: 'NEFT DR-UNIDENTIFIED BENEF-REF ' + ref().slice(0, 9), bd: 0, maker: 'Amit Patel' }); P('Suspense: ₹38,500 paid to an unidentified beneficiary and parked in Suspense A/c.'); }
    if (q4) { let d = D(q4, 1); while (d.getDay() !== 0) d = addD(d, 1); const a = Math.max(100000, Math.round(scale * .05 / 100000) * 100000); mk('Contra', d, [['cash', a, 0], ['bank', 0, a]], 'Cash withdrawal', { bn: 'CASH WDL-SELF-CHQ 000231', bd: 0, maker: 'Riya Shah', checker: 'Riya Shah', hour: 21, min: 14, wk: true }); cashBal += a; P('Large round-sum cash withdrawal of ₹' + a.toLocaleString('en-IN') + ' on a Sunday, maker and checker the same person.'); for (let i = 0; i < 12; i++) { const dd = addD(D(q4, 3), i * 2), aa = 9200 + Math.round(R() * 750); if (dd <= end) mk('Payment', dd, [[pick(['repair', 'office', 'travel']), aa, 0], ['cash', 0, aa]], 'Cash purchase of consumables', { maker: 'Amit Patel' }); } P('Twelve cash payments between ₹9,200 and ₹9,950, just under the ₹10,000 cash limit (Benford test will flag digit 9).'); }
    if (q5) { const a = Math.max(100000, Math.round(scale * .2 / 100000) * 100000); mk('Journal', D(q5, ld(q5)), [['C002', a, 0], ['sales', 0, a]], 'Being sales adjustment', { maker: 'Riya Shah', checker: 'Riya Shah', created: stamp(D(q5, ld(q5)), 23, 41), hour: 23 }); P('Round-sum manual journal of ₹' + a.toLocaleString('en-IN') + ' crediting Sales on the last day of the month, posted at 23:41 and self-approved.'); }
    const ins = months[mi(1)]; if (ins) { const a = rt(scale * .012); mk('Payment', D(ins, 11), [['prepaid', a, 0], ['bank', 0, a]], 'Annual insurance premium paid in advance', { bn: 'NEFT DR-NEW INDIA ASSURANCE', bd: 0 }); P('Prepaid insurance of ₹' + a.toLocaleString('en-IN') + ' never amortised to expense.'); }
    { const d1 = addD(end, -1), v10 = party('V010'), c3 = party('C003'); mk('Payment', d1, [['V010', 125000, 0], ['bank', 0, 125000]], 'Cheque issued to ' + v10.name + ' (not yet presented)', { bn: 'CHQ ISSUED', bd: 6, meta: { party: 'V010' }, wk: false }); mk('Receipt', d1, [['bank', 210000, 0], ['C003', 0, 210000]], 'Cheque deposited by ' + c3.name + ' (in transit)', { bn: 'CHQ DEP', bd: 6, meta: { party: 'C003' } }); P('Timing items: a ₹1,25,000 cheque issued and a ₹2,10,000 cheque deposited in the last days, not yet in the bank statement (appear in the reconciliation statement).'); }
    const bm = months[mi(5)]; const v28 = party('V028'); if (bm) { const a = r2(scale * .02); mk('Payment', D(bm, 16), [['V028', a, 0], ['bank', 0, a]], 'Payment to ' + v28.name, { bn: 'NEFT DR-' + v28.ifsc + '-' + nm(v28) + '-V028', bd: 0, meta: { party: 'V028' } }); P('Payment to blocked vendor V028.'); }
    if (add1.use <= endS) P('Fixed asset FA006 put to use after 28 September: under 180 days, so Income Tax depreciation is at half rate.');
    P('Customer C008 state differs from GSTIN state code; C021 has a zero credit limit; C012 has old unpaid invoices; V002 and V003 bills carry no TDS.');
    P('Depreciation not posted for the latest closed month, and no accrual or tax provision journals exist.');
    // pending / rejected vouchers (approval inbox)
    const T1 = D(months[months.length - 1], Math.min(end.getDate(), 20)), lastM = months[months.length - 1];
    const pv = party('V020'); mk('Payment', addD(end, -1), [['V020', 385000, 0], ['bank', 0, 385000]], 'Part payment to ' + pv.name, { status: 'pending', maker: 'Amit Patel', meta: { party: 'V020' } });
    mk('Journal', addD(end, -1), [['exp_p', 0, 120000], ['prof', 120000, 0]], 'Provision for audit and legal fees', { status: 'pending', maker: 'Amit Patel' });
    const pbig = this.purchase(b, mk, party('V024'), addD(end, -2), 740000, { stCode, split, secAcc, tdsThr, tdsRate, skipTds, coState, pick, rnd, R, bills, exact: true, status: 'pending', noPay: true });
    mk('Payment', addD(end, -2), [['office', 18400, 0], ['bank', 0, 18400]], 'Website hosting renewal (AI-drafted from text: "paid hosting 18,400")', { status: 'pending', ai: true, maker: 'Amit Patel', meta: { aiNote: 'Drafted from natural language' } });
    const rj = mk('Payment', addD(end, -6), [['V013', 62000, 0], ['bank', 0, 62000]], 'Payment to vendor (wrong vendor selected)', { status: 'rejected', maker: 'Amit Patel', meta: { party: 'V013', rejectReason: 'Bill belongs to V031; vendor selected by mistake.' } });
    // self-approval / after-hours / backdated plants
    const pays = list.filter(v => v.type === 'Payment' && v.status === 'posted' && Books.amt(v) > 60000);
    pays.slice(2, 6).forEach(v => { v.checker = v.maker; }); P('Four payments above ₹60,000 approved by the same person who prepared them.');
    list.filter(v => v.status === 'posted' && v.type === 'Sales').slice(5, 8).forEach(v => { v.createdAt = stamp(dparse(v.date), 23, 12 + Math.floor(R() * 40)); });
    list.filter(v => v.status === 'posted' && v.type === 'Purchase').slice(9, 12).forEach(v => { const d = addD(dparse(v.date), 26); if (d <= end) v.createdAt = stamp(d, 11, 20); }); P('Three purchase bills entered more than 25 days after their bill date; three sales invoices entered after 11 pm.');
    // finalise numbering
    list.sort((x, y) => x.date.localeCompare(y.date) || x.createdAt.localeCompare(y.createdAt)); let siCount = 0;
    list.forEach(v => { const f = fyOfDate(v.date); if (v.type === 'Sales') { siCount++; if (siCount === 22) b.seq['Sales' + f] = (b.seq['Sales' + f] || 0) + 1; } v.no = Books.nextNo(b, v.type, f); if (v.type === 'Sales') v.meta.invNo = v.no; });
    P('Sales invoice numbering has a gap at 22 (one number skipped).');
    // bank statement
    const rows = [], planted = {}; let bal = b.accounts.find(a => a.id === 'bank').op; const open = bal;
    const bankV = []; list.forEach(v => { if (v.status !== 'posted' || !v._bn) return; const l = v.lines.find(x => x.acc === 'bank'); if (!l) return; const bd = addD(dparse(v.date), v._bd == null ? 0 : v._bd); if (bd > end) return; bankV.push({ date: bd, narr: v._bn, w: l.cr || 0, d: l.dr || 0, v, ref: /CHQ/.test(v._bn) ? (v._bn.match(/CHQ (\d+)/) || [, ''])[1] : ref().slice(0, 12) }); });
    const extra = (date, narr, w, d, plant, rf) => { if (date <= end) bankV.push({ date, narr, w, d, plant, ref: rf || ref().slice(0, 12) }); };
    if (qm) { extra(addD(D(qm, 14), 2), 'CHQ RETURN-INSUFFICIENT FUNDS-CHQ 004512', bounceAmt, 0, 'Cheque 004512 from C004 returned unpaid. The receipt in books must be reversed.', '004512'); extra(addD(D(qm, 14), 2), 'CHQ RTN CHGS INCL GST', 590, 0, 'Cheque return charges not recorded in books.'); }
    if (months[0]) extra(D(months[0], 9), 'ACCOUNT MAINTENANCE CHARGES INCL GST', 1770, 0, 'Bank charges not recorded in books.');
    if (q3) extra(D(q3, 18), 'NEFT CR-UNKNOWN REMITTER-REF ' + ref().slice(0, 9), 0, rt(scale * .045), 'Receipt from an unidentified remitter. Must not be credited to income without investigation.');
    months.forEach(m => { const mo = m.getMonth(); if ([5, 8, 11, 2].includes(mo)) extra(D(m, ld(m)), 'INT.PD ' + iso(D(m, 1)).slice(0, 7) + ' TO ' + iso(D(m, ld(m))).slice(0, 7), 0, rt(scale * .004), 'Interest credited by the bank, not recorded in books.'); });
    bankV.sort((x, y) => x.date - y.date);
    rows.push({ date: iso(new Date(fy, 3, 1)), narr: 'OPENING BALANCE B/F', ref: '', w: 0, d: 0, bal });
    bankV.forEach(x => { bal = r2(bal + x.d - x.w); rows.push({ date: iso(x.date), narr: x.narr, ref: x.ref, w: x.w, d: x.d, bal }); if (x.plant) planted[rows.length - 1] = x.plant; });
    list.forEach(v => { delete v._bn; delete v._bd; });
    b.vouchers = list; b.bankStmt = { bank: 'HDFC Bank', rows, opening: open, closing: bal, to: endS, planted };
    // POs for 3-way match
    const pbs = list.filter(v => v.type === 'Purchase' && v.status === 'posted' && v.meta.items && v.meta.items.length && v.meta.party && !['V011', 'V015'].includes(v.meta.party)).slice(0, 8);
    b.pos = pbs.map((v, i) => { const it = v.meta.items[0], pv = i === 2 ? .92 : 1, gq = i === 4 ? .9 : 1; return { id: uid('po'), no: 'PO/' + fyLabel(fy) + '/' + String(i + 1).padStart(3, '0'), vendor: v.meta.party, date: iso(addD(dparse(v.date), -12)), items: [{ desc: it.desc, qty: it.qty, rate: r2(it.rate * pv) }], grn: [{ date: iso(addD(dparse(v.date), -2)), qty: Math.round(it.qty * gq * 100) / 100 }], billVid: v.id }; });
    const unrecBill = pbs[2]; if (unrecBill) P('3-way match: PO 003 rate is 8% lower than the bill; PO 005 goods received are 10% fewer than billed.');
    b.counts = {}; b.items.forEach(it => { const q = Seed.stockQty(b, it, endS); b.counts[it.id] = Math.round(q * (it.id === 'RM02' ? .94 : 1)); }); P('Stock count: PP copolymer physical quantity is 6% below book; masterbatch batch has expired.');
    // verification
    b.vouchers.forEach(v => { const dr = sum(v.lines, l => l.dr), cr = sum(v.lines, l => l.cr); if (Math.abs(dr - cr) > 0.01) console.error('Unbalanced seed voucher', v.no, dr, cr); });
    return b;
  },
  purchase(b, mk, v, date, gross, o) {
    const taxable0 = o.exact ? r2(gross / (o.capital ? 1.18 : 1.18)) : r2(gross / 1.18), taxable = taxable0, intra = o.stCode(v) === o.coState, g = o.split(taxable, 18, intra), total = r2(taxable + g.c + g.s + g.i);
    const s = v.tds || 'None'; let tds = 0; const thr = o.tdsThr[s] || 0;
    if (!o.capital && s !== 'None' && s !== '194Q' && taxable >= thr && !o.skipTds.has(v.id)) tds = r2(taxable * o.tdsRate(s, v.pan) / 100);
    const exp = o.capital || o.secAcc[s] || 'purch', net = r2(total - tds), qty = Math.max(1, Math.round(taxable / o.rnd(60, 130)));
    const lines = [[exp, taxable, 0]]; if (g.c) lines.push(['gi_c', g.c, 0], ['gi_s', g.s, 0]); if (g.i) lines.push(['gi_i', g.i, 0]); lines.push([v.id, 0, net]); if (tds) lines.push(['tds_p', 0, tds]);
    const billNo = o.billNo || ('INV-' + (1000 + Math.floor(o.R() * 8999)));
    const vo = mk('Purchase', date, lines, o.narr || 'Purchase from ' + v.name, { status: o.status, meta: { party: v.id, billNo, taxable, cgst: g.c, sgst: g.s, igst: g.i, tds, tdsSec: tds ? s : '', itc: true, rate: 18, total, pos: o.stCode(v), noPay: !!o.noPay, items: [{ desc: o.narr || o.pick(['Polymer raw material', 'Job work charges', 'Consulting services', 'Packaging material', 'Maintenance service']), hsn: s === '194J' ? '9983' : s === '194C' ? '9988' : '3901', qty, rate: r2(taxable / qty), gst: 18, ledger: exp }] } });
    if (vo.status !== 'rejected') o.bills.push({ v: vo, net, noPay: !!o.noPay, force: !!o.billNo }); return vo;
  },
  stockQty(b, it, to) { return it.opQty + sum(b.moves.filter(m => m.item === it.id && m.date <= to), m => m.type === 'IN' ? m.qty : -m.qty); }
};

/* ---------- Lab override: books + bank derived consistently ---------- */
Lab.build = function (co) {
  const vendors = this.vendors(co), customers = this.customers(co), books = Seed.build(co, vendors, customers), st = books.bankStmt;
  const f = d => { const x = dparse(d); return String(x.getDate()).padStart(2, '0') + '/' + String(x.getMonth() + 1).padStart(2, '0') + '/' + String(x.getFullYear()).slice(2); };
  const bank = { title: 'Bank statement (HDFC layout)', file: 'Bank_Statement_HDFC', closing: st.closing, planted: st.planted, rows: st.rows.map((r, i) => ({ 'Date': f(r.date), 'Narration': r.narr, 'Chq./Ref.No.': r.ref, 'Value Dt': f(r.date), 'Withdrawal Amt.': r.w ? r.w.toFixed(2) : '', 'Deposit Amt.': r.d ? r.d.toFixed(2) : '', 'Closing Balance': r.bal.toFixed(2) })) };
  const users = this.users(co); return { vendors, customers, bank, users, seed: { books }, answerKey: '' };
};
