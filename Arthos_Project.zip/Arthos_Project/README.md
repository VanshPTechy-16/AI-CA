# Arthos.AI: AI ERP with internal controls and Indian compliance

*"AI proposes. Humans approve. The ledger remembers."*
Built for the ICAI Advanced ITT batch hackathon (theme: AI and ERP).

One HTML file with double-entry books, maker-checker approvals, GST and TDS working files, payroll, fixed assets, bank reconciliation, fraud tests, a month-end close agent, a Virtual CFO, framework-specific financial statements with notes, an Ind AS first-time adopter guide, and a Claude-powered AI layer. It runs with no install.

## What is in this folder

| Folder | What it holds |
|---|---|
| `01_App` | `arthos-offline.html` (everything built in, works with no internet) and `arthos.html` (smaller; loads libraries online) |
| `02_Bridge_Server` | Optional Node server: hides your Claude key, sends real email with attachments |
| `03_Audit_Report` | `Arthos_ERP_Audit_Report.xlsx`: your 255-question checklist and your 21 points, with evidence |
| `04_Source` | Source parts, styles, libraries, `build.py` (rebuilds both HTML files) and `gen_skins.py` (builds the ten skins with a contrast solver) |
| `05_Tests` | Node tests and browser tests, including the contrast audit and the sample-data round trip |
| `06_Sample_Data` | 67 files in 12 folders, one per tile, plus an answer key listing every planted error |
| `07_Docs` | Your 21 points with status, the roadmap and meta prompt, your USP list |
| `08_Screenshots` | Welcome page, ten skins, Virtual CFO, statement assistant, Ind AS tile, statement pages |

## Start in two minutes

1. Open `01_App/arthos-offline.html` in Chrome or Edge.
2. Click **Load sample company** (Narmada Polymers Pvt Ltd), choose it, and sign in.

| User | Role | PIN |
|---|---|---|
| Riya Shah | Admin (owner) | 1234 |
| Amit Patel | Accountant | 2222 |
| Neha Mehta | Finance manager (approver) | 3333 |
| Karthik Iyer | Auditor (read-only) | 4444 |

3. Open **Import & sample data**. The test checklist lists what to click in every module and what you should see.
4. To start from nothing: **Create new company**, then drag the files from `06_Sample_Data` onto any page.

## Which sample folder tests which tile

| Folder | Upload it on | You should see |
|---|---|---|
| `01_Masters` | Any page | Vendors and customers with planted GSTIN and duplicate issues, employees, assets, stock |
| `02_Bank_Statements` | Statement assistant | Four layouts plus a text PDF and a scanned image. About six lines to record, with suggested ledgers |
| `03_Sales` | Any page | Sales register, three sample invoices, leads and tickets for Leads and support |
| `04_Purchases` | Any page | Purchase register, supplier bill PDFs (read into a purchase form), bill photos (need AI or online OCR) |
| `05_Vouchers_and_Journals` | Any page | A full year of vouchers; trial balance and balance sheet agree |
| `06_Payroll` | Payroll | Employees and a payroll register |
| `07_GST_and_Tax` | GST, TDS desk, AI Studio | GSTR-2B with mismatches, a GST notice, a 26Q draft |
| `08_Annual_Reports_Ind_AS` | Ind AS first-time adopter | Three annual reports read into a trend table, adjustments and checklist |
| `09_Statement_Outputs` | (reference) | Examples of the sign-ready statements, letters and guide |
| `10_Users_and_Access` | (reference) | Users and roles with a planted segregation-of-duties conflict |
| `11_OCR_Scans` | Statement assistant, Purchases | Photos and a scan that exercise OCR |
| `12_Backup` | Settings, Import backup | A full backup of the sample company |

## Ten colour styles
Click the palette icon in the top bar, or choose in Settings. Ledger, Boardroom, Midnight Terminal, Gulabi, Aurora Glass, Ocean, Forest, Paper, Marigold and High Contrast. An automated audit checks every screen in every skin for unreadable text.

## AI features
- **Inside Claude (preview):** AI runs through your Claude account, no key needed.
- **Downloaded file:** add an Anthropic API key in Settings, or connect the Bridge. Everything else works without AI.
- Reading **scanned images** needs AI vision or online OCR. Text PDFs and Excel are read offline.

## Rebuild and test
```
cd 04_Source && python3 build.py        # rewrites both HTML files in 01_App
python3 gen_skins.py                    # only if you change a skin palette
cd ../05_Tests && npm install
node 01_books_integrity_and_all_screens.js
python3 browser/contrast_audit.py       # needs: pip install playwright; playwright install chromium
python3 browser/sample_roundtrip.py     # uploads the sample files into a blank company
```

## Honest status
See `03_Audit_Report` and `07_Docs/YOUR_21_POINTS.md`. In short:
- **Done and tested:** items 1 to 3, 5, 6, 9 to 14, 17 to 21 of your list.
- **Partly:** 4 (import and export on every feature), 7 (assessee-wise optimisation), 15 (ideas from your uploaded files), 16 (OCR).
- **Not verified by me:** real Claude responses, real email sending, phone layouts, 100,000+ records, screen readers.
- **Not built:** budgets, expense claims, manufacturing, document attachments, server-enforced permissions (needs a server beyond the optional Bridge).
- **Not ready for production.** Tax rates and due dates are as of June 2026; have a CA verify every value in `CONFIG`, and review every statement before signature.

## Delivery convention
This folder and `Arthos_Project.zip` are overwritten on every delivery, so there is only ever one current copy.

## Fix: charts going blank after a theme or style change
- **Cause:** the motion setting replaced Chart.js's animation defaults with a bare object, so colour animations had no interpolator. The first hover on a chart, or the first redraw on a theme change, threw `this._fn is not a function` inside Chart.js's shared animation loop. That stopped the loop for every chart, so every chart drawn afterwards stayed blank.
- **Fixed in both files in `01_App`:**
  - `Motion.apply` now keeps Chart.js's own animation defaults and only changes the duration.
  - A guard stops a bad animation from ever stopping the shared loop again.
  - Charts on any screen are redrawn in the new colours when the theme, style or device light/dark changes.
  - "Match device" now follows the device's light/dark switch.
  - A self-check redraws any chart that comes up empty.
- **Source:** the chart part is in `04_Source/p16_chart_theme.js` and is listed in `build.py`. The parts in `04_Source` are older than `01_App`; they don't include the motion feature and other later changes. Edit `01_App` directly until the sources are updated, because running `build.py` now would overwrite those features.
- **Test:** `05_Tests/browser/chart_theme_regression.py` hovers a chart, changes the style, then checks that the charts are still drawn. Run it with a visible browser, or under `xvfb-run`, so motion is on.

## Update: Google Gemini API, October 2026
- **Auth keys:** Google AI Studio now issues **auth keys** that start with `AQ.`. Old `AIza` standard keys stopped working with Gemini in September 2026.
  - The app now accepts `AQ.` keys and sends them in the `x-goog-api-key` header, never in the URL.
  - It warns when a saved key is an old `AIza` key, and explains 401 and 403 errors in plain language.
- **Models:** the model list is now `gemini-3.8-flash` (default), `gemini-3.5-flash-lite` (fastest and cheapest), 3.7 Flash, 3.6 Flash, 3.5 Flash and 3.1 Flash-Lite.
  - Saved 1.x and 2.x models switch to the default automatically. Gemini 2.5 is closed to new projects and 2.0 is retired.
  - If Google retires a model, the app falls back to a current one.
  - Settings has an **Other model ID** box for newer models.
- **Request format:** requests follow the Gemini 3.x rules.
  - No `temperature`, `topP` or `topK`.
  - `thinkingLevel` (minimal, low, medium or high, set in Settings) replaces `thinkingBudget`.
  - Requests never end with a model turn.
  - Thought summaries are left out of answers.
- **Apps Script bridge:** `02_Bridge_Server/Code.gs` and `GOOGLE_APPS_SCRIPT_SETUP.md`, which the app links to, were missing. Both are now included and use the same rules.
- **Test:** `05_Tests/browser/gemini_auth_and_models.py`.
