# Your 21 points: status and evidence

"Done and tested" means I ran it in a real browser and saw the result. See the "Your 21 points" sheet of the audit workbook for the same table with limits.

| # | Request | Status |
|---|---|---|
| 1 | Financial statements per applicable framework, with notes | Done and tested: Ind AS, AS, LLP, non-corporate, trust; 21 tie-out checks pass |
| 2 | First-time Ind AS adopter tile from annual reports | Done and tested with generated reports; scans need AI or online OCR |
| 3 | UI, fonts, text-whitening | Done and tested: 0 contrast issues in 12 skin variants on 41 screens and dialogs |
| 4 | Import and export of Excel, PDF and OCR everywhere | Partly: 13 import types, PDF and image for statements, bills, reports; formatted exports on every report |
| 5 | Five invoice formats on every invoice or export | Done and tested |
| 6 | First page with company choice and new user access | Done and tested |
| 7 | Assessee-wise optimisation and framework disclosure | Partly: templates, 24-item checklist, tips |
| 8 | Mail sharing | Done (dialog and attachment tested); sending needs the Bridge |
| 9 | Sign-ready statement formatting | Done and tested; auditor report page is a placeholder |
| 10 | Statutory validation | Done and tested |
| 11 | Exhaustive sample data in folders | Done and tested: 67 files round-tripped through the upload button |
| 12 | Refresh on every page | Done and tested |
| 13 | Bank statement upload and suggestions, drag and drop everywhere | Done and tested: 123 of 123 suggestions right on lines in the books |
| 14 | Better dashboard and a CFO menu | Done and tested: Virtual CFO; the main Dashboard was not redesigned |
| 15 | Features from the uploaded P2P and inventory files | Partly: RFQ comparison, EOQ and reorder, ageing, count sheet, HSN summary, leads and tickets, TDS desk |
| 16 | OCR reading and suggestions | Partly: needs AI vision or online OCR; live responses not verified |
| 17 | Entries from text never close half-filled | Done and tested |
| 18 | Search in every dropdown | Done and tested |
| 19 | Mandatory fields for posting | Done for vouchers; capital purchase and loan-term fields not asked |
| 20 | Sample company with every field | Done |
| 21 | Ten UI options | Done and tested |
