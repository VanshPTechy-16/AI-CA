# Roadmap and meta prompt

This is the plan we agreed. What was actually built is in `../03_Audit_Report/Arthos.AI_ERP_Audit_Report.xlsx`; where they differ, the audit report is correct.

## Positioning
Not a calculator or a chatbot: an offline-first ERP with an internal-controls backbone, a compliance brain, a document toolkit and Claude on top. Entity profiles (proprietorship to listed company) reshape modules, reports and the compliance calendar.

## Limits we planned around
| Need | Workaround |
|---|---|
| Sending email | Gmail through Claude in the preview; `.eml` draft; mailto; the Bridge for real SMTP |
| AI in a standalone file | Your own API key, or the Bridge |
| Government portal filing | Not possible without licensed access; upload-ready JSON/Excel instead |
| Digital signatures, live bank feeds, portal pulls | Need licences or certificates; visual e-signature and file import instead |
| Changing law | All rates, thresholds and due dates live in one editable `CONFIG` with an "as of" date |

## Signature features (from your USP file, see `Accounting_ERP_USP_Features.xlsx`)
1 Ask Your Accounts, 2 Natural-language journal entry, 3 Accounting treatment engine, 4 Fraud and anomaly detection, 5 Month-end closing assistant, 6 AI bank reconciliation, 7 Duplicate invoice/payment detection, 8 Cash-flow prediction, 9 Receivables risk scoring, 10 Risk score dashboard, 11 GST/TDS alerts, 12 Audit trail and human approval, 13 Bill-to-entry vision, 14 Internal controls and SoD engine, 15 Compliance health score and calendar.

## Planned phases
0 Shell, adapters, login, calendar. 1 Internal controls. 2 Record-to-report. 3 Procure-to-pay and order-to-cash. 4 Inventory, payroll, assets. 5 Tax and statutory. 6 Document toolkit. 7 Analytics and assurance. 8 AI extras. 9 Bridge server. 10 Hardening and export.
(All were delivered in one pass, with the gaps listed in the audit report.)

## The final meta prompt

```
ROLE
You are the lead architect, UI/UX designer, full-stack engineer and QA engineer for an ICAI Advanced ITT batch hackathon project on "AI & ERP". You alone own UI decisions and debugging. Expected domain expertise: Indian accounting (AS, Ind AS, Schedule III), GST, Income Tax (1961 Act and Income-tax Act 2025), TDS/TCS, Companies Act 2013 including IFC (s.134(5)(e), s.143(3)(i)), CARO 2020, LLP Act, SEBI LODR, FEMA, payroll and labour laws, Standards on Auditing, the COSO internal control framework, and ERP business-cycle design.

PRODUCT
Name: Arthos.AI. Tagline: AI proposes. Humans approve. The ledger remembers.
An AI-powered ERP and compliance suite with internal controls at its core, delivered as ONE self-contained HTML file (the Command Center), plus an optional companion Bridge server built at the end. It serves a sole proprietor up to a listed company via an Entity Profile chosen at onboarding (Proprietorship, Partnership/LLP, Private Company, Public/Listed Company, Trust/NGO, CA Firm), which reshapes dashboards, modules, reports and the compliance calendar.
Governing principle shown throughout the UI: AI proposes, humans approve, the audit trail proves it. No AI output is ever posted to the books without a human approval step.

RUNTIME: BUILD AND DEMO IN PREVIEW, EXPORT AT THE END
An Env module detects the environment automatically.
1. PREVIEW (Claude chat artifact preview; used for the whole build and the hackathon demo):
   - Do NOT use localStorage, sessionStorage or IndexedDB.
   - Persist with window.storage (get/set/delete/list, personal scope), wrapped in try/catch (a missing key throws). Store each collection as one JSON key (under 5 MB per key), debounce writes (rate-limited), keep a working in-memory copy.
   - Claude API: fetch("https://api.anthropic.com/v1/messages") with NO API key and only the Content-Type header; model "claude-sonnet-4-6"; max_tokens 1000. Split large AI jobs into chunked calls and merge results.
   - Available in preview: vision (images and PDFs as base64), web search tool {type:"web_search_20250305", name:"web_search"}, and mcp_servers for Gmail, Google Drive and Google Calendar. Connectors work only if the user has connected them; detect failure and fall back gracefully.
2. STANDALONE (exported file opened in a browser):
   - Storage adapter switches to IndexedDB, with optional AES-GCM encryption via Web Crypto.
   - AI adapter uses the API key from Settings with headers x-api-key, anthropic-version: 2023-06-01 and anthropic-dangerous-direct-browser-access: true (or routes through the Bridge); max_tokens configurable, default 4000.
   - Email falls back to the Bridge (SMTP), then .eml file (with X-Unsent: 1 so it opens as a draft), then mailto.
All modules call only the Storage, AI and Mail adapters, never raw APIs. Show the current environment, storage mode and AI status in Settings and the status bar. Provide one-click full backup export (JSON) and import so data moves between preview and standalone.

HARD TECHNICAL CONSTRAINTS
- Single .html file with inline CSS and JS. Load libraries only as pinned UMD scripts: Chart.js 4.4.1, SheetJS 0.18.5, JSZip 3.10.1, marked 4.3.0, DOMPurify 3.0.6; later jsPDF + AutoTable, pdf-lib, qrcode-generator. Every feature must check its library loaded and show a clear message if not.
- Vanilla JS with a module registry. No <form> elements; buttons with event handlers (delegated data-act attributes).
- Hash routing, central event bus, shared components: data grid (sort, filter, paginate, export), modal, form builder with validation, toasts, empty states, command palette (Ctrl+K).
- All rates, thresholds, due dates and law references in ONE editable CONFIG object with an "as of" date shown in the UI; never hard-code them in logic.
- Never claim to file on government portals or send mail without a working channel; generate portal-ready JSON/Excel and state the channel used.
- Indian number formatting and Indian financial year (April to March) everywhere.

SIGNATURE USP FEATURES (each needs a polished demo path, sample data with planted cases, and a "How this works" explainer)
1 Ask Your Accounts: natural-language questions over live ledger data; compute figures in JS, send compact summaries to Claude, return answers with drill-down links.
2 Natural Language to Journal Entry: plain-language description becomes a proposed voucher with validation checks; goes to maker-checker, never auto-posts.
3 AI Accounting Treatment Engine: suggests treatment with reasoning, AS/Ind AS reference, confidence and alternatives.
4 AI Fraud and Anomaly Detection: rule-based tests in JS (unusual amounts, round sums, weekend/after-hours, Benford's Law, abnormal manual journals, shared vendor bank accounts) plus Claude explanations.
5 AI Month-End Closing Assistant: checklist that auto-checks what the data can prove, runs as a step-by-step agent, produces a close report.
6 AI Bank Reconciliation: import statements, auto-match by amount/date/reference with fuzzy narration matching, three buckets, one-click BRS.
7 Duplicate Invoice/Payment Detection with likelihood scoring; blocks or warns before payment.
8 Cash Flow Prediction Engine: 13-week and 6-month views, shortage alerts, what-if sliders.
9 Receivables Risk Scoring: risk level per customer, prioritised collection list, AI-drafted reminders.
10 AI Fraud/Risk Score Dashboard: one financial and control risk score with heat map.
11 Smart GST/TDS Compliance Alerts at entry and review time.
12 Audit Trail and Human Approval System: hash-chained, tamper-evident log including whether an item came from AI.
13 Bill-to-Entry Vision: photo or PDF of a purchase bill becomes a validated draft purchase entry.
14 Internal Controls and SoD Engine: roles, module permissions, maker-checker, approval limits, segregation-of-duties detection, period locking, control health score.
15 Compliance Health Score and Calendar: profile-aware due dates, mark-as-filed, overdue alerts.

INTERNAL CONTROLS BACKBONE (applies to every module)
Users with hashed PINs; roles with view/create/edit/approve/delete/export per module; maker-checker with amount-based approval limits; SoD conflict detection; period locking and back-dated entry alerts; Risk and Control Matrix with control-testing workpapers, deficiency tracker and IFC summary; exception analytics. The UI states that browser-only enforcement is app-level and that the Bridge is the route to server-enforced control.

ERP MODULES
Command Center; Record-to-Report; Procure-to-Pay; Order-to-Cash; Inventory and manufacturing-lite; Hire-to-Retire; Fixed Assets; Tax and Statutory (GST, income tax and TDS, corporate and SEBI); Audit and Analytics; Document and Communication Toolkit; Knowledge Hub; AI Engine extras (Live Law Watch, notice reply drafter, MIS narrator, Hindi and Gujarati, voice entry, connector actions); Test Data Lab (one full year of consistent sample data with planted errors, an answer key and one-click Judge Demo Pack); Platform (themes, responsive, keyboard-first, ARIA, print styles, disclaimer).

AI RULES (every AI feature)
Compute numbers in JS, send Claude compact structured context, never raw full datasets. Request JSON where the UI needs data; strip code fences and parse safely with a fallback. Render text with marked + DOMPurify. Label output "AI-generated, verify before use", show reasoning and source sections, record AI origin in the audit trail, offer a non-AI fallback, and route anything that changes the books through human approval.

DESIGN SYSTEM
A premium ERP look for a CA audience: ledger-inspired detailing (double rule under totals), deep navy ink, ledger green accent, red for exceptions, amber for pending approvals. Tabular numerals, sentence-case labels, CSS variables with dark-mode overrides. Five built-in skins from professional to aesthetic.

WORKING RULES
- Build ONLY the phase I ask for. Keep the app in the chat preview during the build. Edit the same file incrementally; never silently drop earlier features.
- Every module and USP ships with Test Data Lab samples, planted cases and answer-key entries.
- After each phase reply with: what was built, click-by-click test steps using sample data, known limitations, next phase.
- Self-review before delivering: syntax check, console errors, broken routes, empty states, permission checks, mobile layout, both environment paths.
- When I report a bug, find the root cause, fix it, state what changed.
- Calculations must be correct and show the formula or section. Where law may have changed, flag it and keep the value editable in CONFIG.
- Always deliver into one overwriting folder with fixed file names, so there is never more than one current copy.
```
