const { JSDOM } = require('jsdom'); const fs = require('fs'); const path = require('path'); const ROOT = path.join(__dirname, '..');
const L = (p) => fs.readFileSync(path.join(ROOT, '04_Source', 'libs', p), 'utf8');
const libs = { 'chart.js@4.4.1/dist/chart.umd.js': "window.Chart=function(){this.destroy=function(){}};Chart.defaults={};", 
 'xlsx@0.18.5/dist/xlsx.full.min.js': L('xlsx.full.min.js'),
 'jszip@3.10.1/dist/jszip.min.js': L('jszip.min.js'),
 'marked@4.3.0/marked.min.js': L('marked.min.js'),
 'dompurify@3.0.6/dist/purify.min.js': L('purify.min.js'),
 'pdf-lib@1.17.1/dist/pdf-lib.min.js': L('pdf-lib.min.js'),
 'jspdf@2.5.1/dist/jspdf.umd.min.js': L('jspdf.umd.min.js'),
 'jspdf-autotable@3.8.2/dist/jspdf.plugin.autotable.min.js': L('jspdf.plugin.autotable.min.js'),
 'qrcode-generator@1.4.4/qrcode.js': L('qrcode.js') };
exports.make = async function (opts = {}) {
  let html = fs.readFileSync(path.join(ROOT, '01_App', 'arthos.html'), 'utf8');
  html = html.replace(/<script src="https:\/\/cdn\.jsdelivr\.net\/npm\/([^"]+)"><\/script>/g, (m, p) => libs[p] !== undefined ? '<script>' + libs[p].replace(/<\/script>/g, '<\\/script>') + '</script>' : '');
  const errors = [];
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://x.test/', beforeParse(w) {
    if (opts.preview !== false) { const mem = {}; w.storage = { get: async k => { if (!(k in mem)) throw new Error('nokey'); return { key: k, value: mem[k] } }, set: async (k, v) => { mem[k] = v; return { key: k, value: v } }, delete: async k => { delete mem[k]; return { deleted: true } }, list: async () => ({ keys: Object.keys(mem) }) }; w.__mem = mem; }
    Object.defineProperty(w, 'crypto', { value: require('crypto').webcrypto });
    w.TextEncoder = TextEncoder; w.TextDecoder = TextDecoder;
    w.fetch = opts.fetch || (async (u, o) => ({ ok: true, status: 200, json: async () => ({ content: [{ type: 'text', text: 'Connected' }] }) }));
    w.matchMedia = () => ({ matches: false, addEventListener() {} });
    w.scrollTo = () => {}; w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
    w.HTMLElement.prototype.scrollIntoView = function () {};
    w.addEventListener('error', e => errors.push('ERR ' + e.message));
    w.console.error = (...a) => errors.push('console.error ' + a.map(String).join(' ').slice(0, 300));
    w.alert = () => {}; w.print = () => {};
  } });
  const w = dom.window; const $ = s => w.document.querySelector(s);
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const click = s => { const el = typeof s === 'string' ? $(s) : s; if (!el) throw new Error('missing ' + s); el.dispatchEvent(new w.MouseEvent('click', { bubbles: true })); };
  const go = async id => { click(`.nav-item[data-arg="${id}"]`); await sleep(40); };
  const setv = (sel, v, ev = 'input') => { const el = $(sel); if (!el) throw new Error('missing ' + sel); el.value = v; el.dispatchEvent(new w.Event(ev, { bubbles: true })); };
  await sleep(300);
  return { w, $, sleep, click, go, setv, errors, dom };
};
exports.loginDemo = async function (t, pin = '1234', idx = 0) {
  const { w, $, sleep, click } = t;
  click('[data-act="ob-demo"]'); await sleep(1500);
  click(w.document.querySelectorAll('.upick')[idx]); $('#login-pin').value = pin; click('[data-act="wl-go"]'); await sleep(700);
};
