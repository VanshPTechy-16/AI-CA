const H = require('./harness');
(async () => {
  const log = (k, v) => console.log(k.padEnd(30), typeof v === 'string' ? v : JSON.stringify(v));
  const t = await H.make(); const { w, $, sleep, click, go, setv, errors } = t; const E = s => w.eval(s);
  await H.loginDemo(t);
  log('bell badge', $('.bell .badge') && $('.bell .badge').textContent); click('[data-act="notif"]'); await sleep(40); log('notifications', [...w.document.querySelectorAll('.modal li b')].map(x => x.textContent)); click('.modal [data-close]');
  // palette
  click('[data-act="palette"]'); await sleep(30); setv('#pal-in', 'riddhi'); await sleep(30); log('palette "riddhi"', [...w.document.querySelectorAll('#pal-list li')].slice(0, 5).map(l => l.textContent)); w.document.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Escape' }));
  click('[data-act="palette"]'); await sleep(30); setv('#pal-in', 'INV-2231'); await sleep(30); log('palette "INV-2231"', [...w.document.querySelectorAll('#pal-list li')].slice(0, 4).map(l => l.textContent)); w.document.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Escape' }));
  // integrity + selftest
  const I = await E(`Integrity.run()`); log('integrity', I.map(r => (r.ok ? 'PASS ' : r.warn ? 'WARN ' : 'FAIL ') + r.name + ' | ' + r.detail)); 
  const S = E(`SelfTest.run()`); log('self-test', S.filter(r => r.ok).length + '/' + S.length + ' pass'); S.filter(r => !r.ok).forEach(r => log('  FAILED', r));
  // tables
  await go('vouchers'); log('tbl-tools present', !!$('.tbl-tools')); log('pager text', ($('#view .row.small, #view [data-act="grid-more"]') ? 'pager visible' : 'no pager'), ); log('rows shown', w.document.querySelectorAll('#view tbody tr').length);
  setv('[data-tf]', 'Riddhi'); await sleep(20); log('filter "Riddhi" visible rows', [...w.document.querySelectorAll('#view tbody tr')].filter(r => r.style.display !== 'none').length);
  setv('[data-tf]', ''); const th = [...w.document.querySelectorAll('#view th[data-sortable]')].find(x => /Amount/i.test(x.textContent)); click(th); click(th); await sleep(20);
  const amts = [...w.document.querySelectorAll('#view tbody tr')].map(r => parseFloat((r.cells[+th.dataset.sortable] || { textContent: '' }).textContent.replace(/,/g, ''))).filter(x => !isNaN(x)); log('sorted desc ok', amts.slice(0, 4));
  // new ledger
  await go('ledgers'); click('[data-act="acc-add"]'); await sleep(40); setv('#al-n', 'Software Subscriptions'); setv('#al-g', 'Indirect expenses'); click('.modal footer [data-mi="1"]'); await sleep(100);
  log('ledger created', E(`Books.cur().accounts.filter(a=>a.name==='Software Subscriptions').map(a=>[a.id,a.nat,a.sch])`));
  // dashboard live update
  await go('dashboard'); const d1 = $('#view').textContent.replace(/\s+/g, ' ').match(/Profit before tax[^₹]*₹\s?([\d.,]+ ?[A-Za-z]*)/); 
  E(`(()=>{ const b=Books.cur(); b.vouchers.push({id:'vt1',no:'JV/TEST/1',type:'Journal',date:isoToday(),narr:'t',lines:[{acc:'rent',dr:3000000,cr:0},{acc:'bank',dr:0,cr:3000000}],status:'posted',maker:'t',checker:null,ai:false,createdAt:new Date().toISOString(),meta:{},ref:''}); })()`);
  await go('ledgers'); await go('dashboard'); const d2 = $('#view').textContent.replace(/\s+/g, ' ').match(/Profit before tax[^₹]*₹\s?([\d.,]+ ?[A-Za-z]*)/); log('dashboard PBT before/after', [d1 && d1[1], d2 && d2[1]]);
  E(`Books.cur().vouchers=Books.cur().vouchers.filter(v=>v.id!=='vt1')`);
  // idle lock
  E(`App.core.settings.idleMin=0.015`); E(`window.__idleArm(true)`); await sleep(1700); log('auto-lock fired', !!$('#login-pin'));
  log('errors', errors.filter(e => !/getContext/.test(e)));
  process.exit(0);
})().catch(e => { console.log('FAIL', e.stack); process.exit(1); });
