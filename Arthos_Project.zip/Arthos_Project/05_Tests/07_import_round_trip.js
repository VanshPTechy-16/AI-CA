const H = require('./harness');
(async () => {
  const log = (k, v) => console.log(k.padEnd(30), typeof v === 'string' ? v : JSON.stringify(v));
  const t = await H.make(); const { w, $, sleep, click, go, errors } = t; const E = s => w.eval(s);
  await H.loginDemo(t);
  // reference numbers from the loaded demo company
  const ref = E(`(()=>{ const fy=App.session.fy, r=fyRange(fy), pl=Rep.pl(fy,r.from,r.to), bs=Rep.bs(fy); return {posted:Books.posted().length, pbt:Math.round(pl.pbt), totA:Math.round(bs.totA), bsdiff:bs.diff} })()`); log('demo reference', ref);
  // export all sample files from the seed as xlsx (base64)
  const files = E(`(()=>{ const co=App.company; return Imp.files(co).map(f=>{ const wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(f.rows), 'S'); return {name:f.file+'.xlsx', b64: XLSX.write(wb,{bookType:'xlsx',type:'base64'})}; }) })()`);
  log('sample files exported', files.map(f => f.name));
  // new empty company in a fresh app instance (same company name/seed so ledgers match)
  const t2 = await H.make(); const W = t2.w, E2 = s => W.eval(s);
  const set = (id, v) => { t2.$('#' + id).value = v; t2.$('#' + id).dispatchEvent(new W.Event('input', { bubbles: true })); };
  t2.click('[data-act="ob-prof"][data-arg="pvt"]'); set('ob-name', 'Narmada Polymers Pvt Ltd'); set('ob-uname', 'Asha Rao'); set('ob-user', 'asha.r'); set('ob-pin', '5821'); set('ob-pin2', '5821'); t2.click('[data-act="ob-create"]'); await t2.sleep(500);
  log('empty company vouchers', E2('Books.cur().vouchers.length'));
  // sample files are generated per company id: use the NEW company's own sample files (what a user would download there)
  const files2 = E2(`(()=>{ const co=App.company; return Imp.files(co).map(f=>{ const wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(f.rows), 'S'); return {name:f.file+'.xlsx', b64: XLSX.write(wb,{bookType:'xlsx',type:'base64'})}; }) })()`);
  const seedRef = E2(`(()=>{ const s=Lab.get(App.company).seed.books; return {posted:s.vouchers.filter(v=>v.status==='posted').length, all:s.vouchers.length} })()`); log('new company seed', seedRef);
  const fl = files2.map(f => new W.File([Buffer.from(f.b64, 'base64')], f.name));
  await t2.go('import'); await E2(`Imp.run(${JSON.stringify([])})`);
  W.__files = fl; await E2(`Imp.run(window.__files)`); await t2.sleep(300);
  const res = E2('Imp.last.map(r=>[r.file, r.type, r.ok, r.msg.slice(0,110)])'); res.forEach(r => console.log(' ', r[2] ? 'OK  ' : 'FAIL', r[0].padEnd(28), r[1].padEnd(18), r[3]));
  const after = E2(`(()=>{ const fy=App.session.fy, r=fyRange(fy), b=Books.cur(), pl=Rep.pl(fy,r.from,r.to), bs=Rep.bs(fy), cf=Rep.cf(fy), tb=Rep.trial(fy).reduce((s,x)=>s+x.close,0); return {vouchers:b.vouchers.length, pbt:Math.round(pl.pbt), totA:Math.round(bs.totA), bsdiff:bs.diff, cfdiff:cf.diff, tbdiff:Math.round(tb*100)/100, parties:b.parties.length, emp:b.employees.length, assets:b.assets.length, items:b.items.length, gstr2b:(b.gstr2b||[]).length, bank:b.bankStmt&&b.bankStmt.rows.length} })()`);
  log('after import', after);
  // Modules still work on imported data
  const eng = E2(`(()=>{ const r=Risk.run(); const bk=BankRec.run(); return {risk:r.F.length, score:r.score, dup:Dup.scan().length, bankMatched:bk.matched.length, brsDiff:bk.brs.diff, ar:AR.risk().length, payroll:Payroll.run(iso(today0()).slice(0,7)).rows.length, tds:TaxAlerts.scan().length} })()`); log('engines on imported data', eng);
  for (const id of E2('MODULES.map(m=>m.id)')) { await t2.go(id); const x = t2.$('#view').textContent; if (/hit an error|NaN|undefined|\[object/.test(x)) log('SCREEN PROBLEM', id + ': ' + (x.match(/hit an error[^.]*|NaN|undefined|\[object Object\]/) || [''])[0]); }
  log('errors', t2.errors.filter(e => !/getContext/.test(e)).slice(0, 6));
  process.exit(0);
})().catch(e => { console.log('FAIL', e.stack); process.exit(1); });
