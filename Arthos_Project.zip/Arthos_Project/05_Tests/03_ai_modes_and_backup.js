const H = require('./harness');
const fakeAI = async (u, o) => { const b = JSON.parse(o.body || '{}'); const sys = String(b.system || ''); let text = 'Connected';
  if (/draft voucher/.test(sys)) text = '```json\n' + JSON.stringify({ type: 'Payment', narration: 'Rent paid for October', bankAcc: 'bank', acc: 'rent', amount: 25000, tdsSection: '194I', lines: [], assumptions: ['Landlord is an individual'], confidence: 'High' }) + '\n```';
  return { ok: true, status: 200, json: async () => ({ content: [{ type: 'text', text }] }) }; };
(async () => {
  const log = (k, v) => console.log(k.padEnd(24), typeof v === 'string' ? v : JSON.stringify(v));
  // A) preview mode with AI
  let t = await H.make({ fetch: fakeAI }); let { w, $, sleep, click, go, errors } = t; let E = s => w.eval(s);
  await H.loginDemo(t); await go('aistudio'); click('[data-act="st-tab"][data-arg="je"]'); await sleep(30);
  $('#je-t').value = 'Paid rent 25,000 via HDFC, deduct TDS'; click('[data-act="je-go"]'); await sleep(400);
  log('A: JE (AI)', E(`Studio.jeOut&&{type:Studio.jeOut.type, ai:Studio.jeOut.ai, err:Studio.jeOut.err, pre:Studio.jeOut.pre&&{acc:Studio.jeOut.pre.acc, amt:Studio.jeOut.pre.amount, tds:Studio.jeOut.pre.tdsSec}}`));
  click('[data-act="je-open"]'); await sleep(80); log('A: form opened w/ AI flag', E(`VForm.s&&{type:VForm.s.type, ai:VForm.s.ai, amount:VForm.s.amount}`));
  click('.modal footer [data-mi="1"]'); await sleep(300);
  log('A: AI voucher status', E(`(()=>{const v=Books.cur().vouchers.filter(x=>x.ai).pop(); return v&&{status:v.status, ai:v.ai, narr:v.narr.slice(0,40)}})()`));
  log('A: errors', errors.filter(e => !/getContext/.test(e)));
  // B) standalone (no window.storage), no API key -> fallbacks
  t = await H.make({ preview: false }); ({ w, $, sleep, click, go, errors } = t); E = s => w.eval(s);
  log('B: env', E('Env.label+" / "+Store.mode+" / ai ready="+AI.ready()'));
  await H.loginDemo(t); await go('aistudio'); click('[data-act="st-tab"][data-arg="je"]'); await sleep(30);
  $('#je-t').value = 'Paid rent 25,000 via HDFC, deduct TDS'; click('[data-act="je-go"]'); await sleep(200);
  log('B: JE rule fallback', E(`Studio.jeOut&&{type:Studio.jeOut.type, ai:Studio.jeOut.ai, err:Studio.jeOut.err, acc:Studio.jeOut.pre&&Studio.jeOut.pre.acc, amt:Studio.jeOut.pre&&Studio.jeOut.pre.amount}`));
  click('[data-act="copilot"]'); await sleep(40); log('B: copilot disabled', !!$('#cp-text').disabled);
  await go('settings'); log('B: key field', !!$('#api-key'));
  log('B: errors', errors.filter(e => !/getContext/.test(e)));
  // C) backup export/import round trip
  E(`window.__dl=[]; Files.download=(n,d)=>{window.__dl.push({n,txt:d})}`); click('[data-act="backup-export"]'); await sleep(100);
  const bk = E(`window.__dl[0]&&window.__dl[0].txt`); const o = JSON.parse(bk); log('C: backup', { keys: Object.keys(o), books: o.books && Object.keys(o.books).length, vouchers: o.books && Object.values(o.books)[0].vouchers.length, apiKeyBlank: o.core.settings.apiKey === '' });
  process.exit(0);
})().catch(e => { console.log('FAIL', e.stack); process.exit(1); });
