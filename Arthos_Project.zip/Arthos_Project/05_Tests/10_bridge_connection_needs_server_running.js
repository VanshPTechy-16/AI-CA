const H = require('./harness');
(async () => {
  const t = await H.make({ preview: false, fetch: (u, o) => fetch(u, o) }); const { w, $, sleep, click, go, errors } = t; const E = s => w.eval(s);
  await H.loginDemo(t); const log = (k, v) => console.log(k.padEnd(26), typeof v === 'string' ? v : JSON.stringify(v));
  log('before: AI ready', E('AI.ready()'));
  await go('settings'); $('#bridge').value = 'http://localhost:8799'; $('#bridge-token').value = 'wrong'; click('[data-act="bridge-save"]'); await sleep(500);
  log('wrong token toast', [...w.document.querySelectorAll('.toast')].map(x => x.textContent).pop());
  await go('settings'); $('#bridge').value = 'http://localhost:8799'; $('#bridge-token').value = 't1'; click('[data-act="bridge-save"]'); await sleep(500);
  log('good token toast', [...w.document.querySelectorAll('.toast')].map(x => x.textContent).pop());
  log('after: AI ready', E('AI.ready()'));
  const r = await E(`(async()=>{ try { await AI.call({messages:[{role:'user',content:'hi'}]}); return 'OK?' } catch(e){ return e.message } })()`); log('AI via bridge (no key)', r);
  const m = await E(`(async()=>{ try { await Bridge.mail({to:'a@b.in',subject:'x',body:'y'}); return 'sent?' } catch(e){ return e.message } })()`); log('mail via bridge (no SMTP)', m);
  click('[data-act="copilot"]'); await sleep(40); log('copilot enabled w/ bridge', !$('#cp-text').disabled);
  log('errors', errors.filter(e => !/getContext/.test(e)));
  process.exit(0);
})().catch(e => { console.log('FAIL', e.stack); process.exit(1); });
