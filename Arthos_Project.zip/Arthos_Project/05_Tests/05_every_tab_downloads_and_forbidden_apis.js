const H = require('./harness');
(async () => {
  const log = (k, v) => console.log(k.padEnd(26), typeof v === 'string' ? v : JSON.stringify(v));
  const t = await H.make(); const { w, $, sleep, click, go, errors } = t; const E = s => w.eval(s);
  await H.loginDemo(t);
  E(`window.__dl=[]; Files.download=(n,d)=>{window.__dl.push({n,size:(d&&d.size)||String(d).length})}`);
  const bad = [];
  for (const id of E('MODULES.map(m=>m.id)')) {
    await go(id);
    const tabs = [...new Set([...w.document.querySelectorAll('#view [data-act$="-tab"]')].map(e => e.dataset.act + '|' + e.dataset.arg))];
    for (const tb of tabs) { const [a, arg] = tb.split('|'); const el = w.document.querySelector(`#view [data-act="${a}"][data-arg="${arg}"]`); if (!el) continue; click(el); await sleep(25);
      const x = $('#view').textContent; if (/hit an error|NaN|undefined|\[object/.test(x) || x.length < 120) bad.push(id + '/' + arg + ' -> ' + (x.match(/hit an error[^.]*|NaN|undefined|\[object Object\]/) || ['short'])[0]); }
    if (!tabs.length) { const x = $('#view').textContent; if (/NaN|undefined|\[object/.test(x)) bad.push(id + ' -> NaN/undefined'); }
  }
  log('tab sweep problems', bad.length ? bad : 'none');
  // Test lab
  await go('lab'); click('[data-act="lab-pack"]'); await sleep(1500); log('lab pack', E('window.__dl.map(x=>x.n+" ("+x.size+")")'));
  const zip = await E(`(async()=>{ const d=Lab.get(App.company); const files=Lab.files? Lab.files(App.company):null; return files? files.map(f=>f.name):Object.keys(d) })()`); log('lab files', zip);
  // HTML safety greps
  const html = require('fs').readFileSync(require('path').join(__dirname, '..', '01_App', 'arthos.html'), 'utf8');
  log('localStorage use', (html.match(/localStorage|sessionStorage/g) || []).length);
  log('<form tags', (html.match(/<form[ >]/g) || []).length);
  log('size KB', Math.round(html.length / 1024));
  log('errors', errors.filter(e => !/getContext/.test(e)).slice(0, 6));
  process.exit(0);
})().catch(e => { console.log('FAIL', e.stack); process.exit(1); });
