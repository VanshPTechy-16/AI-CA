const H = require('./harness');
(async () => {
  const t = await H.make(); const { w, $, sleep, click, go, setv, errors } = t; const E = s => w.eval(s);
  await H.loginDemo(t);
  const log = (k, v) => console.log(k.padEnd(26), typeof v === 'string' ? v : JSON.stringify(v));
  // 1. Journal via real form
  await go('vouchers'); click('[data-act="v-new"][data-arg="Journal"]'); await sleep(80);
  log('form opened', !!$('#vf-type'));
  setv('[data-l="0:acc"]', 'rent', 'change'); setv('[data-l="0:dr"]', '75000'); setv('[data-l="1:acc"]', 'bank', 'change'); setv('[data-l="1:cr"]', '75000'); setv('[data-f="narr"]', 'Test rent journal'); await sleep(50);
  log('summary shows', ($('#vf-sum')?.textContent || '').replace(/\s+/g, ' ').slice(0, 160));
  log('button label', $('.modal footer [data-mi="1"]').textContent);
  click('.modal footer [data-mi="1"]'); await sleep(300);
  const j = E(`(()=>{const v=Books.cur().vouchers.filter(x=>x.narr==='Test rent journal')[0]; return v&&{no:v.no,status:v.status,maker:v.maker}})()`); log('journal saved', j);
  // 2. Self approval blocked
  log('Riya approve own', E(`Ctl.whyNot(Books.cur().vouchers.find(x=>x.narr==='Test rent journal'))`) || 'ALLOWED?!');
  // 3. Neha approves
  click('[data-act="user-menu"]'); await sleep(10); click('.menu [data-act="signout"]'); await sleep(80);
  { const c = w.document.querySelector('.co-card'); if (c) { click(c); await sleep(40); } } click(w.document.querySelectorAll('.upick')[2]); $('#login-pin').value = '3333'; click('[data-act="wl-go"]'); await sleep(500);
  await go('approvals'); const pend = w.document.querySelectorAll('#view [data-act="v-approve"]').length; log('Neha inbox items', pend);
  const id = E(`Books.cur().vouchers.find(x=>x.narr==='Test rent journal').id`);
  click(`[data-act="v-approve"][data-arg="${id}"]`); await sleep(300);
  log('after approve', E(`(()=>{const v=Books.cur().vouchers.find(x=>x.id==='${id}'); return {status:v.status, checker:v.checker}})()`));
  const big = E(`(()=>{const v=Books.cur().vouchers.find(x=>x.status==='pending'&&Books.amt(x)>500000); return v?{no:v.no,amt:Books.amt(v),why:Ctl.whyNot(v)}:null})()`); log('over-limit bill (Neha)', big);
  await go('approvals'); const rb=w.document.querySelector('#view [data-act="v-reject"]'); const rejId=rb.dataset.arg; log('reject btn visible', !!rb); click(rb); await sleep(60);
  setv('#rj', 'Wrong vendor selected, please re-enter'); click('.modal footer [data-mi="1"]'); await sleep(250);
  log('after reject', E(`Books.cur().vouchers.find(x=>x.id==='${rejId}').status`));
  click('[data-act="user-menu"]'); await sleep(10); click('.menu [data-act="signout"]'); await sleep(80); { const c = w.document.querySelector('.co-card'); if (c) { click(c); await sleep(40); } } click(w.document.querySelectorAll('.upick')[0]); $('#login-pin').value='1234'; click('[data-act="wl-go"]'); await sleep(500);
  // 4. Period lock
  E(`Books.cur().controls.lockDate='2026-06-30'`);
  await go('vouchers'); click('[data-act="v-new"][data-arg="Journal"]'); await sleep(60);
  setv('[data-f="date"]', '2026-06-10'); setv('[data-l="0:acc"]', 'rent', 'change'); setv('[data-l="0:dr"]', '1000'); setv('[data-l="1:acc"]', 'bank', 'change'); setv('[data-l="1:cr"]', '1000'); await sleep(40);
  log('lock message', ($('#vf-sum')?.textContent || '').match(/Blocked[^.]*\./)?.[0] || 'NO BLOCK');
  click('.modal [data-close]');
  // 5. Sales invoice via form + invoice tools
  E(`Books.cur().controls.lockDate=''`);
  click('[data-act="v-new"][data-arg="Sales"]'); await sleep(60);
  setv('[data-f="party"]', 'C003', 'change'); setv('[data-i="0:desc"]', 'HDPE granules'); setv('[data-i="0:qty"]', '100'); setv('[data-i="0:rate"]', '120'); await sleep(50);
  log('sales preview', ($('#vf-sum')?.textContent || '').replace(/\s+/g, ' ').slice(0, 220));
  click('.modal [data-close]');
  // 6. invoice outputs
  const sid = E(`Books.cur().vouchers.find(x=>x.type==='Sales'&&x.status==='posted').id`);
  log('Invoice api', E(`Object.keys(Invoice)`));
  console.log('ERRORS', errors.filter(e => !/getContext/.test(e)).slice(0, 8)); process.exit(0);
})().catch(e => { console.log('FAIL', e.stack); process.exit(1); });
