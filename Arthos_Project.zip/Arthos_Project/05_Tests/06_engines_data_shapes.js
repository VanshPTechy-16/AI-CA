const H = require('./harness');
(async () => {
  const t = await H.make(); const { w, errors } = t; await H.loginDemo(t);
  const E = s => w.eval(s);
  const shape = (name, expr) => { try { const r = E(`(()=>{ const x=(${expr}); const f=v=>Array.isArray(v)?'arr['+v.length+']':(v&&typeof v==='object'?'{'+Object.keys(v).join(',')+'}':typeof v==='number'?Math.round(v*100)/100:String(v).slice(0,50)); return x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.entries(x).map(([k,v])=>[k,f(v)])):f(x) })()`); console.log(name.padEnd(14), JSON.stringify(r)); } catch (e) { console.log(name.padEnd(14), 'THROWS', e.message); } };
  shape('BankRec.run', 'BankRec.run()'); shape('Risk.run', 'Risk.run()'); shape('Risk.benford', 'Risk.benford()');
  shape('Dup.scan', 'Dup.scan()'); shape('TaxAlerts.scan', 'TaxAlerts.scan()'); shape('itcRev', 'TaxAlerts.itcReversals()');
  shape('AR.ageing', "AR.ageing('C')"); shape('AR.risk', "AR.risk()"); shape('Fc.run', 'Fc.run({})');
  shape('Payroll.run', "Payroll.run(iso(today0()).slice(0,7))"); shape('Close keys', 'Object.keys(Close)');
  shape('tax', "IncomeTax.compute({gross:1200000,regime:'new'})");
  console.log('ERRORS', errors.filter(e => !/getContext/.test(e)).slice(0, 6)); process.exit(0);
})().catch(e => { console.log('FAIL', e.stack); process.exit(1); });
