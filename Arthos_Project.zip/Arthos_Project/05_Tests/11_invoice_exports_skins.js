const H = require('./harness');
(async () => {
  const t = await H.make(); const { w, $, sleep, click, go, setv, errors } = t; const E = s => w.eval(s);
  await H.loginDemo(t);
  const log = (k, v) => console.log(k.padEnd(24), typeof v === 'string' ? v : JSON.stringify(v));
  const sid = E(`Books.cur().vouchers.find(x=>x.type==='Sales'&&x.status==='posted').id`);
  await go('o2c'); click(`[data-act="inv-open"][data-arg="${sid}"]`); await sleep(120);
  log('invoice modal', !!$('.inv'));
  for (const tpl of ['classic','modern','minimal','compact','bold']) { E(`Inv.tpl='${tpl}'`); }
  E(`window.__dl=[]; Files.download=(n,d,m)=>{ window.__dl.push({n, size:(d&&d.size)||String(d).length, txt:(typeof d==='string'?d:null)}); }`);
  E(`Books.cur().parties.find(p=>p.id===Books.vch('${sid}').meta.party).gstin='24AAACN1234A1Z5'`);
  E(`App.company.gstin=GST.make('24','AAACN1234A')`);
  for (const f of ['einv','eway','pdf']) { try { E(`Invoice.${f}(Books.vch('${sid}'), 'bold')`); } catch (e) { log(f+' ERR', e.message); } await sleep(150); }
  log('downloads', E(`window.__dl.map(x=>x.n+' ('+x.size+')')`));
  const ej = E(`(window.__dl.find(x=>/\.json$/.test(x.n))||{}).txt`); if (ej) { try { const o = JSON.parse(ej); log('json keys', Object.keys(o).slice(0,8)); } catch(e){ log('json parse', 'bad'); } }
  // reports + exports
  await go('reports'); for (const tab of ['tb','pl','bs','cf','ratios']) { click(`[data-act="rep-tab"][data-arg="${tab}"]`); await sleep(40); const txt=$('#view').textContent; log('report '+tab, txt.length + ' chars; ' + (txt.match(/Total|Profit|Assets|operating/i)||[''])[0]); }
  click('[data-act="rep-tab"][data-arg="bs"]'); await sleep(20); click('[data-act="bs-fmt"]'); await sleep(30); log('bs horizontal', !!$('.hz'));
  click('[data-act="rep-tab"][data-arg="pl"]'); await sleep(20);
  const exps = [...w.document.querySelectorAll('#view [data-act^="exp"]')].map(e=>e.dataset.act+':'+e.dataset.arg); log('export buttons', exps.slice(0,6));
  if (exps.length) { const [a, arg] = exps[0].split(':'); click(`[data-act="${a}"][data-arg="${arg}"]`); await sleep(200); }
  const [xa, xarg] = (exps.find(x=>/xlsx/.test(x))||'').split(':'); if (xa) { click(`[data-act="${xa}"][data-arg="${xarg}"]`); await sleep(200); }
  const pdfx = exps.find(x=>/pdf/.test(x)); if (pdfx) { const [pa,parg]=pdfx.split(':'); click(`[data-act="${pa}"][data-arg="${parg}"]`); await sleep(300); }
  // skins
  const seen = [];
  for (let i = 0; i < 5; i++) { click('[data-act="skin-next"]'); await sleep(30); seen.push(w.document.documentElement.dataset.skin + '/' + w.document.documentElement.dataset.theme); }
  log('skin cycle', seen);
  await go('settings'); click('[data-act="skin-set"][data-arg="aurora"]'); await sleep(40); log('aurora set', w.document.documentElement.dataset.skin);
  log('settings skins', w.document.querySelectorAll('#view .skin').length);
  click('[data-act="skin-set"][data-arg="ledger"]'); await sleep(20);
  // backup roundtrip
  const bk = E(`(()=>{ const core=JSON.parse(JSON.stringify(App.core)); return {companies:core.companies.length, vouchers:Books.cur().vouchers.length} })()`); log('before backup', bk);
  console.log('ERRORS', errors.filter(e => !/getContext/.test(e)).slice(0, 8)); process.exit(0);
})().catch(e => { console.log('FAIL', e.stack); process.exit(1); });
