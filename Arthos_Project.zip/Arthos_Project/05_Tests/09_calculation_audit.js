const H = require('./harness');
(async () => {
  const t = await H.make(); const { w, errors } = t; await H.loginDemo(t); const E = s => w.eval(s);
  const chk = (name, got, exp, tol = 1) => { const ok = Math.abs(got - exp) <= tol; console.log((ok ? 'PASS ' : 'FAIL ') + name.padEnd(46) + ' got ' + got + (ok ? '' : '  expected ' + exp)); return ok; };
  const T = (g, r, x = {}) => E(`IncomeTax.compute(Object.assign({gross:${g},regime:'${r}'},${JSON.stringify(x)})).total`);
  chk('New regime ₹12.75L salary -> nil (87A)', T(1275000, 'new'), 0);
  chk('New regime ₹13L -> marginal relief 25,000+cess', T(1300000, 'new'), 26000);
  chk('New regime ₹20L (1,85,000 + cess)', T(2000000, 'new'), 192400, 1);
  chk('Old regime ₹15L, 80C 1.5L (2,02,500 + cess)', T(1500000, 'old', { c80: 150000 }), 210600, 1);
  chk('Old regime ₹5.5L: taxable 5L -> rebate -> nil', T(550000, 'old'), 0, 0);
  chk('Old regime ₹8L, no ded', T(800000, 'old'), Math.round((12500 + (750000-500000)*0.20)*1.04), 1);
  chk('New regime ₹60L surcharge 10%', T(6000000, 'new'), (()=>{ const tx=5925000; let tax=20000+40000+60000+80000+100000+ (tx-2400000)*0.30; return Math.round(tax*1.10*1.04) })(), 50);
  // payroll
  const emp = `{id:'x',name:'T',gross:20000,basicPct:50,state:'24',regime:'new',doj:'2020-01-01'}`;
  const p = E(`(()=>{ const r=Payroll.calc(${emp}, '2026-10', null, '24'); return {ee:r.ee, er:r.er, esiEE:r.esiEE, esiER:r.esiER, pt:r.pt, g:r.g, basic:r.basic} })()`);
  chk('PF employee 12% of ₹10,000 basic', p.ee, 1200, .01); chk('PF employer 12%', p.er, 1200, .01);
  chk('ESI employee 0.75% of ₹20,000', p.esiEE, 150, 1); chk('ESI employer 3.25% of ₹20,000', p.esiER, 650, 1);
  chk('PT Gujarat ₹20,000 gross', p.pt, 200, 0);
  const p2 = E(`(()=>{ const r=Payroll.calc({id:'y',name:'T',gross:60000,basicPct:50,regime:'new'}, '2026-10', null, '24'); return {ee:r.ee, esiEE:r.esiEE, pt:r.pt} })()`);
  chk('PF capped at ceiling ₹15,000 (basic 30k) = 1,800', p2.ee, 1800, .01); chk('No ESI above ₹21,000', p2.esiEE, 0, 0);
  // depreciation
  console.log('FA api', JSON.stringify(E('Object.keys(FA)')), JSON.stringify(E('CONFIG.fa||CONFIG.dep||null')));
  // TDS rate
  chk('TDS 194C individual PAN (…P…) 1%', E(`TaxAlerts.rate('194C','ABCPE1234F')`), 1, 0);
  chk('TDS 194C company PAN 2%', E(`TaxAlerts.rate('194C','ABCCE1234F')`), 2, 0);
  chk('TDS 194J 10%', E(`TaxAlerts.rate('194J','ABCCE1234F')`), 10, 0);
  chk('TDS no PAN -> 20% (206AA)', E(`TaxAlerts.rate('194J','')`), 20, 0);
  chk('TDS 194I rent 10%', E(`TaxAlerts.rate('194I','ABCCE1234F')`), 10, 0);
  // GSTIN
  chk('GSTIN valid sample', E(`GST.validate(GST.make('24','AAACN1234A')).ok?1:0`), 1, 0);
  chk('GSTIN wrong checksum rejected', E(`GST.validate('24AAACN1234A1Z5').ok?1:0`), 0, 0);
  // GST split
  console.log('GST cfg', JSON.stringify(E('CONFIG.gst')));
  console.log('TDS cfg', JSON.stringify(E('CONFIG.tds.map(t=>[t.sec,t.rate,t.single,t.annual])')));
  console.log('ERR', errors.filter(e=>!/getContext/.test(e)));
  process.exit(0);
})().catch(e => { console.log('FAIL', e.stack); process.exit(1); });
