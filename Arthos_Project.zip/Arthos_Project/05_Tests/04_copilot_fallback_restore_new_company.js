const H = require('./harness');
(async () => {
  const log = (k, v) => console.log(k.padEnd(26), typeof v === 'string' ? v : JSON.stringify(v));
  let t = await H.make({ preview: false }); let { w, $, sleep, click, go, errors } = t; const E = s => w.eval(s);
  await H.loginDemo(t);
  click('[data-act="copilot"]'); await sleep(40);
  $('#cp-text').value = 'Who are my top customers by outstanding?'; click('[data-act="cp-send"]'); await sleep(300);
  log('fallback answer', [...w.document.querySelectorAll('.msg.ai')].map(m => m.textContent.replace(/\s+/g, ' ').slice(0, 220)));
  $('#cp-text').value = 'What is my cash balance?'; click('[data-act="cp-send"]'); await sleep(300);
  log('cash answer', [...w.document.querySelectorAll('.msg.ai')].pop().textContent.replace(/\s+/g, ' ').slice(0, 160));
  // backup -> reset -> import
  click('[data-act="copilot"]'); await go('settings');
  E(`window.__dl=[]; Files.download=(n,d)=>{window.__dl.push({n,txt:d})}`); click('[data-act="backup-export"]'); await sleep(100);
  const bk = E(`window.__dl[0].txt`);
  const before = E('Books.cur().vouchers.length');
  E(`App.books={}; App.core=blankCore()`);
  // simulate import handler
  const file = new w.File([bk], 'b.json', { type: 'application/json' }); const inp = w.document.createElement('input'); inp.type = 'file'; inp.dataset.change = 'backup-import';
  Object.defineProperty(inp, 'files', { value: [file] }); w.document.body.appendChild(inp);
  inp.dispatchEvent(new w.Event('change', { bubbles: true })); await sleep(300);
  log('import modal', !!$('.modal') && $('.modal').textContent.slice(0, 80));
  const btn = [...w.document.querySelectorAll('.modal footer button')].pop(); if (btn) click(btn); await sleep(600);
  log('after restore', E(`(()=>{ const id=App.core.companies[0]&&App.core.companies[0].id; return {companies:App.core.companies.length, vouchers: id&&App.books[id]?App.books[id].vouchers.length:null, before:${before}} })()`));
  log('login screen shown', !!$('#login-pin'));
  // custom company: onboarding path then seed sample books
  t = await H.make(); ({ w, $, sleep, click, go, errors } = t); const E2 = s => w.eval(s);
  const set = (id, v) => { $('#' + id).value = v; $('#' + id).dispatchEvent(new w.Event('input', { bubbles: true })); };
  click('[data-act="ob-prof"][data-arg="proprietor"]'); set('ob-name', 'Kutch Traders'); set('ob-uname', 'Asha Rao'); set('ob-user', 'asha.r'); set('ob-pin', '5821'); set('ob-pin2', '5821');
  click('[data-act="ob-create"]'); await sleep(500);
  log('new co: empty books', E2(`Books.cur().vouchers.length`));
  await go('vouchers'); log('empty state', $('#view').textContent.replace(/\s+/g, ' ').slice(0, 220));
  await go('dashboard'); log('dashboard h1', $('#view h1').textContent);
  E2(`Actions['seed-books']()`); await sleep(300);
  const c = [...w.document.querySelectorAll('.modal footer button')].pop(); if (c && /load|replace|sample|yes/i.test(c.textContent)) click(c); await sleep(900);
  log('new co: after seed', E2(`(()=>{ const b=Books.cur(); const bs=Rep.bs(App.session.fy); return {v:b.vouchers.length, bsDiff:bs.diff, unb:b.vouchers.filter(v=>Math.abs(v.lines.reduce((s,l)=>s+l.dr-l.cr,0))>0.01).length} })()`));
  log('errors', errors.filter(e => !/getContext/.test(e)).slice(0, 6));
  process.exit(0);
})().catch(e => { console.log('FAIL', e.stack); process.exit(1); });
