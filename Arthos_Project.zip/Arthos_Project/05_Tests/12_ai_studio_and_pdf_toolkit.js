const H = require('./harness');
const fakeAI = async (u, o) => { const b = JSON.parse(o.body || '{}'); const sys = String(b.system || '') + JSON.stringify(b.messages || '').slice(0, 400); let text = 'Connected';
  if (/journal|voucher|Paid rent/i.test(sys) && /JSON/i.test(sys)) text = JSON.stringify({ type: 'Payment', date: '2026-10-28', narration: 'Rent paid', lines: [{ acc: 'rent', dr: 25000, cr: 0 }, { acc: 'bank', dr: 0, cr: 22500 }, { acc: 'tds_p', dr: 0, cr: 2500 }], checks: ['TDS 194I at 10%'], assumptions: ['Landlord is an individual'], confidence: 0.82 });
  return { ok: true, status: 200, json: async () => ({ content: [{ type: 'text', text }] }) }; };
(async () => {
  const t = await H.make({ fetch: fakeAI }); const { w, $, sleep, click, go, setv, errors } = t; const E = s => w.eval(s);
  await H.loginDemo(t); const log = (k, v) => console.log(k.padEnd(24), typeof v === 'string' ? v : JSON.stringify(v));
  log('AI status after login', E('AI.status'));
  // Copilot
  click('[data-act="copilot"]'); await sleep(50); $('#cp-text').value = 'Why did profit change?'; click('[data-act="cp-send"]'); await sleep(250);
  log('copilot msgs', w.document.querySelectorAll('.msg').length);
  log('copilot ctx has books', /revenue|Revenue|ledger/.test(E('Copilot.context()')));
  click('[data-act="copilot"]');
  // AI studio JE
  await go('aistudio'); log('studio tabs', [...w.document.querySelectorAll('#view [data-act="st-tab"]')].map(e=>e.dataset.arg));
  E(`App.ui.jeText='Paid rent 25,000 via HDFC, deduct TDS'`); await E(`Actions['je-go']()`); await sleep(300);
  log('JE out', E(`Studio.jeOut&&{type:Studio.jeOut.type, lines:(Studio.jeOut.pre&&Studio.jeOut.pre.lines||[]).length, ai:Studio.jeOut.ai, err:Studio.jeOut.err}`));
  // Other tabs render
  for (const tb of ['je','tr','bill','notice','mis','law']) { click(`[data-act="st-tab"][data-arg="${tb}"]`); await sleep(30); const x=$('#view').textContent; if (/hit an error/.test(x)) log('TAB ERROR', tb); }
  // Bill sample, notice sample
  log('Samples api', E('Object.keys(Samples)')); log('Studio keys', E('Object.keys(Studio)'));
  // Docs toolkit with pdf-lib
  await go('docs'); log('tool cards', w.document.querySelectorAll('#view .card').length);
  const pdfTest = await E(`(async()=>{ const {PDFDocument}=PDFLib; const mk=async n=>{const d=await PDFDocument.create(); for(let i=0;i<n;i++) d.addPage([300,300]); return await d.save()}; const a=await mk(2), b=await mk(3); const out=await PDFDocument.create(); for(const buf of [a,b]){ const s=await PDFDocument.load(buf); (await out.copyPages(s,s.getPageIndices())).forEach(p=>out.addPage(p)); } return out.getPageCount() })()`); log('pdf-lib merge pages', pdfTest);
  log('Tk keys', E('Object.keys(Tk)'));
  // Law watch + settings
  console.log('ERRORS', errors.filter(e => !/getContext/.test(e)).slice(0, 8)); process.exit(0);
})().catch(e => { console.log('FAIL', e.stack); process.exit(1); });
