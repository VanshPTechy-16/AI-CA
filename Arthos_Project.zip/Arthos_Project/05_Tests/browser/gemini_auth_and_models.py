# Gemini API check with a mocked Google endpoint: AQ. auth key in x-goog-api-key header, Gemini 3.x request body, error messages, model fallback.
import sys, os, time, json
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
reqs=[]; mode={'v':'ok'}
def handler(route):
    r=route.request; u=r.url
    if 'generativelanguage.googleapis.com' in u:
        b=json.loads(r.post_data); reqs.append((u, r.headers.get('x-goog-api-key'), b))
        m=mode['v']
        if m=='401': return route.fulfill(status=401, json={'error':{'code':401,'message':'Request had invalid authentication credentials.','status':'UNAUTHENTICATED','details':[{'reason':'ACCESS_TOKEN_TYPE_UNSUPPORTED'}]}})
        if m=='404' and 'gemini-3.8-flash' in u: return route.fulfill(status=404, json={'error':{'code':404,'message':'models/x is not found','status':'NOT_FOUND'}})
        return route.fulfill(status=200, json={'candidates':[{'content':{'parts':[{'text':'thinking...','thought':True},{'text':'Connected'}]},'finishReason':'STOP'}]})
    if u.startswith(('file:','data:','blob:')): return route.continue_()
    route.abort()
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1400,'height':900}); errs=[]
    pg.on('pageerror', lambda e: errs.append(str(e)[:200])); pg.route('**/*', handler)
    toasts=lambda: pg.evaluate("[...document.querySelectorAll('#toasts .toast')].map(t=>t.className.replace('toast ','')+': '+t.textContent)")
    pg.goto(APP); pg.wait_for_selector('[data-act="ob-demo"]'); pg.click('[data-act="ob-demo"]'); pg.wait_for_selector('.upick'); pg.fill('#login-pin','1234'); pg.click('[data-act="wl-go"]'); pg.wait_for_selector('#view h1'); time.sleep(.8)
    pg.evaluate("App.core.settings.geminiModel='gemini-2.5-flash'; Router.go('settings')"); time.sleep(.8)
    pg.evaluate("Actions['ai-provider']('gemini')"); time.sleep(.5)
    print('model after migrate', pg.evaluate("Gem.model()"), '| options', pg.evaluate("[...document.querySelectorAll('#gm-model option')].map(o=>o.value)"))
    pg.fill('#gm-key','sk-wrong'); pg.click('[data-act=gem-save]'); time.sleep(.4); print('bad key ->', toasts()[-1:])
    pg.fill('#gm-key','AQ.Ab8RN6Kx_TestKeyFor-Arthos.1234567890abcdef'); pg.click('[data-act=gem-save]'); time.sleep(1.2)
    u,k,bd=reqs[-1]; print('AQ key ->', toasts()[-1:]); print('  url', u); print('  header key', k[:6]+'…'); print('  key in URL?', 'key=' in u); print('  body', json.dumps(bd)[:300])
    print('  temperature present?', 'temperature' in json.dumps(bd), '| thinkingBudget?', 'thinkingBudget' in json.dumps(bd))
    # trailing model turn stripped
    pg.evaluate("Gem.call({messages:[{role:'user',content:'hi'},{role:'assistant',content:'prefill'}]})"); time.sleep(.5); print('  last role', reqs[-1][2]['contents'][-1]['role'])
    mode['v']='404'; r=pg.evaluate("Gem.call({messages:[{role:'user',content:'x'}]}).then(d=>'ok '+Gem.model()).catch(e=>'ERR '+e.message)"); print('404 fallback ->', r, [q[0].split('/')[-1] for q in reqs[-2:]])
    pg.evaluate("App.core.settings.geminiModel='gemini-3.8-flash'")
    mode['v']='401'; r=pg.evaluate("Gem.call({messages:[{role:'user',content:'x'}]}).then(()=> 'ok').catch(e=>e.message)"); print('401 ->', r)
    mode['v']='ok'; pg.evaluate("Router.render()"); time.sleep(.3)
    pg.fill('#gm-key','AIzaSyD-OldStandardKey1234567890abcdefg'); pg.click('[data-act=gem-save]'); time.sleep(1); print('AIza ->', [t for t in toasts() if 'AIza' in t][-1:])
    pg.select_option('#gm-think','high'); pg.fill('#gm-custom','gemini-3.7-flash'); pg.click('[data-act=gem-save]'); time.sleep(1); print('custom ->', pg.evaluate("[Gem.model(),Gem.think()]"), reqs[-1][0].split('/')[-1], reqs[-1][2]['generationConfig'])
    
    print('errors', errs); b.close()
