import sys, os, time
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
reqs=[]; errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':1440,'height':900}, accept_downloads=True); pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)[:160]))
    pg.route('**/*',block_network)
    pg.goto(APP); pg.wait_for_selector('[data-act="ob-demo"]')
    libs=pg.evaluate("['Chart','XLSX','JSZip','marked','DOMPurify','PDFLib','jspdf','qrcode'].map(n=>n+':'+(typeof window[n]!=='undefined'))")
    print('libs loaded with NO network:', libs)
    pg.click('[data-act="ob-demo"]'); pg.wait_for_selector('.upick'); pg.fill('#login-pin','1234'); pg.click('[data-act="wl-go"]'); pg.wait_for_selector('#view h1'); time.sleep(1.2)
    print('chart drawn:', pg.evaluate("!!document.querySelector('#dash-chart')&&!!App.chart"))
    def grab(label, js):
        try:
            with pg.expect_download(timeout=20000) as d: pg.evaluate(js)
            dl=d.value; path=OUT+'/off_'+dl.suggested_filename; dl.save_as(path); print('OK  ',label.ljust(14),dl.suggested_filename,os.path.getsize(path),'bytes')
        except Exception as e: print('FAIL',label,str(e)[:80])
    pg.evaluate("Router.go('reports')"); time.sleep(.5); pg.evaluate("Actions['rep-tab']('pl')"); time.sleep(.4)
    for fmt in ['pdf','xlsx']:
        try:
            with pg.expect_download(timeout=15000) as d: pg.click(f'#view [data-act="exp"][data-arg="pl|{fmt}"]')
            print('OK   P&L',fmt,d.value.suggested_filename)
        except Exception as e: print('FAIL P&L',fmt)
    pg.evaluate("Router.go('lab')"); time.sleep(.4); grab('demo pack ZIP',"Actions['lab-pack']()")
    sid=pg.evaluate("(()=>{App.company.upi='narmada@hdfcbank'; return Books.cur().vouchers.find(x=>x.type==='Sales'&&x.status==='posted').id})()")
    print('invoice QR svg:', pg.evaluate(f"Invoice.html(Books.vch('{sid}'),'modern').includes('<svg')"))
    grab('invoice PDF', f"Invoice.pdf(Books.vch('{sid}'),'modern')")
    # persistence across reload (IndexedDB)
    time.sleep(1.0); pg.reload(); pg.wait_for_selector('.co-card', timeout=8000); pg.click('.co-card'); pg.wait_for_selector('#login-pin', timeout=8000)
    pg.fill('#login-pin','1234'); pg.click('[data-act="wl-go"]'); pg.wait_for_selector('#view h1'); time.sleep(.8)
    print('after reload vouchers persisted:', pg.evaluate("Books.cur().vouchers.length"), '| audit entries:', pg.evaluate("App.log.length"))
    print('network requests attempted (all blocked):', reqs or 'none'); print('page errors:', errs or 'none'); b.close()
