"""Uploads the shipped sample files into a BLANK company through the real upload button."""
import sys, os, time, glob
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
S = os.path.join(ROOT, '06_Sample_Data')
def up(pg, *rel):
    fs = [os.path.join(S, r) for r in rel]; pg.set_input_files('input[data-change="smart-file"]', fs); time.sleep(1.2)
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width':1440,'height':950}).new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:300])); pg.route('**/*', block_network)
    pg.goto(APP); pg.wait_for_selector('[data-act="ob-create"]'); pg.click('[data-act="ob-prof"][data-arg="pvt"]'); pg.fill('#ob-name','Narmada Polymers Pvt Ltd'); pg.fill('#ob-uname','Asha Rao'); pg.fill('#ob-user','asha.r'); pg.fill('#ob-pin','5821'); pg.fill('#ob-pin2','5821'); pg.click('[data-act="ob-create"]'); pg.wait_for_selector('#view h1'); time.sleep(.5)
    print('blank company vouchers:', pg.evaluate("Books.cur().vouchers.length"))
    step = lambda label: print(f'  {label:<34}', pg.evaluate("({v:Books.cur().vouchers.length, parties:Books.cur().parties.length, emp:Books.cur().employees.length, assets:Books.cur().assets.length, items:Books.cur().items.length, bank:Books.cur().bankStmt?Books.cur().bankStmt.rows.length:0, g2b:(Books.cur().gstr2b||[]).length, leads:(Books.cur().leads||[]).length, tickets:(Books.cur().tickets||[]).length})"))
    up(pg, '01_Masters/Vendor_Master.xlsx', '01_Masters/Customer_Master.xlsx', '01_Masters/Opening_Balances.xlsx'); step('masters and opening balances')
    up(pg, '05_Vouchers_and_Journals/Journal_Dump.csv', '04_Purchases/Purchase_Register.xlsx'); step('journal and purchase register')
    ok = pg.evaluate("(()=>{ const fy=App.session.fy; return {tbDiff:Math.round(Rep.trial(fy).reduce((s,x)=>s+x.close,0)*100)/100, bsDiff:Rep.bs(fy).diff, unbalanced:Books.cur().vouchers.filter(v=>Math.abs(v.lines.reduce((s,l)=>s+l.dr-l.cr,0))>0.01).length}})()"); print('  integrity after import:', ok)
    up(pg, '01_Masters/Employees.xlsx', '01_Masters/Fixed_Assets.xlsx', '01_Masters/Stock_Count.xlsx', '07_GST_and_Tax/GSTR2B.xlsx', '03_Sales/CRM/Leads.xlsx', '03_Sales/CRM/Support_Tickets.xlsx'); step('operations, GSTR-2B, CRM')
    for f in ['02_Bank_Statements/Bank_Statement_SBI_layout.csv', '02_Bank_Statements/Bank_Statement_ICICI_layout.xlsx', '02_Bank_Statements/Bank_Statement_HDFC.xlsx']:
        up(pg, f); r = pg.evaluate("({rows:Stm.rows.length, src:Stm.src, todo:Stm.rows.filter(r=>!r.inBooks).length, warn:Stm.warn.length})"); print('  statement', os.path.basename(f).ljust(38), r)
    up(pg, '02_Bank_Statements/Bank_Statement_HDFC_text_PDF.pdf'); time.sleep(1.5); print('  statement PDF:', pg.evaluate("({rows:Stm.rows.length, via:Stm.via, warn:Stm.warn.length})"))
    up(pg, '04_Purchases/Bill_PDFs/' + sorted(os.listdir(os.path.join(S, '04_Purchases/Bill_PDFs')))[0]); pg.wait_for_selector('#vf-miss', timeout=15000); print('  supplier bill PDF -> form:', pg.evaluate("({type:VForm.s.type, party:VForm.s.party, billNo:VForm.s.billNo, rate:VForm.s.items[0].rate, hsn:VForm.s.items[0].hsn})"), '|', pg.inner_text('#vf-miss').split('\n')[0]); pg.evaluate("document.getElementById('modal-root').innerHTML=''")
    up(pg, *['08_Annual_Reports_Ind_AS/' + f for f in sorted(os.listdir(os.path.join(S, '08_Annual_Reports_Ind_AS')))]); pg.wait_for_function("IndAS.years().length>=3", timeout=40000); print('  annual reports -> Ind AS tile years:', pg.evaluate("IndAS.years()"))
    up(pg, '07_GST_and_Tax/Sample_GST_Notice.pdf'); time.sleep(1); print('  notice -> AI Studio tab:', pg.evaluate("App.ui.stTab"), '| text loaded:', pg.evaluate("(Studio.notice||'').length>100"))
    pg.evaluate("Router.go('fspack'); Actions['fs-tab']('ready')"); time.sleep(.5); print('  FS readiness for the imported books:', pg.evaluate("FSChk.score()"))
    r = pg.evaluate("(()=>{ const fy=App.session.fy; const d=FS.build({}); return {checks:d.checks.length, failing:d.checks.filter(c=>!c.ok).map(c=>c.label)} })()"); print('  FS tie-outs on imported books:', r)
    print('page errors:', errs or 'none'); b.close()
