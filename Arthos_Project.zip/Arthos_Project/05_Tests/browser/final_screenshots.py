import sys, os, time, base64, shutil
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
from PIL import Image
D = os.path.join(ROOT, '08_Screenshots'); shutil.rmtree(D, ignore_errors=True); os.makedirs(D)
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width':1440,'height':900}).new_page(); pg.route('**/*', block_network); demo_login(pg, time)
    pg.add_style_tag(content='*{transition:none!important}')
    skins = pg.evaluate("SKINS.map(s=>s.id)"); thumbs = []
    for sk in skins:
        pg.evaluate(f"App.core.settings.skin='{sk}'; App.core.settings.theme='light'; applyTheme(); Router.go('dashboard')"); time.sleep(.6); fp = f'/tmp/_sk_{sk}.png'; pg.screenshot(path=fp); thumbs.append(fp)
    ims = [Image.open(t).convert('RGB').resize((720, 450)) for t in thumbs]; W = Image.new('RGB', (1440, 450 * 5), 'white')
    for i, im in enumerate(ims): W.paste(im, ((i % 2) * 720, (i // 2) * 450))
    W.save(D + '/01_ten_skins.png')
    pg.evaluate("App.core.settings.skin='ledger'; applyTheme();")
    def shot(name, js, wait=.8, full=False): pg.evaluate(js); time.sleep(wait); pg.screenshot(path=D + '/' + name, full_page=full)
    shot('02_virtual_cfo.png', "Router.go('cfo')"); shot('03_cfo_ask.png', "Actions['cfo-tab']('ask'); Actions['cfo-go']('Why did profit change last month?')", 1.2)
    shot('04_fs_pack_readiness.png', "Router.go('fspack'); Actions['fs-tab']('ready')", 1, True)
    shot('05_statement_assistant.png', "Router.go('stmt'); Actions['stm-sample']('pdf')", 2.5, True)
    shot('06_ind_as_tile.png', "Router.go('indas'); Actions['ia-sample']()", 4, True)
    shot('07_mandatory_fields_form.png', "Router.go('vouchers'); VForm.open('Sales')", 1)
    pg.evaluate("document.getElementById('modal-root').innerHTML=''")
    sid = pg.evaluate("Books.cur().vouchers.find(x=>x.type==='Sales'&&x.status==='posted').id"); shot('08_invoice_format_picker.png', f"Invoice.open('{sid}')", 1.2)
    pg.evaluate("document.getElementById('modal-root').innerHTML=''"); shot('09_import_and_sample_data.png', "Router.go('import')", 1, True)
    out = pg.evaluate("""async()=>{ const d=FS.build({units:'lakh'}); const doc=FS.pdf(d,{draft:false}); const r=await Rd.pdf(new File([doc.output('blob')],'x.pdf')); const imgs=[]; for(const i of [0,2,3,5,7]){ if(!r.pages[i]) continue; const vp=r.pages[i].page.getViewport({scale:1.4}); const c=document.createElement('canvas'); c.width=vp.width; c.height=vp.height; await r.pages[i].page.render({canvasContext:c.getContext('2d'), viewport:vp}).promise; imgs.push(c.toDataURL('image/png').split(',')[1]); } return imgs; }""")
    for n, im in zip(['10_fs_cover', '11_fs_balance_sheet', '12_fs_profit_and_loss', '13_fs_cash_flow', '14_fs_notes'], out): open(D + f'/{n}.png', 'wb').write(base64.b64decode(im))
    pg.click('[data-act="user-menu"]'); pg.click('.menu [data-act="signout"]'); pg.wait_for_selector('.co-card'); time.sleep(.4); pg.screenshot(path=D + '/00_welcome_company_chooser.png')
    b.close()
print(sorted(os.listdir(D)))
