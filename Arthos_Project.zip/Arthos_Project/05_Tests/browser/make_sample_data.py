"""Builds 06_Sample_Data: one folder per tile, every file consistent with the sample company.
Run:  python3 make_sample_data.py      (needs 01_App/arthos-offline.html built)"""
import sys, os, time, base64, shutil, zipfile, io
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
DEST = os.path.join(ROOT, '06_Sample_Data'); shutil.rmtree(DEST, ignore_errors=True); os.makedirs(DEST)
JS = r"""
async () => {
  const co = App.company, out = [], cap = []; const od = Files.download; Files.download = (n, b) => cap.push([n, b]);
  const b64 = async x => typeof x === 'string' ? btoa(unescape(encodeURIComponent(x))) : await blobB64(x);
  const put = async (p, x) => out.push([p, await b64(x)]);
  const F = Imp.files(co), fold = { Vendor_Master: '01_Masters', Customer_Master: '01_Masters', Opening_Balances: '01_Masters', Employees: '01_Masters', Fixed_Assets: '01_Masters', Stock_Count: '01_Masters', Bank_Statement_HDFC: '02_Bank_Statements', Sales_Register: '03_Sales', Purchase_Register: '04_Purchases', GSTR2B: '07_GST_and_Tax', Journal_Dump: '05_Vouchers_and_Journals', Approval_Log: '05_Vouchers_and_Journals' };
  for (const f of F) { const d = fold[f.file]; if (!d) continue; await put(d + '/' + f.file + '.xlsx', Files.xlsx({ [f.title.slice(0, 28)]: f.rows })); await put(d + '/' + f.file + '.csv', Files.csv(f.rows)); }
  await put('07_GST_and_Tax/GSTR2B.json', JSON.stringify(GSTR2B.sample(), null, 1)); await put('10_Users_and_Access/Users_Roles.json', JSON.stringify(Lab.get(co).users.data, null, 2));
  // bank statements in other layouts and formats
  const rows = SampleDocs.rows(80), op = SampleDocs.opening(rows), dm = d => d.slice(8, 10) + '-' + d.slice(5, 7) + '-' + d.slice(0, 4);
  await put('02_Bank_Statements/Bank_Statement_SBI_layout.csv', Files.csv([{ 'Txn Date': dm(rows[0].date), 'Description': 'OPENING BALANCE B/F', 'Ref No./Cheque No.': '', 'Debit': '', 'Credit': '', 'Balance': op.toFixed(2) }, ...rows.map(r => ({ 'Txn Date': dm(r.date), 'Description': r.narr, 'Ref No./Cheque No.': r.ref, 'Debit': r.w ? r.w.toFixed(2) : '', 'Credit': r.d ? r.d.toFixed(2) : '', 'Balance': r.bal.toFixed(2) }))]));
  await put('02_Bank_Statements/Bank_Statement_ICICI_layout.xlsx', Files.xlsx({ Statement: [{ 'Transaction Date': dm(rows[0].date), 'Transaction Remarks': 'OPENING BALANCE B/F', 'Withdrawal Amount (INR )': '', 'Deposit Amount (INR )': '', 'Balance (INR )': op.toFixed(2) }, ...rows.map(r => ({ 'Transaction Date': dm(r.date), 'Transaction Remarks': r.narr + ' ' + r.ref, 'Withdrawal Amount (INR )': r.w ? r.w.toFixed(2) : '', 'Deposit Amount (INR )': r.d ? r.d.toFixed(2) : '', 'Balance (INR )': r.bal.toFixed(2) }))] }));
  await put('02_Bank_Statements/Bank_Statement_HDFC_text_PDF.pdf', SampleDocs.pdf(80)); await put('02_Bank_Statements/Bank_Statement_scanned_image.png', await SampleDocs.png(30)); await put('11_OCR_Scans/Bank_Statement_scanned_image.png', await SampleDocs.png(30));
  // invoices in three formats
  const sv = Books.cur().vouchers.filter(v => v.type === 'Sales' && v.status === 'posted'); for (const [i, t] of [[0, 'classic'], [4, 'modern'], [9, 'bold']]) { if (sv[i]) { try { Invoice.pdf(sv[i], t); } catch (e) { } } }
  // supplier bills as text PDFs (parsed offline) and photos (need AI or online OCR)
  const vs = Books.cur().parties.filter(p => p.kind === 'V' && GST.validate(p.gstin).ok).slice(0, 3); const bills = [['INV-7712', '2026-10-24', 118500, 18], ['SB/26-27/0418', '2026-10-26', 246300, 18], ['TX-90311', '2026-10-27', 54200, 18]];
  for (let i = 0; i < vs.length; i++) { const [no, d, tx, r] = bills[i]; await put('04_Purchases/Bill_PDFs/Supplier_Bill_' + vs[i].id + '_' + no.replace(/\W+/g, '') + '.pdf', SampleDocs.billPdf(vs[i], { no, date: dm(d), taxable: tx, rate: r })); }
  Actions['lab-bills'](); Actions['lab-notice'](); await Actions['lab-pack'](); await new Promise(r => setTimeout(r, 600));
  { const ym = isoToday().slice(0, 7), P = Payroll.run(ym); await put('06_Payroll/Employees.xlsx', Files.xlsx({ Employees: Imp.files(co).find(f => f.file === 'Employees').rows })); await put('06_Payroll/Payroll_Register_' + ym + '.xlsx', Files.xlsx({ Payroll: P.rows.map(r => ({ Employee: r.e.name, Gross: r.g, Basic: r.basic, 'PF employee': r.ee, 'PF employer': r.er, 'ESI employee': r.esiEE, 'ESI employer': r.esiER, 'Professional tax': r.pt, TDS: r.tds, 'Net pay': r.net })) })); }
  // annual reports for the Ind AS tile
  for (const f of IndAS.sampleFiles()) await put('08_Annual_Reports_Ind_AS/' + f.name, f);
  // CRM, TDS
  const L = Books.cur(); await put('03_Sales/CRM/Leads.xlsx', Files.xlsx({ Leads: L.leads.map(l => ({ Lead: l.name, Company: l.company, Phone: l.phone, Email: l.email, Source: l.source, Stage: l.stage, Value: l.value, 'Next follow-up': l.next })) })); await put('03_Sales/CRM/Support_Tickets.xlsx', Files.xlsx({ Tickets: L.tickets.map(k => ({ Ticket: k.no, Customer: (Books.party(k.cust) || {}).name || k.cust, Subject: k.subject, Priority: k.pri, Status: k.status, Opened: k.at.slice(0, 10) })) }));
  await put('07_GST_and_Tax/TDS_26Q_annexure_draft.xlsx', Files.xlsx({ Annexure: TDSD.rows().map(r => ({ 'Deductee code': r.p.id, PAN: r.pan || 'PANNOTAVBL', Name: r.p.name, Section: r.sec, 'Date of payment': r.dt, 'Amount paid': r.base, 'Rate %': r.rate, 'TDS deducted': r.got })) }));
  // financial statement outputs, letters
  for (const frf of ['as', 'indas', 'noncorp']) { const d = FS.build({ units: 'lakh', frf }); await put('09_Statement_Outputs/Financial_Statements_' + frf.toUpperCase() + '.pdf', FS.pdf(d, { draft: false }).output('blob')); const wb = await FS.xlsx(d); await put('09_Statement_Outputs/Financial_Statements_' + frf.toUpperCase() + '.xlsx', new Blob([await wb.xlsx.writeBuffer()])); }
  await put('09_Statement_Outputs/Management_Representation_Letter.pdf', Conf.mrl().output('blob')); await put('09_Statement_Outputs/Balance_Confirmations_Debtors_sample.pdf', Conf.pdf(Conf.rows('C', isoToday()).slice(0, 4), 'C', isoToday()).output('blob'));
  await IndAS.add(IndAS.sampleFiles()); await put('09_Statement_Outputs/Ind_AS_101_Guide.pdf', IndAS.pdf(IndAS.analyse()).output('blob'));
  // full backup of the sample company
  const core = JSON.parse(JSON.stringify(App.core)); core.settings.apiKey = ''; await put('12_Backup/Arthos_Backup_Sample_Company.json', JSON.stringify({ app: CONFIG.app.name, format: 'lekhaai-backup', version: 1, exportedAt: new Date().toISOString(), from: 'sample', core, log: App.log, books: App.books }));
  Files.download = od;
  for (const [n, b] of cap) { const path = /Sample_Bills\.zip$/.test(n) ? '__bills.zip' : /GST_Notice/.test(n) ? '07_GST_and_Tax/' + n : /Judge_Demo/.test(n) ? n : '03_Sales/Invoices/' + n; await put(path, b); }
  return { files: out, key: Lab.key(co) };
}
"""
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width':1440,'height':950}).new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:300])); pg.route('**/*', block_network); demo_login(pg, time)
    res = pg.evaluate(JS); b.close()
n = 0
for path, data in res['files']:
    raw = base64.b64decode(data)
    if path == '__bills.zip':
        z = zipfile.ZipFile(io.BytesIO(raw))
        for nm in z.namelist():
            if nm.lower().endswith(('.jpg', '.jpeg', '.png')):
                for d in ('04_Purchases/Bill_Photos', '11_OCR_Scans'):
                    fp = os.path.join(DEST, d, nm); os.makedirs(os.path.dirname(fp), exist_ok=True); open(fp, 'wb').write(z.read(nm)); n += 1
        continue
    fp = os.path.join(DEST, path); os.makedirs(os.path.dirname(fp), exist_ok=True); open(fp, 'wb').write(raw); n += 1
open(os.path.join(DEST, 'Answer_Key.md'), 'w', encoding='utf-8').write(res['key'])
print('files written:', n, '| page errors:', errs or 'none')
tot = 0
for d, _, fs in os.walk(DEST):
    for f in fs: tot += os.path.getsize(os.path.join(d, f))
print('total MB:', round(tot / 1048576, 1)); print(sorted(os.listdir(DEST)))
