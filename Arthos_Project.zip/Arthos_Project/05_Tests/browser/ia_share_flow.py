import sys, os, time, base64
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width':1440,'height':950}, accept_downloads=True).new_page(); errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)[:300])); pg.route('**/*', block_network); demo_login(pg, time)
    pg.evaluate("Router.go('indas')"); time.sleep(.4)
    pg.evaluate("Actions['ia-sample']()"); pg.wait_for_function("IndAS.years().length>=3", timeout=40000); time.sleep(.6)
    r = pg.evaluate("(()=>{ const a=IndAS.analyse(); return {files:IndAS.files.map(f=>f.name+':'+f.n), years:a.Y, last:a.last, applic:a.applic.m, networth:Math.round(a.networth), first:a.firstLabel, transition:a.transitionLabel, adj:a.adj.map(x=>x.area), effect:Math.round(a.effect), trend:a.trend.map(t=>[t.y,Math.round(t.rev||0),Math.round(t.pat||0),Math.round(t.eq||0)])}})()")
    print('1 Ind AS tile:', {k:v for k,v in r.items() if k!='trend'}); print('  trend (year, revenue, PAT, equity in rupees):', r['trend'])
    pg.screenshot(path=OUT+'/indas.png', full_page=True)
    with pg.expect_download() as d: pg.click('[data-act="ia-pdf"]')
    d.value.save_as(OUT+'/indas.pdf'); print('  guide PDF KB:', os.path.getsize(OUT+'/indas.pdf')//1024)
    with pg.expect_download() as d2: pg.click('[data-act="ia-xlsx"]')
    d2.value.save_as(OUT+'/indas.xlsx')
    from openpyxl import load_workbook; print('  workbook sheets:', load_workbook(OUT+'/indas.xlsx').sheetnames)
    # invoice picker
    sid = pg.evaluate("Books.cur().vouchers.find(x=>x.type==='Sales'&&x.status==='posted').id")
    pg.evaluate(f"Invoice.open('{sid}')"); pg.wait_for_selector('.tpl-grid'); n = pg.evaluate("document.querySelectorAll('.tpl-card').length"); print('2 invoice formats offered:', n, pg.evaluate("[...document.querySelectorAll('.tpl-card b')].map(x=>x.textContent)")); pg.screenshot(path=OUT+'/invoice_picker.png')
    pg.click('.tpl-card[data-tpl="modern"]'); pg.wait_for_selector('#inv-area .inv'); print('  chose Modern ->', pg.evaluate("document.querySelector('#inv-area .inv').className"))
    pg.evaluate("window.__dl=[]; const od=Files.download; Files.download=(n,d,m)=>{ window.__dl.push({n, t:(typeof d==='string'?d:null), size:d&&d.size}); }")
    pg.click('.modal footer button:has-text("Email invoice")'); pg.wait_for_selector('#sh-to', timeout=15000); time.sleep(.3)
    print('  email dialog: to =', pg.input_value('#sh-to'), '| subject =', pg.input_value('#sh-sub')[:60], '| attachments listed:', pg.inner_text('.modal').count('.pdf'))
    pg.fill('#sh-to', 'accounts@example.in'); pg.click('.modal footer button:has-text("Download .eml draft")'); time.sleep(.5)
    eml = pg.evaluate("(window.__dl.find(x=>/\\.eml$/.test(x.n))||{}).t"); print('  .eml has PDF attachment:', bool(eml and 'application/pdf' in eml and 'Content-Disposition: attachment' in eml), '| size', len(eml or ''))
    pg.evaluate("document.getElementById('modal-root').innerHTML=''")
    # confirmations
    pg.evaluate("Router.go('confirm')"); time.sleep(.5); pg.click('[data-act="cf-all"]'); time.sleep(.3)
    k = pg.evaluate("Object.values(App.ui.cfSel||{}).filter(Boolean).length"); print('3 confirmations: parties selected', k)
    res = pg.evaluate("""async()=>{ const {k,d,rows}=cfPick(); const doc=Conf.pdf(rows.slice(0,3),k,d); const f=new File([doc.output('blob')],'c.pdf'); const r=await Rd.pdf(f); const m=Conf.mrl(); const r2=await Rd.pdf(new File([m.output('blob')],'m.pdf')); return {pages:r.pages.length, reply:/REPLY SLIP/.test(r.text), balance:/Balance as at/.test(r.text), mrl:/representation/i.test(r2.text), mrlPages:r2.pages.length, audit:/audit trail/i.test(r2.text)}; }""")
    print('  letters:', res)
    # FS mail
    pg.evaluate("Router.go('fspack'); Actions['fs-tab']('export')"); time.sleep(.6); pg.click('[data-act="fs-mail"]'); pg.wait_for_selector('#sh-sub', timeout=20000); print('4 FS email dialog subject:', pg.input_value('#sh-sub'), '| attachment:', 'Financial_Statements' in pg.inner_text('.modal'))
    print('page errors:', errs or 'none'); b.close()
