import sys, os, time
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width':1440,'height':950}).new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:160])); pg.route('**/*', block_network); demo_login(pg, time)
    pg.evaluate("Router.go('vouchers'); VForm.open('Sales')"); pg.wait_for_selector('#vf-miss'); time.sleep(.3)
    t = pg.inner_text('#vf-miss'); print('1 mandatory panel shows:', t.split('\n')[0], '|', 'Customer' in t, 'Narration' in t)
    pg.click('.modal footer .btn.primary'); time.sleep(.3); print('  save stays open:', bool(pg.query_selector('.modal')), '| panel red:', 'tried' in (pg.get_attribute('#vf-miss','class') or ''))
    pg.fill('[data-f="narr"]', 'abc'); pg.keyboard.press('Escape'); time.sleep(.3); print('2 Esc on a dirty form keeps it open with warning:', bool(pg.query_selector('.modal')), '|', 'unsaved' in pg.inner_text('#vf-miss').lower())
    # searchable select
    pg.click('[data-f="party"] ~ .ss-btn'); pg.wait_for_selector('.ss-pop:not([hidden])'); n_all = pg.evaluate("document.querySelectorAll('.ss-pop:not([hidden]) li[role=option]').length"); pg.keyboard.type('sahy'); time.sleep(.2)
    n_f = pg.evaluate("document.querySelectorAll('.ss-pop:not([hidden]) li[role=option]').length"); print('3 searchable select: options', n_all, '-> filtered to', n_f, '|', pg.evaluate("[...document.querySelectorAll('.ss-pop:not([hidden]) li[role=option]')].map(l=>l.textContent)"))
    pg.keyboard.press('Enter'); time.sleep(.3); print('  chosen (native + state):', pg.evaluate("document.querySelector('[data-f=party]').value"), pg.evaluate("VForm.s.party"))
    # HSN rules
    for code, rate in (('12', '18'), ('390110', '18'), ('390110', '5'), ('9983', '18'), ('998313', '18')):
        pg.fill('[data-i="0:hsn"]', code); pg.select_option('[data-i="0:gst"]', rate) if pg.query_selector('[data-i="0:gst"]') else None; time.sleep(.15)
        lines = [l for l in pg.inner_text('#vf-miss').split('\n') if 'HSN' in l]; print('  HSN', code, '@', rate + '% ->', (lines[0][:150] if lines else 'accepted'))
    pg.screenshot(path=OUT+'/form_mandatory.png')
    # Esc twice discards
    pg.keyboard.press('Escape'); pg.keyboard.press('Escape'); time.sleep(.3); print('4 second Esc discards:', not pg.query_selector('.modal'))
    # purchase invoice number rule
    pg.evaluate("VForm.open('Purchase')"); pg.wait_for_selector('#vf-miss'); pg.fill('[data-f="billNo"]', 'INV 22/2026-27 EXTRA LONG'); time.sleep(.15); print('5 bill no rule:', [l for l in pg.inner_text('#vf-miss').split('\n') if 'bill number' in l.lower()][:1])
    pg.keyboard.press('Escape'); time.sleep(.2); pg.evaluate("document.getElementById('modal-root').innerHTML=''")
    # partial (AI-style) entry cannot post
    pg.evaluate("VForm.open('Payment', {amount:'25000', acc:'rent', ai:true, aiMeta:'drafted from text'})"); pg.wait_for_selector('#vf-miss'); pg.click('.modal footer .btn.primary'); time.sleep(.3)
    print('6 partial AI entry: stays open =', bool(pg.query_selector('.modal')), '| missing:', [x for x in ('Narration','UTR / cheque') if x in pg.inner_text('#vf-miss')])
    pg.evaluate("document.getElementById('modal-root').innerHTML=''")
    # complete a journal and verify with Refresh
    before = pg.evaluate("Books.cur().vouchers.length")
    pg.evaluate("VForm.open('Journal', {narr:'Office rent for October 2026', lines:[{acc:'rent',dr:'20000',cr:''},{acc:'bank',dr:'',cr:'20000'}]})"); time.sleep(.3)
    print('7 complete journal -> panel:', pg.inner_text('#vf-miss').split('\n')[0]); pg.click('.modal footer .btn.primary'); time.sleep(.6)
    print('  vouchers', before, '->', pg.evaluate("Books.cur().vouchers.length"))
    pg.click('[data-act="refresh"]'); pg.wait_for_selector('.modal'); print('8 refresh and verify:', pg.inner_text('.modal .note').split('\n')[0]); pg.screenshot(path=OUT+'/refresh_verify.png')
    print('page errors:', errs or 'none'); b.close()
