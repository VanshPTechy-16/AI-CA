import os
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
APP = 'file://' + os.path.join(ROOT, '01_App', 'arthos-offline.html')   # offline build needs no network
OUT = os.path.join(os.path.dirname(__file__), '_out'); os.makedirs(OUT, exist_ok=True)
def block_network(route):  # abort everything that is not a local file, to prove nothing leaves the machine
    u = route.request.url
    if u.startswith(('file:', 'data:', 'blob:')): route.continue_()
    else: route.abort()
def demo_login(pg, time):
    pg.goto(APP); pg.wait_for_selector('[data-act="ob-demo"]'); pg.click('[data-act="ob-demo"]'); pg.wait_for_selector('.upick')
    pg.fill('#login-pin', '1234'); pg.click('[data-act="wl-go"]'); pg.wait_for_selector('#view h1'); time.sleep(1.0)
