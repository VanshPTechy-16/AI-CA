import sys, os, time
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_context(viewport={'width':1440,'height':900}).new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:160])); pg.route('**/*',block_network)
    pg.goto(APP); pg.wait_for_selector('[data-act="ob-demo"]'); pg.click('[data-act="ob-demo"]'); pg.wait_for_selector('.upick'); pg.fill('#login-pin','1234'); pg.click('[data-act="wl-go"]'); pg.wait_for_selector('#view h1'); time.sleep(1)
    T="""(N)=>{ const b=Books.cur(); const base=b.vouchers.filter(v=>v.status==='posted'); const t0=performance.now(); let k=0; const out=[];
      while(out.length<N){ for(const v of base){ if(out.length>=N) break; const c=JSON.parse(JSON.stringify(v)); c.id='p'+(k++); c.no=c.no+'-X'+k; out.push(c);} }
      b.vouchers=base.concat(out); return b.vouchers.length }"""
    def time_it(label, js):
        t=pg.evaluate("(js)=>{ const t0=performance.now(); try{ (0,eval)(js) }catch(e){ return 'ERR '+e.message } return Math.round(performance.now()-t0) }", js); print(f'   {label:<34} {t} ms')
    for N in [3000, 12000]:
        n=pg.evaluate(T, N); print(f'--- {n} vouchers (~{n*2.7:.0f} ledger lines)')
        time_it('Trial balance (Rep.trial)', "Rep.trial(App.session.fy)")
        time_it('Balance sheet', "Rep.bs(App.session.fy)")
        time_it('Cash flow', "Rep.cf(App.session.fy)")
        time_it('Risk & anomaly tests', "Risk.run()")
        time_it('Duplicate scan', "Dup.scan()")
        time_it('Receivables risk', "AR.risk()")
        time_it('Dashboard render', "Router.go('dashboard')")
        time_it('Vouchers list render (paged)', "Router.go('vouchers')")
        time_it('Financial statements render', "Router.go('reports')")
        time_it('Integrity check (async start)', "Integrity.run()")
    print('page errors:', errs or 'none'); b.close()
