import sys, os, time
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width':1440,'height':950}).new_page(); errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)[:300])); pg.route('**/*', block_network); demo_login(pg, time)
    print('risk finding keys:', pg.evaluate("Object.keys(Risk.run().F[0])"))
    for tab in ['over','prof','liq','cv','tax','ask']:
        pg.evaluate(f"Router.go('cfo'); Actions['cfo-tab']('{tab}')"); time.sleep(.5)
        n = pg.evaluate("document.querySelectorAll('#view canvas').length"); txt = pg.inner_text('#view'); bad = [w for w in ('NaN','undefined','[object') if w in txt]
        print(f'tab {tab:<5} canvases={n} problems={bad or "none"}')
        if tab in ('over','liq'): pg.screenshot(path=OUT+f'/cfo_{tab}.png', full_page=True)
    res = pg.evaluate("""()=>{ const out=[]; CFO_QS.forEach(q=>{ const a=CFO.answer(q); out.push([q.slice(0,46), a? a.replace(/\\n/g,' ').slice(0,95) : 'NO ANSWER']); }); return out; }""")
    miss = [r for r in res if r[1]=='NO ANSWER']; print('questions answered from ledgers:', len(res)-len(miss), 'of', len(res)); [print('  ', r[0], '->', r[1]) for r in res[:6]]; print('  unanswered:', miss)
    pg.evaluate("Actions['cfo-tab']('ask')"); time.sleep(.3); pg.evaluate("Actions['cfo-go']('Why did profit change last month?')"); time.sleep(.8)
    print('chat after asking:', pg.evaluate("document.querySelectorAll('#cfo-chat .msg').length"), 'messages; link buttons:', pg.evaluate("document.querySelectorAll('#cfo-chat button[data-act]').length"))
    pg.click('[data-act="copilot"]'); time.sleep(.3); pg.fill('#cp-text', 'Who owes me money?'); pg.click('[data-act="cp-send"]'); time.sleep(.6)
    print('copilot answer:', pg.inner_text('#cp-body .msg.ai >> nth=-1')[:170].replace('\n',' '))
    print('page errors:', errs or 'none'); b.close()
