import sys, os, time, base64
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width':1440,'height':950}, accept_downloads=True).new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:200])); pg.route('**/*', block_network); demo_login(pg, time)
    pg.evaluate("Router.go('stmt')"); time.sleep(.4)
    # 1. PDF round trip: render 40 seed rows to a PDF, read it back and compare line by line
    r = pg.evaluate("""async()=>{ const rows=SampleDocs.rows(40); const f=new File([SampleDocs.pdf(40)],'S.pdf',{type:'application/pdf'}); const d=await Rd.any(f); const st=Cls.bank(d.lines); const got=st.rows.filter(x=>x.narr!=='OPENING BALANCE B/F');
      let same=0; rows.forEach((o,i)=>{ const g=got[i]; if(g && g.date===o.date && Math.abs(g.w-o.w)<.01 && Math.abs(g.d-o.d)<.01 && Math.abs(g.bal-o.bal)<.01) same++; });
      return {orig:rows.length, parsed:got.length, exact:same, via:d.via, warnings:st.warnings.length, opening:st.opening, closing:st.closing, sample:got[3]}; }""")
    print('1 PDF round trip:', {k:v for k,v in r.items() if k!='sample'}); print('  sample parsed row:', r['sample'])
    # 2. refs and narrations
    r2 = pg.evaluate("""async()=>{ const rows=SampleDocs.rows(40); const d=await Rd.any(new File([SampleDocs.pdf(40)],'S.pdf',{type:'application/pdf'})); const got=Cls.bank(d.lines).rows.filter(x=>x.narr!=='OPENING BALANCE B/F'); let ref=0, nar=0; rows.forEach((o,i)=>{ const g=got[i]; if(!g) return; if(g.ref===o.ref) ref++; const A=o.narr.replace(/\\s+/g,' ').trim(); if(g.narr===A) nar++; }); return {refMatch:ref, narrationExact:nar, total:rows.length}; }""")
    print('2 references/narrations recovered:', r2)
    # 3. load via the assistant (drop path) and look at suggestions on the FULL statement vs actual books
    pg.evaluate("Actions['stm-sample']('pdf')"); pg.wait_for_selector('table.t', timeout=20000); time.sleep(.8)
    info = pg.evaluate("({rows:Stm.rows.length, inBooks:Stm.rows.filter(r=>r.inBooks).length, todo:Stm.rows.filter(r=>!r.inBooks).length, src:Stm.src, via:Stm.via})"); print('3 assistant loaded:', info)
    # accuracy of the suggestion engine against what the books actually say
    acc = pg.evaluate("""()=>{ const b=Books.cur(), st=Lab.get(App.company).seed.books.bankStmt; const rows=Sug.build({rows:st.rows}); let tot=0, ok=0, byType={}; const book=[]; b.vouchers.filter(v=>v.status==='posted').forEach(v=>v.lines.forEach(l=>{ if(l.acc==='bank'&&(l.dr||l.cr)) book.push({v,amt:l.dr||l.cr,dir:l.dr>0?'in':'out',date:v.date}); }));
      rows.forEach(r=>{ const row={...r}; const sug=Sug.row(row,b); const m=book.find(k=>k.dir===r.dir&&Math.abs(k.amt-r.amt)<.005&&Math.abs(daysBetween(r.date,k.date))<=5&&k.v.ref); if(!m) return; const ctr=m.v.lines.find(l=>l.acc!=='bank'); if(!ctr) return; tot++; const good = sug.acc===ctr.acc || (['go_c','go_s','go_i'].includes(ctr.acc)&&sug.acc==='go_c') || (ctr.acc==='tds_p'&&sug.acc==='tds_p'); if(good) ok++; else (byType[sug.acc+' vs '+ctr.acc]=(byType[sug.acc+' vs '+ctr.acc]||0)+1); });
      return {compared:tot, correct:ok, pct:Math.round(ok/tot*100), misses:byType}; }""")
    print('4 suggestion accuracy on rows that exist in the books:', acc)
    # 5. create entries from the planted unrecorded lines
    pg.evaluate("Actions['stm-sample']('xlsx')"); time.sleep(.6)
    pg.evaluate("Books.cur().stmtPosted={}"); 
    ub = pg.evaluate("(()=>{ const R=BankRec.run(); return R.ub.map(x=>({d:x.date, n:x.narr.slice(0,38), kind:x.cls.kind})) })()"); print('5 bank-only lines per reconciliation:', ub)
    pg.evaluate("Books.cur().bankStmt && Stm.load(Books.cur().bankStmt,'Seed statement','Seed')"); time.sleep(.5)
    todo = pg.evaluate("Stm.rows.filter(r=>!r.inBooks).map(r=>({n:r.narr.slice(0,34), type:r.sug.type, acc:r.sug.acc, conf:r.sug.conf, why:r.sug.why.slice(0,60)}))"); print('  suggestions for lines not in books:'); [print('   ', t) for t in todo]
    n0 = pg.evaluate("Books.cur().vouchers.length"); pg.click('[data-act="stm-auto"]'); time.sleep(.2)
    sel = pg.evaluate("Stm.rows.filter(r=>r.sel).length"); pg.click('[data-act="stm-post"]'); time.sleep(.8)
    res = pg.evaluate("document.querySelector('.modal .note')?.textContent"); print('6 selected', sel, '| result:', res)
    if pg.query_selector('.modal'): pg.click('.modal [data-close]')
    print('  vouchers', n0, '->', pg.evaluate("Books.cur().vouchers.length"), '| reconciliation difference now:', pg.evaluate("BankRec.run().brs.diff"), '| still to record:', pg.evaluate("Stm.rows.filter(r=>!r.inBooks).length"))
    pg.screenshot(path=OUT+'/statement_assistant.png')
    print('page errors:', errs or 'none'); b.close()
