# Regression test: hover a chart (runs colour animations), change the style, check charts are still drawn (not blank).
# Run headed under a real display (or xvfb-run) so motion is on. Blank chart = 1 distinct colour.
import sys, os, time, io
sys.path.insert(0, os.path.dirname(__file__))
from _common import block_network
from playwright.sync_api import sync_playwright
from PIL import Image
from _common import APP; APPF=sys.argv[1] if len(sys.argv)>1 else APP
def vis(pg): return [len(set(Image.open(io.BytesIO(c.screenshot())).convert('RGB').getdata())) for c in pg.query_selector_all('#view canvas')]
with sync_playwright() as p:
    b=p.chromium.launch(headless=False); pg=b.new_context(viewport={'width':1542,'height':900}).new_page(); errs=[]
    pg.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>false})"); pg.on('pageerror', lambda e: errs.append(str(e)[:80])); pg.route('**/*', block_network)
    pg.goto(APPF); pg.wait_for_selector('[data-act="ob-demo"]'); pg.click('[data-act="ob-demo"]'); pg.wait_for_selector('.upick'); pg.fill('#login-pin','1234'); pg.click('[data-act="wl-go"]'); pg.wait_for_selector('#view h1'); time.sleep(1)
    pg.click('.nav-item[data-arg=cfo]'); time.sleep(1); pg.click('[data-act=cfo-tab][data-arg=over]'); time.sleep(1.2)
    pts=pg.evaluate("(()=>{const c=Chart.getChart(document.getElementById('cfo-c1')),r=c.canvas.getBoundingClientRect();return c.getDatasetMeta(0).data.map(e=>[r.left+e.x,r.top+(e.y+e.base)/2])})()")
    for x,y in pts: pg.mouse.move(x,y); time.sleep(.15)
    pg.mouse.move(5,5); time.sleep(.6); print('after hover errors', errs[:2], 'animator running', pg.evaluate("Chart.animator._running"))
    for sk in ['gulabi','midnight']:
        pg.click('.nav-item[data-arg=settings]'); time.sleep(.8); pg.click(f'[data-act=skin-set][data-arg={sk}]'); time.sleep(.8)
        pg.click('.nav-item[data-arg=cfo]'); time.sleep(1); pg.click('[data-act=cfo-tab][data-arg=prof]'); time.sleep(1.5)
        print(sk, 'distinct colours per chart', vis(pg), pg.evaluate("[...document.querySelectorAll('#view canvas')].map(c=>Chart.getChart(c).config.data.datasets[0].backgroundColor)"))
    print('errors', len(errs), errs[:2]); b.close()
