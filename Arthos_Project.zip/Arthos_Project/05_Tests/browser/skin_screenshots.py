import sys, os, time
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width': 1440, 'height': 900}).new_page(); pg.route('**/*', block_network); demo_login(pg, time)
    for sk in ['ledger', 'boardroom', 'midnight', 'gulabi', 'aurora']:
        pg.evaluate(f"App.core.settings.skin='{sk}'; App.core.settings.theme='light'; applyTheme(); Router.render();"); time.sleep(.6); pg.screenshot(path=f'{OUT}/dashboard_{sk}.png')
    print('screenshots written to', OUT); b.close()
