import sys, os, time
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width':1440,'height':950}, accept_downloads=True).new_page(); errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)[:300])); pg.route('**/*', block_network); demo_login(pg, time)
    mods = pg.evaluate("MODULES.map(m=>m.id)"); print('modules:', len(mods), [m for m in ('cfo','rfq','crm','invx','tdsdesk','fspack','indas','confirm','stmt','import') if m in mods])
    for tab in ['rop','age','cnt','val','hsn']:
        pg.evaluate(f"Router.go('invx'); Actions['ix-tab']('{tab}')"); time.sleep(.3); t = pg.inner_text('#view'); print(f'invx/{tab}: {len(t)} chars, problems={[w for w in ("NaN","undefined") if w in t] or "none"}')
    pg.evaluate("Router.go('invx'); Actions['ix-tab']('rop')"); time.sleep(.3); print('  EOQ rows:', pg.evaluate("IX.rows().map(r=>[r.i.name.slice(0,18), Math.round(r.eoq), Math.round(r.rop), r.below])"))
    pg.evaluate("Router.go('rfq')"); time.sleep(.4); print('rfq: cards', pg.evaluate("document.querySelectorAll('#view .card').length"), '| lowest flagged:', 'Lowest' in pg.inner_text('#view'), '| saving line:', 'saves' in pg.inner_text('#view'))
    pg.evaluate("Actions['rfq-po']('rf_s1|1')"); pg.wait_for_selector('#vf-miss'); print('  purchase form prefilled: vendor', pg.evaluate("VForm.s.party"), 'rate', pg.evaluate("VForm.s.items[0].rate"), 'qty', pg.evaluate("VForm.s.items[0].qty")); pg.evaluate("document.getElementById('modal-root').innerHTML=''")
    pg.evaluate("Router.go('crm')"); time.sleep(.4); print('crm: kpis', pg.evaluate("[...document.querySelectorAll('#view .kpi .v')].map(x=>x.textContent)"))
    pg.evaluate("Actions['lead-conv']('ld_s3')"); pg.wait_for_selector('#cv-n'); pg.fill('#cv-g','24AAACK1234'); time.sleep(.2); pg.click('.modal footer [data-mi="1"]'); time.sleep(.3); print('  bad GSTIN on conversion:', pg.inner_text('#cv-err')[:90])
    pg.fill('#cv-g',''); pg.click('.modal footer [data-mi="1"]'); time.sleep(.5); print('  converted -> customer', pg.evaluate("Books.cur().leads.find(l=>l.id==='ld_s3').cust"), '| accounts has it:', pg.evaluate("!!Books.cur().accounts.find(a=>a.id===Books.cur().leads.find(l=>l.id==='ld_s3').cust)"))
    pg.evaluate("Actions['crm-tab']('tk')"); time.sleep(.3); print('  tickets with breach flag:', pg.inner_text('#view').count('Breached'))
    pg.evaluate("Router.go('tdsdesk')"); time.sleep(.5); print('tdsdesk kpis:', pg.evaluate("[...document.querySelectorAll('#view .kpi .v')].map(x=>x.textContent)"), '| exceptions:', pg.inner_text('#view .chip.bad, #view .chip.good').split('\\n')[0])
    with pg.expect_download() as d: pg.click('#view [data-act="exp"][data-arg="tds26q|xlsx"]')
    d.value.save_as(OUT+'/26q.xlsx'); print('  26Q annexure xlsx KB', os.path.getsize(OUT+'/26q.xlsx')//1024)
    print('CFO runway question:', (pg.evaluate("CFO.answer('How many months of cash do I have?')") or '')[:90])
    print('page errors:', errs or 'none'); b.close()
