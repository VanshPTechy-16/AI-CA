import sys, os, time, zipfile, io
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width':1440,'height':950}, accept_downloads=True).new_page(); errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)[:200])); pg.route('**/*', block_network); demo_login(pg, time)
    # accuracy of narration/reference recovery and suggestions
    r = pg.evaluate("""async()=>{ const rows=SampleDocs.rows(40); const d=await Rd.any(new File([SampleDocs.pdf(40)],'S.pdf',{type:'application/pdf'})); const got=Cls.bank(d.lines).rows.filter(x=>x.narr!=='OPENING BALANCE B/F'); let ref=0,nar=0; rows.forEach((o,i)=>{ const g=got[i]; if(!g) return; if(g.ref===o.ref) ref++; if(g.narr===o.narr.replace(/\\s+/g,' ').trim()) nar++; }); return {refMatch:ref,narrExact:nar,total:rows.length}; }""")
    print('1 PDF narration/reference recovery:', r)
    acc = pg.evaluate("""()=>{ const b=Books.cur(), st=Lab.get(App.company).seed.books.bankStmt; const rows=st.rows.filter(x=>x.narr!=='OPENING BALANCE B/F').map((r,i)=>({i,...r,dir:r.d>0?'in':'out',amt:r.d>0?r.d:r.w})); const book=[]; b.vouchers.filter(v=>v.status==='posted').forEach(v=>v.lines.forEach(l=>{ if(l.acc==='bank'&&(l.dr||l.cr)) book.push({v,amt:l.dr||l.cr,dir:l.dr>0?'in':'out',date:v.date,used:false}); }));
      let tot=0, ok=0, miss={}; rows.forEach(r=>{ const m=book.find(k=>!k.used&&k.dir===r.dir&&Math.abs(k.amt-r.amt)<.005&&Math.abs(daysBetween(r.date,k.date))<=5); if(!m) return; m.used=true; const ctr=m.v.lines.find(l=>l.acc!=='bank'); if(!ctr) return; tot++; const s=Sug.row(r,b); const good=s.acc===ctr.acc||(['go_c','go_s','go_i'].includes(ctr.acc)&&s.acc==='go_c')||(s.acc==='cash'&&ctr.acc==='cash'); if(good) ok++; else { const k=s.acc+' (sug) vs '+ctr.acc+' (books)'; miss[k]=(miss[k]||0)+1; } });
      return {compared:tot, correct:ok, pct:Math.round(ok/tot*100), misses:miss}; }""")
    print('2 suggestion accuracy vs the ledger the books actually used:', acc)
    # formatted Excel (ExcelJS) and PDF
    pg.evaluate("Router.go('reports')"); time.sleep(.5); pg.evaluate("Actions['rep-tab']('pl')"); time.sleep(.5)
    with pg.expect_download() as d: pg.click('#view [data-act="exp"][data-arg="pl|xlsx"]')
    path = OUT + '/pl.xlsx'; d.value.save_as(path)
    from openpyxl import load_workbook
    wb = load_workbook(path); ws = wb.active
    hdr = [c for c in ws[6] if c.value]; print('3 Excel: sheet', ws.title, '| title row:', ws['A3'].value, '| header fill:', hdr[0].fill.fgColor.rgb, '| header bold:', hdr[0].font.b, '| freeze:', ws.freeze_panes, '| merged:', len(ws.merged_cells.ranges), '| landscape:', ws.page_setup.orientation, '| filter:', ws.auto_filter.ref)
    nums = [c for row in ws.iter_rows(min_row=7, max_row=20) for c in row if isinstance(c.value, (int, float))]; print('   numeric cells stored as numbers:', len(nums), '| format:', nums[0].number_format if nums else None, '| right aligned:', nums[0].alignment.horizontal if nums else None)
    with pg.expect_download() as d2: pg.click('#view [data-act="exp"][data-arg="pl|pdf"]')
    pp = OUT + '/pl.pdf'; d2.value.save_as(pp); data = open(pp, 'rb').read()
    txt = pg.evaluate("""async(b64)=>{ const bin=atob(b64), u=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++) u[i]=bin.charCodeAt(i); const r=await Rd.pdf(new File([u],'x.pdf')); return {pages:r.pages.length, text:r.text.slice(0,600), hasRupee:r.text.includes('₹'), hasPageNo:/Page 1 of/.test(r.text)}; }""", __import__('base64').b64encode(data).decode())
    print('4 PDF: pages', txt['pages'], '| rupee sign present:', txt['hasRupee'], '| page numbers:', txt['hasPageNo'], '| size KB', len(data)//1024); print('   first lines:', txt['text'][:260].replace('\n',' | '))
    print('page errors:', errs or 'none'); b.close()
