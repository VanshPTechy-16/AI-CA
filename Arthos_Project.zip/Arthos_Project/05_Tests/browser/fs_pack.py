import sys, os, time, base64, json
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width':1440,'height':950}).new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)[:300])); pg.route('**/*', block_network); demo_login(pg, time)
    pg.evaluate("Router.go('fspack')"); time.sleep(.6); pg.screenshot(path=OUT+'/fs_readiness.png')
    print('readiness:', pg.evaluate("(()=>{const s=FSChk.score(); return s})()"))
    for frf in ['as','indas','llp','noncorp','trust']:
        r = pg.evaluate("""(frf)=>{ App.company.frf=frf; const d=FS.build({units:'lakh'}); const bad=d.checks.filter(c=>!c.ok).map(c=>c.label+' :: '+c.detail); return {frf, sections:d.sections.map(s=>s.id), notes:d.notes.length, checks:d.checks.length, failing:bad, bsA:Math.round(d.taC), bsL:Math.round(d.tlC)}; }""", frf)
        print(frf.ljust(8), 'sections', r['sections'], '| notes', r['notes'], '| checks', r['checks'], '| failing', r['failing'][:4])
    pg.evaluate("App.company.frf='as'")
    # PDF
    out = pg.evaluate("""async()=>{ const d=FS.build({units:'lakh'}); const doc=FS.pdf(d,{draft:false}); const blob=doc.output('blob'); const f=new File([blob],'fs.pdf'); const r=await Rd.pdf(f); const imgs=[]; for(const i of [0,1,2,3,5]){ if(!r.pages[i]) continue; const vp=r.pages[i].page.getViewport({scale:1.25}); const c=document.createElement('canvas'); c.width=vp.width; c.height=vp.height; await r.pages[i].page.render({canvasContext:c.getContext('2d'), viewport:vp}).promise; imgs.push(c.toDataURL('image/png').split(',')[1]); }
      const t=r.text; return {pages:r.pages.length, kb:Math.round(blob.size/1024), hasRupee:t.includes('₹'), hasUDIN:/UDIN: 123456280626AAABCD/.test(t), pageNums:/Page 1 of /.test(t), contents:/Balance Sheet[\\s.]*\\d/.test(t), signature:/As per our report of even date/.test(t), sample:r.pages[2].lines.slice(0,14), imgs}; }""")
    for i, im in enumerate(out['imgs']): open(OUT+f'/fs_page{i+1}.png','wb').write(base64.b64decode(im))
    print('PDF:', {k:v for k,v in out.items() if k not in ('imgs','sample')}); print('  page 3 text:', out['sample'][:12])
    # Excel
    x = pg.evaluate("""async()=>{ const d=FS.build({units:'lakh'}); const wb=await FS.xlsx(d); const buf=await wb.xlsx.writeBuffer(); let s=''; const u=new Uint8Array(buf); for(let i=0;i<u.length;i+=32768) s+=String.fromCharCode.apply(null,u.subarray(i,i+32768)); return {b64:btoa(s), total:d.taC/1e5}; }""")
    open(OUT+'/fs.xlsx','wb').write(base64.b64decode(x['b64']))
    from openpyxl import load_workbook
    wb = load_workbook(OUT+'/fs.xlsx'); print('Excel sheets:', wb.sheetnames)
    ws = wb['Balance Sheet']; vals = [(r[0].value, r[2].value) for r in ws.iter_rows(min_row=7, max_row=ws.max_row) if r[0].value and str(r[0].value).startswith('TOTAL')]; print('  BS totals in Excel (lakhs):', vals, '| app total (lakhs):', round(x['total'],2), '| number format:', ws['C9'].number_format)
    print('page errors:', errs or 'none'); b.close()
