"""Contrast, overflow and font audit. Opens every module (and key dialogs) in every skin and flags:
 - text whose contrast against its real background is below WCAG AA (4.5, or 3 for large/bold text)
 - invisible text (colour equals background, or transparent text fill)
 - horizontal page overflow and clipped text
 - text not rendered in an embedded font
Usage: python3 contrast_audit.py [skin ...]   (default: all skins)"""
import sys, os, time, json
sys.path.insert(0, os.path.dirname(__file__))
from _common import *
from playwright.sync_api import sync_playwright
JS = r"""
() => {
  const parse = c => { const m = c.match(/rgba?\(([^)]+)\)/); if(!m) return [0,0,0,0]; const p = m[1].split(/[ ,\/]+/).filter(Boolean).map(Number); return [p[0],p[1],p[2], p.length>3 ? p[3] : 1]; };
  const over = (f, b) => { const a = f[3]; return [f[0]*a+b[0]*(1-a), f[1]*a+b[1]*(1-a), f[2]*a+b[2]*(1-a), 1]; };
  const lum = c => { const f = v => { v/=255; return v<=0.03928 ? v/12.92 : Math.pow((v+0.055)/1.055,2.4); }; return 0.2126*f(c[0])+0.7152*f(c[1])+0.0722*f(c[2]); };
  const ratio = (a,b) => { const l1 = lum(a), l2 = lum(b); return (Math.max(l1,l2)+0.05)/(Math.min(l1,l2)+0.05); };
  const root = getComputedStyle(document.documentElement), bodyBg = parse(getComputedStyle(document.body).backgroundColor);
  const base = bodyBg[3] ? bodyBg : [255,255,255,1];
  const gradCols = el => { const out = []; for (let e = el; e && e.nodeType === 1; e = e.parentElement) { const bi = getComputedStyle(e).backgroundImage; if (bi && bi.includes('gradient')) { const cs = bi.match(/rgba?\([^)]+\)/g) || []; if (cs.length) return cs.map(parse); } } return null; };
  const bgOf = el => { const chain = []; for (let e = el; e && e.nodeType === 1; e = e.parentElement) chain.push(e); let bg = base.slice(); for (let i = chain.length-1; i >= 0; i--) { const c = parse(getComputedStyle(chain[i]).backgroundColor); if (c[3] > 0) bg = over(c, bg); } return bg; };
  const out = []; const seen = new Set();
  const vis = el => { const r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; const s = getComputedStyle(el); return s.visibility !== 'hidden' && s.display !== 'none' && +s.opacity > 0.05; };
  const roots = [...document.querySelectorAll('#view, #modal-root, .copilot.open, .menu, .topbar, .sidebar, .statusbar')];
  const walker = r => { const tw = document.createTreeWalker(r, NodeFilter.SHOW_TEXT); let n; while ((n = tw.nextNode())) { const t = n.nodeValue.trim(); if (t.length < 1) continue; const el = n.parentElement; if (!el || ['SCRIPT','STYLE','OPTION','NOSCRIPT'].includes(el.tagName) || !vis(el)) continue; if (el.closest('.sr, [hidden], canvas, button:disabled, [disabled]')) continue;
      const cs = getComputedStyle(el); let fg = parse(cs.color); const opacityChain = (() => { let o = 1; for (let e = el; e && e.nodeType===1; e = e.parentElement) o *= +getComputedStyle(e).opacity; return o; })(); const bg = bgOf(el); if (cs.backgroundClip === 'text' || cs.webkitBackgroundClip === 'text' || el.closest('[data-bgclip]') || (()=>{ for (let e = el; e && e.nodeType===1; e = e.parentElement) { const x = getComputedStyle(e); if (x.backgroundClip === 'text' || x.webkitBackgroundClip === 'text') return true; } return false; })()) continue; const gc = gradCols(el); fg[3] = fg[3]*opacityChain; const fgs = (gc && gc.length) ? gc.map(g => over(fg, over(g, bg))) : [over(fg, bg)]; const bgs = (gc && gc.length) ? gc.map(g => over(g, bg)) : [bg]; let r = 99; fgs.forEach((f, i) => { r = Math.min(r, ratio(f, bgs[i])); }); fg = fgs[0];
      const size = parseFloat(cs.fontSize), bold = +cs.fontWeight >= 700, large = size >= 24 || (bold && size >= 18.66); const need = large ? 3 : 4.5;
      const clear = cs.webkitTextFillColor && /rgba\(0, 0, 0, 0\)|transparent/.test(cs.webkitTextFillColor) && !(cs.backgroundClip === 'text' || cs.webkitBackgroundClip === 'text');
      if (r < need || clear) { const key = el.tagName + '.' + (el.className||'').toString().split(' ').slice(0,2).join('.') + '|' + Math.round(r*10); if (seen.has(key)) continue; seen.add(key); out.push({ sel: el.tagName.toLowerCase() + (el.className ? '.' + String(el.className).trim().split(/\s+/).slice(0,2).join('.') : ''), text: t.slice(0,40), ratio: +r.toFixed(2), need, fg: cs.color, op: +opacityChain.toFixed(2), bg: bg.map(Math.round).join(','), dbg: JSON.stringify({gc: gc && gc.map(x=>x.map(Math.round).join(',')), bgs: bgs.map(x=>x.map(Math.round).join(',')), fgs: fgs.map(x=>x.map(Math.round).join(','))}).slice(0,300), size, clear: !!clear }); } } };
  roots.forEach(walker);
  // form controls
  document.querySelectorAll('#view input, #view select, #view textarea, #modal-root input, #modal-root select, #modal-root textarea').forEach(el => { if (!vis(el) || el.type === 'checkbox' || el.type === 'radio' || el.type === 'file') return; const cs = getComputedStyle(el); const bg = over(parse(cs.backgroundColor), bgOf(el.parentElement)); const fg = over(parse(cs.color), bg); const r = ratio(fg, bg); if (r < 4.5) out.push({ sel: el.tagName.toLowerCase()+'(control)', text: el.placeholder || el.value || '', ratio: +r.toFixed(2), need: 4.5, fg: cs.color, size: 14 }); });
  const overflowX = document.documentElement.scrollWidth - document.documentElement.clientWidth;
  const fonts = [...new Set([...document.querySelectorAll('#view *')].slice(0,400).map(e => getComputedStyle(e).fontFamily.split(',')[0].replace(/['"]/g,'').trim()))];
  return { issues: out, overflowX, fonts };
}
"""
def main():
    want = sys.argv[1:]
    report = {}
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_context(viewport={'width': 1440, 'height': 900}).new_page(); errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)[:150])); pg.route('**/*', block_network); demo_login(pg, time); pg.add_style_tag(content='*,*::before,*::after{transition:none!important;animation:none!important}')
        skins = pg.evaluate("SKINS.map(s=>({id:s.id,mode:s.mode}))")
        mods = pg.evaluate("MODULES.map(m=>m.id)")
        for sk in skins:
            if want and sk['id'] not in want: continue
            variants = [('light', sk['id'])] + ([('dark', sk['id'])] if sk['mode'] == 'auto' else [])
            for theme, sid in variants:
                tag = sid + ('/' + theme if sk['mode'] == 'auto' else '')
                pg.evaluate(f"App.core.settings.skin='{sid}'; App.core.settings.theme='{theme}'; applyTheme();"); time.sleep(0.15); issues = []; ovf = 0
                for m in mods + ['@modal-voucher', '@modal-notif', '@modal-integrity', '@palette', '@copilot']:
                    try:
                        if m == '@modal-voucher': pg.evaluate("Router.go('vouchers'); VForm.open('Sales')")
                        elif m == '@modal-notif': pg.evaluate("Router.go('dashboard'); Actions.notif()")
                        elif m == '@modal-integrity': pg.evaluate("Router.go('dashboard'); Actions.integrity()")
                        elif m == '@palette': pg.evaluate("Router.go('dashboard'); openPalette()")
                        elif m == '@copilot': pg.evaluate("Router.go('dashboard'); Copilot.toggle(true)")
                        else: pg.evaluate(f"Router.go('{m}')")
                        time.sleep(0.2 if m.startswith('@') else 0.07)
                        r = pg.evaluate(JS)
                        for i in r['issues']: i['where'] = m; issues.append(i)
                        ovf = max(ovf, r['overflowX'])
                    except Exception as e: issues.append({'where': m, 'sel': 'ERROR', 'text': str(e)[:80], 'ratio': 0, 'need': 0})
                    pg.evaluate("document.getElementById('modal-root').innerHTML=''; Copilot.toggle(false)")
                report[tag] = {'issues': issues, 'overflowX': ovf}
        b.close()
    tot = 0
    for tag, r in report.items():
        agg = {}
        for i in r['issues']: agg.setdefault(i['sel'], []).append(i)
        print(f"{tag:<18} issues:{len(r['issues']):>3}  overflowX:{r['overflowX']}")
        for sel, lst in sorted(agg.items(), key=lambda x: -len(x[1]))[:6]: print(f"     {sel:<34} x{len(lst):<3} worst {min(x['ratio'] for x in lst):<5} e.g. '{lst[0]['text']}' ({lst[0]['where']})")
        tot += len(r['issues'])
    json.dump(report, open(os.path.join(OUT, 'contrast_report.json'), 'w'), indent=1); print('TOTAL issues', tot, '| page errors', errs or 'none')
if __name__ == '__main__': main()
