const H = require('./harness');
(async () => {
  const t = await H.make(); const { w, $, sleep, click, go, errors } = t;
  await H.loginDemo(t);
  const r = w.eval(`(()=>{ const fy=App.session.fy; const bs=Rep.bs(fy), cf=Rep.cf(fy), pl=Rep.pl(fy, fyRange(fy).from, fyRange(fy).to);
   return {bsDiff:bs.diff, totA:Math.round(bs.totA), totL:Math.round(bs.totL), cfDiff:cf.diff, cfo:Math.round(cf.cfo), cfi:Math.round(cf.cfi), cff:Math.round(cf.cff), net:Math.round(cf.net), open:Math.round(cf.open), close:Math.round(cf.close), pbt:Math.round(pl.pbt), income:Math.round(pl.income), expense:Math.round(pl.expense)} })()`);
  console.log(JSON.stringify(r));
  const ids = w.eval('MODULES.map(m=>m.id)'); console.log('modules:', ids.join(','));
  for (const id of ids) { await go(id); const v = $('#view'); const txt = v.textContent; const len = txt.length;
    if (/hit an error|couldn.t|is not defined|undefined/.test(txt) || len < 80) console.log('CHECK', id, len, txt.slice(0, 160)); }
  // reports tabs
  await go('reports'); const tabs = [...w.document.querySelectorAll('#view [data-act]')].map(e => e.dataset.act + ':' + e.dataset.arg).filter(x => /tab/.test(x)); console.log('report tab acts:', tabs.join(' '));
  console.log('ERRORS', errors.filter(e => !/getContext/.test(e)).slice(0, 10));
  process.exit(0);
})().catch(e => { console.log('FAIL', e.stack); process.exit(1); });
